function encrypt(plainText) {

	var nvalue = "REPLACE_WITH_RSA_KEY_MODULUS_HEX_VALUE";
	var evalue = "REPLACE_WITH_EXPONENT_HEX_VALUE";

	var rsa = new RSAKey();
	rsa.setPublic(nvalue, evalue);
	var res = rsa.encrypt(plainText);
	return res;	
}