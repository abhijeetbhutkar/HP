'use strict';

(function ( $, window, document /*, undefined */ ) {
	// Function to update labels of text fields
	// Text based inputs
	var inputSelector = 'input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=number], input[type=search], textarea';

	// Create the defaults once
	var pluginName = 'inputCmp';
	var defaults = {
		propertyName: 'value',
		wrapCls: 'input-cmp',
		wrapOnCls: 'input-cmp-on',
		labelCls: 'label',
		labelOnCls: 'label-on'
	};

	// The actual plugin constructor
	function InputCmp( element, options ) {
		this.element = element;

		// jQuery has an extend method that merges the
		// contents of two or more objects, storing the
		// result in the first object. The first object
		// is generally empty because we don't want to alter
		// the default options for future instances of the plugin
		this.options = $.extend( {}, defaults, options) ;

		this._defaults = defaults;
		this._name = pluginName;

		this.init();
	}

	InputCmp.prototype = {

		init: function() {
			var $el = $(this.element);
			var $parent = $el.closest('.' + this._defaults.wrapCls);
			var $label = $parent.find('.' + this._defaults.labelCls);
			var val = $el.val();

			if (val) {
				$label.addClass(this._defaults.labelOnCls);
			} else {
				$label.removeClass(this._defaults.labelOnCls);
			}
		}

	};

	// Handle HTML5 autofocus
	$('input[autofocus]').siblings('label, i').addClass('active');

	// document events delegation:

	var $doc = $(document);
	var fullInputSelector = '.' + defaults.wrapCls + ' ' + inputSelector;

	$doc
		.on('focus', fullInputSelector, function() {
			var $el = $(this);
			var $parent = $el.closest('.' + defaults.wrapCls);

			$parent.addClass(defaults.wrapOnCls);
		})
		.on('blur', fullInputSelector, function() {
			var $el = $(this);
			var $parent = $el.closest('.' + defaults.wrapCls);

			$parent.removeClass(defaults.wrapOnCls);
		})
		.on('input', fullInputSelector, function() {
			var $el = $(this);
			var val = $el.val();
			var $parent = $el.closest('.' + defaults.wrapCls);
			var $label = $parent.find('.' + defaults.labelCls);

			if (val) {
				$label.addClass(defaults.labelOnCls);
			} else {
				$label.removeClass(defaults.labelOnCls);
			}
		});
	// $(document).on('change', inputSelector, function () {
	// 	if ($(this).val().length !== 0 || $(this).attr('placeholder') !== undefined) {
	// 		$(this).siblings('label').addClass('active');
	// 	}
	// });

	// // Add active when element has focus
	// $(document).on('focus', inputSelector, function () {
	// 	$(this).siblings('label').addClass('active');
	// 	$(this).siblings('hr').addClass('bar-bottom-on');
	// 	$(this).siblings('hr').removeClass('bar-bottom-off');


	// });

	// $(document).on('blur', inputSelector, function () {
	// 	var $input = $(this);
	// 	if ($input.val().length === 0 && $input[0].validity.badInput !== true && $input.attr('placeholder') === undefined) {
	// 		$input.siblings('label, i').removeClass('active');
	// 	}
	// });

	// $(document).on('blur', 'input', function () {
	// 	var $document = $(this);
	// 	$document.siblings('hr').addClass('bar-bottom-off');
	// });



	// A really lightweight plugin wrapper around the constructor,
	// preventing against multiple instantiations
	$.fn[pluginName] = function ( options ) {
		return this.each(function () {
			if (!$.data(this, 'plugin_' + pluginName)) {
				$.data(this, 'plugin_' + pluginName,
				new InputCmp( this, options ));
			}
		});
	};

	//auto activation
	$(function() {
		$(inputSelector).inputCmp();
	});

})( jQuery, window, document );
