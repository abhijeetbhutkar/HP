'use strict';

(function ( $, window, document, undefined ) {
	// Function to update labels of text fields
	// Text based inputs
	// var inputSelector = 'input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=number], input[type=search], textarea';

	// Create the defaults once
	var pluginName = 'inputField';
	var defaults = {
		propertyName: 'value'
	};

	// The actual plugin constructor
	function InputField( element, options ) {
		this.element = element;

		// jQuery has an extend method that merges the
		// contents of two or more objects, storing the
		// result in the first object. The first object
		// is generally empty because we don't want to alter
		// the default options for future instances of the plugin
		this.options = $.extend( {}, defaults, options) ;

		this._defaults = defaults;
		this._name = pluginName;

		this.init();
	}

	InputField.prototype = {

		init: function() {
			var $element = $(this.element);
			if ($element.val().length > 0 || $element.attr('placeholder') !== undefined || $element[0].validity.badInput === true) {
				$element.siblings('label').addClass('active');
			}
			else {
				$element.siblings('label, i').removeClass('active');
			}
		}

	};

	// Handle HTML5 autofocus
	// $('input[autofocus]').siblings('label, i').addClass('active');

	// // document events delegation:

	// // Add active if form auto complete
	// $(document).on('change', inputSelector, function () {
	// 	if ($(this).val().length !== 0 || $(this).attr('placeholder') !== undefined) {
	// 		$(this).siblings('label').addClass('active');
	// 	}
	// });

	// // Add active when element has focus
	// $(document).on('focus', inputSelector, function () {
	// 	$(this).siblings('label').addClass('active');
	// 	$(this).siblings('hr').addClass('bar-bottom-on');
	// 	$(this).siblings('hr').removeClass('bar-bottom-off');


	// });

	// $(document).on('blur', inputSelector, function () {
	// 	var $input = $(this);
	// 	if ($input.val().length === 0 && $input[0].validity.badInput !== true && $input.attr('placeholder') === undefined) {
	// 		$input.siblings('label, i').removeClass('active');
	// 	}
	// });

	// $(document).on('blur', 'input', function () {
	// 	var $document = $(this);
	// 	$document.siblings('hr').addClass('bar-bottom-off');
	// });



	// A really lightweight plugin wrapper around the constructor,
	// preventing against multiple instantiations
	$.fn[pluginName] = function ( options ) {
		return this.each(function () {
			if (!$.data(this, 'plugin_' + pluginName)) {
				$.data(this, 'plugin_' + pluginName,
				new InputField( this, options ));
			}
		});
	};

	//auto activation
	$(function() {
		// $(inputSelector).inputField();
	});

})( jQuery, window, document );
