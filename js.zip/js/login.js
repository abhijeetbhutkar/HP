/*global MFPInit, $, WL, moment, _, ServiceProvider */

/**
 * notes: MFPInit, onDeviceReady
 * alert, Fastclick,
 * window.completeStep2,
 * messengerUrl;
 * callSecureLogin1, callSecureLogin2
 **/

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-34667158-1']);
_gaq.push(['_trackPageview']);

var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

//vizuryTagFire('VIZVRM4526');              
var onMFPInit = null;
var loginBtnDisable = null;
var Login = (
    function () {
        function run($) {
            'use strict';
            $ = jQuery; // FIXME: hot fix for lazy load bundle js
            var loginType = '';
            var loadingIcon = $('.preloader');
            var uniqueDeviceId;
            var deviceType;
            var deviceName;
            var modelName;
            var appVersion;
            var configVersion;
            var appName;
            var deviceManufacturer;
            var osVersion;
            var XAuthId;
            var freshInstall = true;
            var messengerUrl = 'messenger/index.html';
            var _config = {};
            var initOptions = {};
            var $body = jQuery('body');
            var DashboardPageUrl = 'dashboard.html#/dashboard';
            var self = this;

            var analyticId = null;
            var jailbrokenValue = false;

            var faId = null;
            var faGrpId = null;
            var questionId = null;
            var faErrorCode = null;
            var faErrorMessage = null;

            var LocatorConfigVer = '1.0.0';
            var TransactionConfigVer = '1.0.0';
            var LocalBankConfigVer = '1.0.0';

            var encryptedUserCredintialSession = null;
            var credintialType = null;

            var touchActivationFlow = false;
            var msgerActivationFlow = false;
            var quickActivationFlow = false;

            window.footerYear = new Date().getFullYear().toString();
            console.log('>>>window.footerYear: ', window.footerYear);

            var isIos = /iPad|iPhone|iPod/.test(navigator.userAgent);
            if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > 0) {
                console.log("Am IE browser");

                if (document.all && !document.addEventListener) {
                    console.log(" Am IE 8 or older");
                    alert("Browser not supported.");
                }
            }

            loadingIcon.fadeIn();

            var quickstartHtml = $('select.quickstart').html();
            var secureWord = $('#secure-img');
            if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
                $body.addClass('mobile');
                //add quick start mobile with quick balance option
                //  $('select.quickstart').html($('#mobile-quickstart').html() + quickstartHtml);
                $('select.quickstart').html($('#desktop-quickstart').html() + quickstartHtml);
            } else {
                //add quick start mobile without quick balance
                $('select.quickstart').html($('#desktop-quickstart').html() + quickstartHtml);
            }

            var formStep1 = $('#login-form-step1');
            var formStep2 = $('#form-login_step2');
            var formStep3 = $('#form-login_step3');
            var validateOpt = {
                errorElement: 'div',
                messages: {
                    username: {
                        required: 'CIMB Clicks ID is mandatory',
                        minlength: 'Please enter at least 6 characters'
                    },

                    password: {
                        required: 'This field is required',
                        minlength: 'Please enter at least 8 characters'
                    },

                    fatext: {
                        required: 'This field is required'
                    }
                }
            }
            formStep1.validate(validateOpt);
            formStep2.validate(validateOpt);
            formStep3.validate(validateOpt);
            var usn = $('#user-id');
            var pas = $('#password');
            var faanswer = $('#fatext');
            var serviceActivation = $('.mobile .service-activation');
            var serviceActivationClose = serviceActivation.find('.back-btn, .close-service');
            var serviceQuickBalance = serviceActivation.find('.quick-balance');
            var serviceTac = serviceActivation.find('.tac-verification');
            var serviceTouchId = serviceActivation.find('.touch-id-verification');
            var serviceTouchIdLogin = serviceActivation.find('.touch-id-login');
            var serviceTacMobile = serviceActivation.find('.tac-on-mobile');
            var serviceTacGen = serviceActivation.find('.tac-generator');
            var warningBlock = $('.js-system-warning-block');
            var loginTimes = 0;
            var isMobile = /Mobile/.test(navigator.userAgent);

            $('.js-help-support-title').hide();

            var aboutUsPage = serviceActivation.find('.js-about-us-container');

            // localStorage.setItem('showFirstTimeLogin', true);

            var userProfile = [];
            var currentState = '';
            //for fixing issue: keyboard overlap textinput
            var $targetElement = null;

            //======= Vivian Added ======//
            var cookiesData = document.cookie;
            console.log('cookiesData: ', cookiesData);
            self.websiteCookiesData = cookiesData;
            //===========================//

            $('.main-content, .main-content .header').css({ 'padding-top': warningBlock.outerHeight() });

            warningBlock.find('.icon-close').on('click', function () {
                $(this).parent().fadeOut();
                $('.main-content, .main-content .header').css({ 'padding-top': '0' });
            });

            var showConfirmation = function (tl, msg, yesCb, noCb, isOneButton, yesLabel, noLabel) {
                console.log("showConfirmation", yesLabel);
                var md;
                // if (window.innerWidth >= 768) {
                    md = $('#modal-confirm-desktop');
                // } else {
                //     md = $('#modal-confirm-mobile');
                // }

                md.find('#header h1').text(tl);
                md.find('#content p').html(msg);

                if (yesLabel) {
                    md.find('.btn-yes').text(yesLabel);
                }
                if (noLabel) {
                    md.find('.btn-no').text(noLabel);
                }

                md.fadeIn();

                md.find('.btn-yes').on('click', function () {
                    md.fadeOut();
                    md.find('.btn-yes').off('click');
                    md.find('.btn-no').off('click');
                    if (typeof yesCb === 'function') {
                        yesCb();
                    }
                });

                md.find('.btn-no').on('click', function () {
                    md.fadeOut();
                    md.find('.btn-yes').off('click');
                    md.find('.btn-no').off('click');
                    if (typeof noCb === 'function') {
                        noCb();
                    }
                });

                if (isOneButton) {
                    md.find('.btn-yes').addClass('btn-full');
                    md.find('.btn-no').hide();
                } else {
                    md.find('.btn-yes').removeClass('btn-full');
                    md.find('.btn-no').show();
                }

                md.find('.btn-yes').focus(); //RegressionIssue #6810 (Vivian Added)
            };

            var isQuickBalanceRegister = function (user) {
                //Apply logic to get account register Quick Balance on page
                // this is just Simple switch new user as unregister quick balance.
                if (user === 'new_user') {
                    return false;
                }
                return false;
            };

            var showService = function (service) {
                serviceActivation.find('.activate').fadeOut(function () {
                    service.fadeIn();
                });
            };


            //go through messenger activation
            window.activateMessenger = function (action, data) {
                console.log('Notification Trigger this Messenger Activation');

            };


            var validateForm = function (FormObj, FormObj2, FormObj3) {
                var validate = FormObj.valid();
                var validateUsername = function () {
                    //Verifying username and get Secure word
                    console.log('trigger loading status & verify username');
                    self.showLoading();
                    //localStorage.setItem('userSession', usn.val());
                    if (localStorage.getItem('activateSession')) {
                        localStorage.removeItem('activateSession');
                    }
                    
                    if(self.enableGoogleCaptcha){
                        try {
                            if (typeof grecaptcha !== 'undefined'){ 
                                if(grecaptcha && grecaptcha.getResponse() == ""){
                                    grecaptcha.execute();
                                    self.hideLoading();
                                    console.log('stopped');
                                    return false;
                                }else{
                                    console.log('login');
                                    callSecureLogin1(usn.val(), 'normal');
                                }  
                            }else{
                                console.log('login');
                                callSecureLogin1(usn.val(), 'normal');
                            } 
                        } catch (err) {
                            console.log(err+ 'login catch');
                            callSecureLogin1(usn.val(), 'normal');
                        }                                            
                    }else{
                        console.log('legacy login');
                        callSecureLogin1(usn.val(), 'normal');
                    }

                    //callSecureLogin1(usn.val(), 'normal');
                };

				/*
					Verifying username and password
				 */
                var verifyData = function () {
                    self.showLoading();
                    callSecureLogin2(analyticId, pas.val(), null);
                };

                var verifyFA = function () {
                    self.showLoading();
                    callFA(analyticId, pas.val());
                };

                if (!validate) {
                    return validate;
                }

                if (FormObj3 != null) {
                    verifyFA();
                } else if (!FormObj2) {
                    verifyData();
                } else {
                    validateUsername();
                }

                // if (!FormObj2 && !FormObj3) {
                //     verifyData();
                // } else if (FormObj && !FormObj3) {
                //     validateUsername();
                // }

                console.log('returning validate', validate);

                return validate;
            };

            var nextForm = function ($FormObj) {
                $FormObj.fadeIn();
            };

            function showDowntimeTemplate(data) {
                console.log('Pre Login Downtime Data', data)
                self.downtime(data);
                /*var downtimeScreen = $('#down-time-teplate');
                var downtimeTitle = $('.downtime-title-text');
                var downtimeFrom = $('.downtime-from-time');
                var downtimeTo = $('.downtime-to-time');
                var downtimeMsg = $('.downtime-msg-text');

                $(downtimeScreen).show();
                $(downtimeTitle).text(data.title);
                $(downtimeFrom).text(moment(data.startDateTime).format('DD MMM YYYY, hh:mm:ss A'));
                $(downtimeTo).text(moment(data.endDateTime).format('DD MMM YYYY, hh:mm:ss A'));
                $(downtimeMsg).text(data.message);*/

            }

            function aa() {
                // Adobe Analytics
                window.clearDigitalData();
                digitalData.page = {
                    pageInfo: {
                        pageName: "web:Pre-loginPage"
                    },
                    category: {
                        pageType: "input",
                        primaryCategory: "LoginModule",
                        subCategory1: "Pre-login",
                        subCategory2: "",
                        subCategory3: ""
                    }
                };
                digitalData.user = {
                    loginStatus: "not logged-in"
                };
            }

            function isMobileDevice(){
                //Checking only phone, not including tablet
		        //This function is mainly use to differentiate between phone and tablet
                var check = false;
                (function (a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true; })(navigator.userAgent || navigator.vendor);
                return check;
            }

			/**
			 * Toggle screens for "Update Available", Update Available with Skip", "Device Rooted", "Device Jailbroken", "Hide All".
			 *
			 * @param {string} screenType - Screen type should be
			 * - UPDATE_AVAILABLE
			 * - UPDATE_AVAILABLE_SKIP
			 * - DEVICE_ROOTED
			 * - DEVICE_JAILBROKEN
			 * - HIDE_ALL
			 * - GET_STARTED
			 *
			 * @returns {undefined} - Nothing is returned
		     */
            function togglePreLoginScreen(screenType) {
                var octoScreen = $('#octo-screen');
                var octoGrayMobile = $('.octo-gray-mobile');
                var octoGrayWink = $('.octo-gray-wink');
                var octoTitle = $('.octo-title');
                var octoDescription = $('.octo-description');
                var octoButtonText = $('.octo-button-text');
                var progressBar = $('.update-progressbar');
                var octoButton = $('.octo-button');
                var octoLinkSkipContainer = $('.octo-link-skip-container');
                var octoLinkSkip = $('.octo-link-skip');

                var btnClose = octoScreen.find('.btn-close');

                //$(octoLinkSkip).click(skip);
                currentState = screenType;
                console.log('>>>>>>>>>>>>>>>>', currentState, screenType);
                btnClose.hide();

                if (screenType === 'HIDE_ALL') {
                    $(octoScreen).hide();
                    $('.login-wrapper').show();
                    $('.js-get-started-container').hide();
                }/* else if (screenType === 'GET_STARTED') {
                    $('.login-wrapper').hide();
                    $(progressBar).hide();
                    $('.js-get-started-container').show();
                }*/ else if (screenType === 'INIT_FAIL') {
                    $(octoScreen).show();
                    $(octoGrayMobile).show();
                    $(octoGrayWink).hide();
                    $(progressBar).hide();
                    $(octoLinkSkipContainer).hide();
                    $(octoTitle).text('Fail To Load');
                    $(octoDescription).text('We have failed to load this page. Please check your connection and try again.');
                    $(octoButtonText).text('Try Again');
                }
            }

            function initSideBar() {
                var $loginWraper = $('.login-wrapper');

                var removeEvent = function () {
                    $body.off('click', '.js-sidebar-overlay-slide');
                };

                var toggleSideBar = function () {
                    var openCls = 'sidebar-open';
                    var $sidebarElement = $('.login-wrapper .sidebar-login');

                    if ($sidebarElement.hasClass(openCls)) {
                        $sidebarElement.removeClass(openCls);
                        document.body.classList.remove('sidebar-open');
                    } else {
                        $sidebarElement.addClass(openCls);
                        document.body.classList.add('sidebar-open');
                    }
                };

                var getSidebarStatus = function () {
                    return $('.login-wrapper .sidebar-login').hasClass('sidebar-open');
                };

                $loginWraper.off().on('click', '.navbar-toggle', function () {
                    // var openCls = 'sidebar-open';

                    // toggle the sidebar
                    toggleSideBar();

                    if (getSidebarStatus()) {
                        $body.on('click', '.js-sidebar-overlay-slide', function (e) {
                            e.preventDefault();
                            e.stopPropagation();

                            toggleSideBar();
                            removeEvent();
                        }.bind(this));
                    } else {
                        removeEvent();
                    }
                });

                $loginWraper.on('click', '.menu-items .clickable', function () {
                    $('li').removeClass('active');
                    $(this).parent().addClass('active');
                    toggleSideBar();
                    removeEvent();
                });
            }

            // Secure Login Step 1--------------------
            function callSecureLogin1(username, type) {
                onMFPInit();
                console.log("login _gaq", _gaq);
                //pixel.parse(pixel.getSHA256(username));              
                console.log('param: ', self.queryParams, 'username Step1: ', username, self.fromEPayment);
                var encryptedUsername = null;
                var timeStamp = getCurrentTime();
                var requestBody = null;
                var refId;
                

                if (type === 'touch') {
                    encryptedUsername = MFPInit.aesEncyption(uniqueDeviceId, timeStamp, username);
                    requestBody = {
                        'requestHeader': {
                            'channelTime': timeStamp,
                            'deviceId': uniqueDeviceId
                        },
                        'requestBody': {
                            'deviceKey': encryptedUsername,
                            'grant_type': 'ibs_credential'
                        }
                    };
                }
                else {
                    encryptedUsername = MFPInit.encryptMY(username);
                    requestBody = {
                        'requestHeader': {
                            'channelTime': timeStamp,
                            'deviceId': uniqueDeviceId
                        },
                        'requestBody': {
                            'username': encryptedUsername,
                            'grant_type': 'ibs_credential'
                        }
                    };
                }               
                //requestBody.requestBody.google_reCaptha_generatedKey = self.google_reCaptha_generatedKey;
                //console.log('added Google capctha = '+ self.google_reCaptha_generatedKey)
                var hashKey = window.hashKeyValue;
                var requestBodyString = JSON.stringify(requestBody);
                var hashMac = MFPInit.getHashMAC(requestBodyString, hashKey, timeStamp);
                var authorizationKey = _config.authorizationKey;

                if (self.fromEPayment) {
                    authorizationKey = _config.authorizationKeyEP;
                } else if (self.fromFPX) {
                    authorizationKey = _config.authorizationKeyFPX;
                }

                var requestHeader;
                if (self.fromFPX) {
                    refId = self.queryParams["refId"];
                    console.log('refId', refId);
                    requestHeader = { Authorization: authorizationKey, ChannelAuthCode: hashMac, FpxRefId: refId };
                    console.log('requestHeader', requestHeader);
                } else {
                    requestHeader = { Authorization: authorizationKey, ChannelAuthCode: hashMac };
                    console.log('requestHeader', requestHeader);
                }
                console.log("login step 1 call service provider")
                ServiceProvider.ServiceHub.getDataByService(ServiceProvider.ServiceType.SERVICE_LOGIN_STEP1, [requestHeader, requestBodyString], {},
                    loginStep1Success, loginStep1Failure);
            }

            function loginStep1Success(result, type) {
                onMFPInit();
                //$('.googleCapthaCls').removeAttr("disabled");
                if (type && type === 'DOWNTIME') {
                    showDowntimeTemplate(result.downTime);
                } else {
                    XAuthId = result.authId;
                    analyticId = result.analyticId;

                    var imgType = 'data:image/png;base64,';
                    secureWord.attr('src', imgType + result.secureWord);
                    formStep1.animate({ opacity: 0 }, function () {
                        usn.blur();
                        formStep1.hide();
                        nextForm(formStep2);
                    });
                }
                self.hideLoading();
            }
            function loginStep1Failure(result) {
                onMFPInit();
                //$('.googleCapthaCls').removeAttr("disabled");
                console.log('Response Failed LoginStep1 : ', result);
                showConfirmation('Alert', result, null, null, true, 'OK');
                self.hideLoading();
            }

            window.completeStep2 = function () {
                $('.js_error_message').addClass('active-error');

                usn.val('').removeClass('valid').addClass('invalid error');
                pas.val('').removeClass('valid').addClass('invalid error');
                usn.prev('label.label-on').removeClass('label-on');

                formStep2
                    .css({ opacity: 1 })
                    .animate({ opacity: 0 }, function () {
                        $(this).hide();
                        nextForm(formStep1);
                        usn.blur();
                        $('div.error').remove();
                        loadingIcon.fadeOut();
                    });
            };

            function callFA(analyticID, password) {

                var facontext;

                if (faanswer.val() && faanswer.val() != '') {
                    facontext = {
                        "faGrpId": faGrpId,
                        "faId": faId,
                        "questionId": questionId,
                        "answer": faanswer.val()
                    }
                }

                console.log('param FA: ', faanswer.val());
                callSecureLogin2(analyticID, password, facontext);
                faanswer.val('');
                $('#fatext-error').hide();
            }

            // Secure Login Step 2---------------------------
            function callSecureLogin2(analyticID, password, facontext) {
                console.log('param: ', self.queryParams);

                var refId;

               //checking new password policy trim --rel18_a              
               var format = /[~!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;               
               if(format.test(password) && password.length >= 8){
                      password = password;
               }else{
                      password = password.substring(0, 8);
               }

                var encryptedPass = MFPInit.encryptMY(password);
                var timeStamp = getCurrentTime();

                if (localStorage.getItem('isJailbroken')) {
                    jailbrokenValue = localStorage.getItem('isJailbroken');
                }

                var requestBody = {
                    'requestHeader': {
                        'channelTime': timeStamp,
                        'deviceId': uniqueDeviceId
                    },
                    'requestBody': {
                        'authId': XAuthId,
                        'password': encryptedPass,
                        'jailbroken': jailbrokenValue,
                        'appId': appName,
                        'appVersion': appVersion,
                        'deviceType': deviceType,
                        'deviceName': deviceName,
                        'modelName': modelName,
                        'osVersion': osVersion,
                        "faContextBO": facontext,
                        'deviceManufacturer': deviceManufacturer,
                        'grant_type': 'ibs_credential'
                    }
                };
                console.log('requestbody Step2 ', requestBody);

                var hashKey = window.hashKeyValue;
                var requestBodyString = JSON.stringify(requestBody);
                var hashMac = MFPInit.getHashMAC(requestBodyString, hashKey, timeStamp);
                var authorizationKey = _config.authorizationKey;

                if (self.fromEPayment) {
                    authorizationKey = _config.authorizationKeyEP;
                } else if (self.fromFPX) {
                    authorizationKey = _config.authorizationKeyFPX;
                }

                var requestHeader;
                if (self.fromFPX) {
                    refId = self.queryParams["refId"];
                    console.log('refId', refId);
                    requestHeader = { Authorization: authorizationKey, ChannelAuthCode: hashMac, FpxRefId: refId };
                    console.log('requestHeader', requestHeader);
                } else {
                    requestHeader = { Authorization: authorizationKey, ChannelAuthCode: hashMac };
                    console.log('requestHeader', requestHeader);
                }
               
                var userEnquirySuccess = function (result) {

                    console.log('USER Enquiry Data', result);

                    var userEnquriyData = {
                        'displayName': result.displayName,
                        'preferredName': result.preferredName,
                        'nadRegistered': result.nadRegistered,
                        'lastLogin': result.lastLogin,
                        'deviceFTLFlag': result.device ? result.device.deviceFTLFlag : false,
                        'firstTimeLogin': result.firstTimeLogin ? result.firstTimeLogin : false,
                        'custSegment': result.custSegment,
                        'deviceSettingKey': result.device ? result.device.deviceSettingKey : '',
                        'deviceSettingStatus': result.device ? result.device.deviceSettingStatus : '',
                        'cardReplacementSetup': result.userPrerequisite ? result.userPrerequisite.cardReplacementSetup : null,
                        'irSecurityQuestion': result.userPrerequisite ? result.userPrerequisite.irSecurityQuestion : false,
                        'vaSecurityQuestion': result.userPrerequisite ? result.userPrerequisite.vaSecurityQuestion : false,
                        'termConditions': result.userPrerequisite ? result.userPrerequisite.termConditions : false,
                        'userAcqCampaignBannerList': result.userAcqCampaignBannerList,
                        //'irSecurityQuestion': true,
                        //'vaSecurityQuestion': false
                        //'termConditions': false
                    };
                   
                    //cardReplacement redirectUrl 
                    if (userEnquriyData.cardReplacementSetup) {
                        var redirectUrl = '#/card-replacement';
                        window.location.href = redirectUrl;
                    }

                    //Get CmID and CmPassword from deviceSettingInfo
                    if (result.device && result.device.deviceSettingKey) {
                        if (result.device.deviceSettingKey.touchIdSecretKey) {
                            localStorage.setItem('deviceKey', result.device.deviceSettingKey.touchIdSecretKey);
                        }

                        if (result.device.deviceSettingKey.cmId) {
                            localStorage.setItem('cmId', result.device.deviceSettingKey.cmId);
                        } else {
                            if (localStorage.getItem('cmId'))
                                localStorage.removeItem('cmId');
                        }

                        if (result.device.deviceSettingKey.cmPassword) {
                            localStorage.setItem('cmPass', result.device.deviceSettingKey.cmPassword);
                        } else {
                            if (localStorage.getItem('cmPass'))
                                localStorage.removeItem('cmPass');
                        }

                    } else {
                        if (localStorage.getItem('cmId'))
                            localStorage.removeItem('cmId');

                        if (localStorage.getItem('cmPass'))
                            localStorage.removeItem('cmPass');
                    }
                    
                    localStorage.setItem('userEnquiry', JSON.stringify(userEnquriyData));
                    console.log("nadRegistered>>>", localStorage.getItem('userEnquiry'));
                    localStorage.setItem('appState', 'PostLogin');
                    var selectedOption = $('select.quickstart').val();
                    localStorage.setItem('loginSelectedOption', selectedOption);
                    //go to the page user selected in dropdown
                    console.log('This is selected option from dropdown', selectedOption);
                    
                    //check for customer segmentation
                    if (userEnquriyData.custSegment) {
                        var teenFound = false;
                        var vaOnly = false;
                        var NTBLazOnly = false;

                        for (var i = 0; i < userEnquriyData.custSegment.length; i++) {

                           
                            if (userEnquriyData.custSegment[i] === 'T') {
                                teenFound = true;
                            }
                            else if (userEnquriyData.custSegment[i] === 'L') {
                                vaOnly = true;
                            }
                            else if (userEnquriyData.custSegment[i] === 'Z') {
                                NTBLazOnly = true;
                            }
                        }

                        console.log("teenFound", teenFound);
                        console.log("vaOnly", vaOnly);
                        console.log("NTBLazOnly", NTBLazOnly);

                        console.log('selectedOption', selectedOption);

                        if (teenFound && vaOnly && NTBLazOnly) {
                            if (selectedOption === 'dashboard') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'NV') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'JP') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'CA') {
                                self.changePage('overview');
                            }
                            else {
                                self.changePage(selectedOption);
                            }
                        }
                        else if (teenFound && vaOnly){
                            if (selectedOption === 'dashboard') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'NV') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'JP') {
                                self.changePage('overview');
                            }
                            else {
                                self.changePage(selectedOption);
                            }
                        }
                        else if(teenFound && NTBLazOnly){
                            if (selectedOption === 'NV') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'JP') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'CA') {
                                self.changePage('overview');
                            }
                            else {
                                self.changePage(selectedOption);
                            }
                        }
                        else if(vaOnly && NTBLazOnly){
                            if (selectedOption === 'dashboard') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'CA') {
                                self.changePage('overview');
                            }
                            else {
                                self.changePage(selectedOption);
                            }
                        }
                        else if (teenFound){
                            //teen cant go to paybill
                            if (selectedOption === 'NV') {
                                self.changePage('overview');
                            }
                            else if (selectedOption === 'JP') {
                                self.changePage('overview');
                            }
                            else {
                                self.changePage(selectedOption);
                            }
                        }
                        else if(vaOnly){
                            if (selectedOption === 'dashboard') {
                                self.changePage('overview');
                            }
                            else {
                                self.changePage(selectedOption);
                            }
                        }
                        else if(NTBLazOnly){
                            //NTBLazOnly cant go to Transfer Money
                            if (selectedOption === 'CA' || selectedOption === 'dashboard') {
                                self.changePage('overview');
                            }
                            else {
                                self.changePage(selectedOption);
                            }
                        }
                        else {
                            console.log('customer segment is not teen');
                            self.changePage(selectedOption);
                        }
                    }
                    else {
                        console.log('we dont have customer segmentation');
                        self.changePage(selectedOption);
                    }

                    // Adobe Analytics Tracking
                    // overview, quickbalance, CA, NV, JP, topUp
                    var loginOptionSelect = null;
                    switch (selectedOption) {
                        case 'overview':
                            loginOptionSelect = 'View My Accounts';
                            break;
                        case 'dashboard':
                            loginOptionSelect = 'View My Dashboard';
                            break;
                        case 'NV':
                            loginOptionSelect = 'Pay Bills';
                            break;
                        case 'CA':
                            loginOptionSelect = 'Transfer Money';
                            break;
                        case 'JP':
                            loginOptionSelect = 'JomPAY';
                            break;
                        case 'OR':
                            loginOptionSelect = 'Pay Loans and Cards';
                            break;
                        case 'topUp':
                            loginOptionSelect = 'Top Up';
                            break;
                        default:
                            loginOptionSelect = 'View My Dashboard';
                            break;
                    }
                    if (!digitalData.user) digitalData.user = {};
                    digitalData.user.loginStatus = "logged-in";
                    if (!digitalData.user.loginType) digitalData.user.loginType = 'user id';
                    digitalData.user.memberLoginType = result.firstTimeLogin === true ? 'first time login' : 'repeat';
                    digitalData.user.loginOptionSelect = loginOptionSelect;
                    digitalData.user.customerStatus = result.device && result.device.deviceSettingKey ? 'owner' : 'guest';
                    digitalData.user.profile = {
                        profileInfo: {
                            customerID: analyticID ? analyticID : ''
                        }
                    };
                    if (typeof _satellite != 'undefined') {
                        _satellite.track('web:successful login');
                        console.log('Adobe Analytics Tracking: web:successful login');
                    }
                };

                var userEnquiryFailure = function (result) {
                    self.hideLoading();
                    console.log('User Enquiry Failed : ', result);
                    failHandler(result);
                };

                // AuthRealmChallengeHandler.submitAdapterAuthentication(invocationData, {});
                var successHandler = function (response, type) {
                    //Check for downtime exception
                    if (type && type === 'DOWNTIME') {
                        showDowntimeTemplate(response.downTime);
                        self.hideLoading();
                    }
                    else {
                        //we submit the success as authentication has been done
                        //ServiceProvider.ServiceHub.submitSuccess();
                        console.log('Secure 2 response', response);
                        //Start the interval for timeout
                        // var currentTime = moment().toISOString();
                        var currentTime = response.array ? response.array.expires_in || response.expires_in : response.expires_in; //real || mock : mock
                        startCheckingTimeOut(currentTime);
                        startIdleTimeout();


                        //Call User Enquiry Service
                        if (localStorage.getItem('freshInstall')) {
                            freshInstall = localStorage.getItem('freshInstall');
                        }

                        localStorage.setItem('LoginType', 'normal');
                        console.log('User Enquiry Request Data', uniqueDeviceId + freshInstall);
                        ServiceProvider.ServiceHub.getDataByService(ServiceProvider.ServiceType.SERVICE_USER_INFO, [uniqueDeviceId, freshInstall], {}, userEnquirySuccess, userEnquiryFailure);

                    }
                };

                var failHandler = function (error) {
                    self.hideLoading();

                    var needRedirectUser = false;
                    var redirectLocation = '';
                    var errorMsg = error;

                    if (typeof error == 'object') {
                        var errorCode = error['error'];
                        var errorDesc = error['error_description'];
                        errorMsg = errorDesc + ' [' + errorCode + ']';

                        if (error['data']) {
                            if (error['data']['location']) {
                                needRedirectUser = true;
                                redirectLocation = error['data']['location'];
                            }
                        }
                    }

                    console.log('error.faGrpId', error);

                    if (error.faGrpId) {

                        faId = error.faId;
                        faGrpId = error.faGrpId;
                        questionId = error.questionId;
                        faErrorCode = "";
                        faErrorMessage = "";
                        
                        if(error.errorCode){
                            faErrorCode = error.errorCode;
                        }

                        if(error.errorMessage){
                            faErrorMessage = error.errorMessage;
                        }

                        console.log('faErrorCode', faErrorCode);
                        console.log('faErrorMessage', faErrorMessage);

                        var question = $('#faquestion');
                        $("#faquestion").html(error.question);
                        $("#faErrorText").html(faErrorMessage + ' ' + faErrorCode);

                        console.log('showing fa page');
                        formStep2.fadeOut(function () {
                            nextForm(formStep3);
                        });

                    }
                    else {

                        showConfirmation('Alert', errorMsg, function () {
                            formStep1.find('.text-error').hide();
                            formStep1.find('.js_error_message').addClass('active-error');
                            usn.val('').removeClass('valid').addClass('invalid error');
                            pas.val('').removeClass('valid').addClass('invalid error');
                            formStep1.find('label').removeClass('label-on');
                            formStep2.find('label').removeClass('label-on');

                            if (needRedirectUser) {
                             //   if (!isMobile) {
                                    if (redirectLocation == 'FORGOT_ID_PASSWORD') {
                                        // UAT 1629
                                        //ePayment and FPX Login using Suspended ID after hit error after click Ok button 
                                        //should does not route to Forgot User Name and Password Page as this only apply for Clicks Web
                                        if (!self.fromFPX && !self.fromEPayment) {
                                            var redirectUrl = '#/forgot-pass';
                                            window.location.href = redirectUrl;
                                        } else {
                                            formStep2.fadeOut(function () {
                                                formStep3.hide(); //make sure formStep3 is hide
                                                nextForm(formStep1);
                                            })
                                        }

                                    } else if (redirectLocation == 'CARD_REPLACEMENT') {
                                        var redirectUrl = '#/card-replacement';
                                        window.location.href = redirectUrl;
                                    }else if (redirectLocation == 'USER_NOT_IN_WHITELIST') { //PILOT STAGE
                                        window.location.href = "https://10.104.88.105/ibk/";
                                    }		                                   
	                           // } 

                                    }else{
                                           formStep2.fadeOut(function () {
                                    formStep3.hide(); //make sure formStep3 is hide
                                    nextForm(formStep1);
                                    aa();
                                })
                                    }
                             
                        }, function () {

                        }, true, 'OK');
                    }

                    // Adobe Analytics Tracking
                    window.clearDigitalData();
                    digitalData.errorPage = {
                        interactionScreenName: ServiceProvider.SecureServiceType.SERVICE_SECURE_LOGIN_STEP2,
                        customErrorCode: error.error
                    };
                    if (typeof _satellite != 'undefined') {
                        _satellite.track('web:custom error');
                        console.log('Adobe Analytics Tracking: web:custom error');
                    }
                    //window.completeStep2();
                    MFPInit.logoutUser({});
                };
                //MFPInit.submitAdapterAuthentication(responseHHandler, invocationData);

                ServiceProvider.ServiceHub.getDataByService(ServiceProvider.SecureServiceType.SERVICE_SECURE_LOGIN_STEP2, [analyticID, requestHeader, requestBodyString], {}, successHandler, failHandler);

                // if (password.length < 8 || password.length > 8) {
                //     showConfirmation('Alert', 'Password must contain 8 characters.', null, null, true);

                //     self.hideLoading();
                // } else {
                //     var encryptedPass = MFPInit.encryptMY(password);
                //     var timeStamp = getCurrentTime();

                //     if (localStorage.getItem('isJailbroken')) {
                //         jailbrokenValue = localStorage.getItem('isJailbroken');
                //     }

                //     var requestBody = {
                //         'requestHeader': {
                //             'channelTime': timeStamp,
                //             'deviceId': uniqueDeviceId
                //         },
                //         'requestBody': {
                //             'authId': XAuthId,
                //             'password': encryptedPass,
                //             'jailbroken': jailbrokenValue,
                //             'appId': appName,
                //             'appVersion': appVersion,
                //             'deviceType': deviceType,
                //             'deviceName': deviceName,
                //             'modelName': modelName,
                //             'osVersion': osVersion,
                //             'deviceManufacturer': deviceManufacturer,
                //             'grant_type': 'ibs_credential'
                //         }
                //     };
                //     console.log('requestbody Step2 ', requestBody);

                //     var hashKey = window.hashKeyValue;
                //     var requestBodyString = JSON.stringify(requestBody);
                //     var hashMac = MFPInit.getHashMAC(requestBodyString, hashKey, timeStamp);
                //     var authorizationKey = _config.authorizationKey;

                //     if (self.fromEPayment) {
                //         authorizationKey = _config.authorizationKeyEP;
                //     } else if (self.fromFPX) {
                //         authorizationKey = _config.authorizationKeyFPX;
                //     }

                //     var requestHeader;
                //     if (self.fromFPX) {
                //         refId = self.queryParams["refId"];
                //         console.log('refId', refId);
                //         requestHeader = { Authorization: authorizationKey, ChannelAuthCode: hashMac, FpxRefId: refId };
                //         console.log('requestHeader', requestHeader);
                //     } else {
                //         requestHeader = { Authorization: authorizationKey, ChannelAuthCode: hashMac };
                //         console.log('requestHeader', requestHeader);
                //     }

                //     var userEnquirySuccess = function (result) {
                //         console.log('USER Enquiry Data', result);

                //         var userEnquriyData = {
                //             'displayName': result.displayName,
                //             'lastLogin': result.lastLogin,
                //             'deviceFTLFlag': result.device ? result.device.deviceFTLFlag : false,
                //             'custSegment': result.custSegment,
                //             'deviceSettingKey': result.device ? result.device.deviceSettingKey : '',
                //             'deviceSettingStatus': result.device ? result.device.deviceSettingStatus : ''
                //         };

                //         //Get CmID and CmPassword from deviceSettingInfo
                //         if (result.device && result.device.deviceSettingKey) {
                //             if (result.device.deviceSettingKey.touchIdSecretKey) {
                //                 localStorage.setItem('deviceKey', result.device.deviceSettingKey.touchIdSecretKey);
                //             }

                //             if (result.device.deviceSettingKey.cmId) {
                //                 localStorage.setItem('cmId', result.device.deviceSettingKey.cmId);
                //             } else {
                //                 if (localStorage.getItem('cmId'))
                //                     localStorage.removeItem('cmId');
                //             }

                //             if (result.device.deviceSettingKey.cmPassword) {
                //                 localStorage.setItem('cmPass', result.device.deviceSettingKey.cmPassword);
                //             } else {
                //                 if (localStorage.getItem('cmPass'))
                //                     localStorage.removeItem('cmPass');
                //             }

                //         } else {
                //             if (localStorage.getItem('cmId'))
                //                 localStorage.removeItem('cmId');

                //             if (localStorage.getItem('cmPass'))
                //                 localStorage.removeItem('cmPass');
                //         }

                //         localStorage.setItem('userEnquiry', JSON.stringify(userEnquriyData));

                //         localStorage.setItem('appState', 'PostLogin');
                //         var selectedOption = $('select.quickstart').val();
                //         //go to the page user selected in dropdown
                //         console.log('This is selected option from dropdown', selectedOption);

                //         //check for customer segmentation
                //         if (userEnquriyData.custSegment) {
                //             var teenFound = false;
                //             for (var i = 0; i < userEnquriyData.custSegment.length; i++) {
                //                 if (userEnquriyData.custSegment[i] === 'T') {
                //                     teenFound = true;
                //                     break;
                //                 }
                //             }

                //             if (teenFound) {
                //                 console.log('teen segment found ');
                //                 //teen cant go to paybill
                //                 if (selectedOption === 'NV') {
                //                     self.changePage('overview');
                //                 }
                //                 else {
                //                     self.changePage(selectedOption);
                //                 }
                //             }
                //             else {
                //                 console.log('customer segment is not teen');
                //                 self.changePage(selectedOption);
                //             }
                //         }
                //         else {
                //             console.log('we dont have customer segmentation');
                //             self.changePage(selectedOption);
                //         }
                //     };
                //     var userEnquiryFailure = function (result) {
                //         self.hideLoading();
                //         console.log('User Enquiry Failed : ', result);
                //         failHandler('Failed to login, Please try again.');
                //     };

                //     // AuthRealmChallengeHandler.submitAdapterAuthentication(invocationData, {});
                //     var successHandler = function (response, type) {
                //         //Check for downtime exception
                //         if (type && type === 'DOWNTIME') {
                //             showDowntimeTemplate(response.downTime);
                //             self.hideLoading();
                //         }
                //         else {
                //             //we submit the success as authentication has been done
                //             //ServiceProvider.ServiceHub.submitSuccess();

                //             //Start the interval for timeout
                //             var currentTime = moment().toISOString();
                //             startCheckingTimeOut(currentTime);
                //             startIdleTimeout();

                //             //Call User Enquiry Service
                //             if (localStorage.getItem('freshInstall')) {
                //                 freshInstall = localStorage.getItem('freshInstall');
                //             }

                //             localStorage.setItem('LoginType', 'normal');
                //             console.log('User Enquiry Request Data', uniqueDeviceId + freshInstall);
                //             ServiceProvider.ServiceHub.getDataByService(ServiceProvider.ServiceType.SERVICE_USER_INFO, [uniqueDeviceId, freshInstall], {}, userEnquirySuccess, userEnquiryFailure);

                //         }
                //     };

                //     var failHandler = function (error) {
                //         self.hideLoading();
                //         showConfirmation('Alert', error, function () {

                //             formStep1.find('.text-error').hide();
                //             formStep1.find('.js_error_message').addClass('active-error');
                //             usn.val('').removeClass('valid').addClass('invalid error');
                //             pas.val('').removeClass('valid').addClass('invalid error');
                //             formStep1.find('label').removeClass('label-on');
                //             formStep2.find('label').removeClass('label-on');

                //             formStep2.fadeOut(function () {
                //                 nextForm(formStep1);
                //             });
                //         }, function () {

                //         }, true);
                //         //window.completeStep2();
                //         MFPInit.logoutUser({});
                //     };
                //     //MFPInit.submitAdapterAuthentication(responseHHandler, invocationData);

                //     ServiceProvider.ServiceHub.getDataByService(ServiceProvider.SecureServiceType.SERVICE_SECURE_LOGIN_STEP2, [analyticID, requestHeader, requestBodyString], {}, successHandler, failHandler);
                // }

            }

            //TODO OTP Step 1 function ----------------------------------
            function callOtpLoginStep1(username, password) {
                var encryptedPass = MFPInit.encryptMY(password);
                var requestBody = {
                    'requestHeader': {
                        'channelAuthCode': 'HMACSTRING',
                        'channelTime': '2012-04-23T18:25:43.511Z',
                        'pageId': 'PAGEID',
                        'requestId': 'REQUESTUUIDSTRING',
                        'deviceId': 'DEVICEVENDORID'
                    },
                    'requestBody': {
                        'sessionString': 'SESSIONSTRING',
                        'username': username,
                        'password': encryptedPass,
                        'grant_type': 'ibs_credential'
                    }
                };

                ServiceProvider.ServiceHub.getDataByService(ServiceProvider.ServiceType.SERVICE_OTP_STEP1, [requestBody], {},
                    loginOTPStep1Success, loginOTPStep1Failure);
            }

            function loginOTPStep1Success(result) {
                console.log('Success Respond from OTPStep1', result);
                loadingIcon.fadeOut();
                // window.location = 'tempPage.html';
                self.changePage('temp-page');
            }

            function loginOTPStep1Failure(result) {
                console.log('Failed Respond from OTPStep1', result);
                loadingIcon.fadeOut();
            }

            //TODO OTP Login Step 2---------------------------
            function callOtpLoginStep2(username, tag) {
                var requestBody = {
                    'requestHeader': {
                        'channelAuthCode': 'HMACSTRING',
                        'channelTime': '2012-04-23T18:25:43.511Z',
                        'pageId': 'PAGEID',
                        'requestId': 'REQUESTUUIDSTRING',
                        'deviceId': 'DEVICEVENDORID',
                        'authId': 'AUTHIDFROMSERVER'
                    },
                    'requestBody': {
                        'otpType': 'SMS',
                        'otp': tag,
                        'grant_type': 'ibs_credential'
                    }
                };

                var invocationData = {
                    adapter: 'authAdapter',
                    procedure: 'OTPLoginStep2',
                    parameters: [username, requestBody]
                };

                // submitAdapterAuthentication(invocationData, {});
                MFPInit.submitAdapterAuthentication(invocationData, {});
            }

            //Get Current Time in ISO format
            function getCurrentTime() {
                return moment().toISOString();
            }


            //Get out of app config files
            function getConfigFiles(callback) {
                jQuery.ajax({
                    url: 'data/config.json',
                    type: 'GET',
                    contentType: 'application/json;charset=UTF-8',
                    dataType: 'json',
                    async: true,
                    cache: false,
                    success: function (res/*, status, xhr*/) {
                        console.log('Config Data ', res);
                        if (typeof res === 'string') {
                            res = JSON.parse(res);
                        }

                        //Set app versioning
                        configVersion = res.appVersion || '0000';
                        if (res && res.appVersion) {
                            console.log('build version from config web,', res.appVersion);
                            localStorage.setItem('buildVer', res.appVersion);
                        }
                        $('.app-version-id').text(appVersion);
                        $('.build-version-id').text(configVersion);

                        window.configData = res;
                        var authorizationKey = res.authorizationKey;

                        if (self.fromEPayment) {
                            authorizationKey = res.authorizationKeyEP;
                        } else if (self.fromFPX) {
                            authorizationKey = res.authorizationKeyFPX;
                        }

                        localStorage.setItem('authKey', authorizationKey);

                        if (callback) {
                            callback(res);
                        }
                    }
                });
            }

            //Get in app default config files
            function getDefaultAppConfig() {
                jQuery.ajax({
                    url: 'data/defaultvalues.json',
                    type: 'GET',
                    contentType: 'application/json;charset=UTF-8',
                    dataType: 'json',
                    async: false,
                    cache: false,
                    success: function (res) {
                        console.log('Default Config Data ', res);
                        if (typeof res === 'string') {
                            res = JSON.parse(res);
                        }

                        if (res.locatorSetting) {
                            localStorage.setItem('LocatorConfigVer', res.locatorSetting.version);
                            LocatorConfigVer = res.locatorSetting.version;
                            localStorage.setItem('LocatorConfig', JSON.stringify(res.locatorSetting));
                        }
                        if (res.trxSetting) {
                            localStorage.setItem('TransactionConfigVer', res.trxSetting.version);
                            TransactionConfigVer = res.trxSetting.version;
                            localStorage.setItem('TransactionConfig', JSON.stringify(res.trxSetting));
                        }
                        if (res.localBankSetting) {
                            localStorage.setItem('LocalBankConfigVer', res.localBankSetting.version);
                            LocalBankConfigVer = res.localBankSetting.version;
                            localStorage.setItem('LocalBankConfig', JSON.stringify(res.localBankSetting));
                        }
                        if (res.cmsSecuredBanner) {
                            localStorage.setItem('InitCmsBanner', JSON.stringify(res.cmsSecuredBanner));
                            console.log("Local InitCmsBanner >>>> : ", localStorage.getItem('InitCmsBanner'));
                        }
                        if (res.loginSecurityTips) {
                            localStorage.setItem('InitLoginSecurityTips', JSON.stringify(res.loginSecurityTips));
                            console.log("Local loginSecurityTips >>>> : ", localStorage.getItem('InitLoginSecurityTips'));
                        }
                        if (res.loginBanners) {
                            localStorage.setItem('InitLoginBanner', JSON.stringify(res.loginBanners));
                            console.log("Local loginBanners >>>> : ", localStorage.getItem('InitLoginBanner'));
                        }
                        if (res.clicksAppAcqBanner) {
                            localStorage.setItem('InitClicksAppAcqBanner', JSON.stringify(res.clicksAppAcqBanner));
                            console.log("Local InitClicksAppAcqBanner >>>> : ", localStorage.getItem('InitClicksAppAcqBanner'));
                        }
                        if (res.adobeMonitor !== undefined) {
                            console.log("res.adobeMonitor");
                            // localStorage.setItem('InitAdobeMonitor', JSON.stringify(res.adobeMonitor));
                            // console.log("Local InitAdobeMonitor >>>> : ", localStorage.getItem('InitAdobeMonitor'));
                            if (res.adobeMonitor === false) {
                                console.log("KILL ADOBE ANALYTICS");
                                window._satellite = {};
                                window._satellite.settings = {};
                                window._satellite.track = function (s) { }
                                window.salesAbandonment = function () { }
                            } else {
                                console.log("DON'T KILL ADOBE ANALYTICS");
                            }
                        }
                        localStorage.setItem('defaultConfigData', JSON.stringify(res));

                    },
                    error: function () {
                        console.log('Failed to download default config data');
                    }
                });
            }

            var proto = this;
            proto = proto || {};

            proto.init = function (options) {
                initOptions = _.extend(initOptions, options);
                this.initValues();
                this.bindEvents();
                this.initMFP();
            };

            proto.initValues = function () {
                //Move to password screen on quick balance return
                // if (localStorage.getItem('goToOtherPage') === null) { 
                //     localStorage.setItem('goToOtherPage', false);
                //     // window.location.assign('/index.html');
                //     // window.location.href = window.location.origin + window.location.pathname;
                //     window.location.href = window.location.protocol + "//" + window.location.hostname + window.location.pathname;

                //     setTimeout(function () {
                //         window.location.reload();
                //     }, 500);
                // }
                if (localStorage.getItem('userSession')) {
                    var session = {};
                    try {
                        session = JSON.parse(localStorage.getItem('userSession'));
                    } catch (err) {
                        session = {};
                    }
                    if (session.quickbalance) {
                        usn.val(session.userName);
                        $('select.quickstart').val('overview');
                        formStep1.hide();
                        nextForm(formStep2);
                    }
                }

            };

            proto.bindEvents = function () {
                var self = this;

                $("#icon-close-all").click(function () {
                    alert("icon close");
                    $(".warning-block").fadeOut("fast", function () {
                        $('.main-content').attr('style', 'padding-top: 0');
                        $('.header').attr('style', 'padding-top:0')
                    });
                });

                //TEMP if u click on OTP btn step 2
                $('#otp-btn-id').on('click', function () {
                    var userPas = $('#otp-tag-id');
                    console.log('im Clicking on OTP Btn 2', userPas.val());
                    if (userPas.val()) {
                        callOtpLoginStep2('anyPerson', userPas.val());
                    }
                });

                $('body').on("focusin", "#user-id, #password, [name=secure-word]", function (event) {
                    $targetElement = $(event.currentTarget);
                    $('.js_error_message').removeClass('active-error');
                    jQuery(document).find('input.error').removeClass('invalid').removeClass('error');
                });
                $('body').on("focusout", "#user-id, #password, [name=secure-word]", function (event) {
                    $targetElement = null;
                    // $('.js_error_message').removeClass('active-error');
                });

                $(window).resize(function () {
                    // console.log('resize');
                    if (!$targetElement) { return; }
                    //fix me, move up depend on the height of the top banner on mobile
                    var bannerHeight = $('.banner-mob.login-mob').height();

                    var $mainElement = $('.mobile .main-content');
                    // var windowHeight = $(window).height();
                    // //console.log('windowHeight ', windowHeight);
                    // var userIdPos = $targetElement.offset().top;
                    // var topPos = userIdPos - windowHeight + 50;

                    setTimeout(function () {
                        $mainElement.animateScroll(bannerHeight);
                    }, 200);
                });

                // init Fastclick on doc ready
                /*global FastClick*/
                if ('FastClick' in window && !FastClick.attached) {
                    console.log('Register Fastclick');
                    FastClick.attach(document.body);
                    FastClick.attached = true;
                }

                // binding hybrid Messenger module
                /* global WebView*/
                if ('WebView' in window) {
                    $('.navbar-note').on('click', function () {
                        console.log("Bell Clicked(Pre Login)", "cmId=>" + localStorage.getItem('cmId'), "cmPass=>" + localStorage.getItem('cmPass'));
                        WebView.show(messengerUrl);
                    });
                }

                /*if (!localStorage.getItem('firstTime') || localStorage.getItem('firstTime') === true) {
                    togglePreLoginScreen('GET_STARTED');
                } else {
                    */togglePreLoginScreen('HIDE_ALL');
                    aa();/*
                }*/

                //add event listener

                // $('.octo-update-available .octo-button').on('click', function() {
                // 	togglePreLoginScreen('UPDATE_AVAILABLE_SKIP');
                // });
                // $('.js-get-started-container .js-get-start-btn').on('click', function () {
                //     togglePreLoginScreen('HIDE_ALL');
                //     localStorage.setItem('firstTime', false);
                // });
                $('#octo-screen .btn-close').on('click', function () {
                    togglePreLoginScreen('HIDE_ALL');
                    aa();
                });
                $('.octo-update-available .octo-link-skip-container').on('click', function () {
                    togglePreLoginScreen('HIDE_ALL');
                    aa();
                });
                $('.octo-update-available .octo-button').off().on('click', function () {
                    console.log('Current State', currentState);

                    /*if (currentState === 'GET_STARTED') {
                        if (!localStorage.getItem('firstTime') || localStorage.getItem('firstTime') === true) {
                            togglePreLoginScreen('HIDE_ALL');
                            togglePreLoginScreen('GET_STARTED');
                        } else {
                            togglePreLoginScreen('HIDE_ALL');
                        }
                    } else*/ if (currentState === 'INIT_FAIL') {
                        loadingIcon.fadeIn();
                        proto.initMFP();

                        /*if (!localStorage.getItem('firstTime') || localStorage.getItem('firstTime') === true) {
                            togglePreLoginScreen('HIDE_ALL');
                            togglePreLoginScreen('GET_STARTED');
                        } else {
                            */togglePreLoginScreen('HIDE_ALL');
                            aa();/*
                        }*/
                    }
                });

                //dropdown
                $('.dropdown-menu li').on('click', function (e) {
                    var targetElement = $(e.currentTarget);

                    targetElement.addClass('active');
                    $(this).next().removeClass('active');
                    $(this).prev().removeClass('active');
                });

                var $customSelects = $('select.quickstart');

                $customSelects.select2({
                    minimumResultsForSearch: Infinity
                });
                $customSelects.each(function (index, el) {
                    var select2Data = $(el).data('select2');
                    select2Data.$dropdown.find('.select2-results__options').addClass('select2-login');
                    select2Data.$dropdown.find('.select2-results__options').scrollbar({
                        ignoreMobile: true,
                        ignoreOverlay: true
                    });

                    select2Data.$selection.on('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        select2Data.open();

                        select2Data.$dropdown.find('.select2-results__option[role="treeitem"]').addClass('needsclick');

                    });

                });

                $('#login-form-step1').find('.btn-primary').on('click', function () {
                    
                    // Adobe Analytics Tracking
                    if (typeof _satellite != 'undefined') {
                        _satellite.track("web:login-start");
                        console.log("Adobe Analytic Tracking: web:login-start");
                    }

                    // Adobe Analytics
                    window.clearDigitalData();
					digitalData.page = { 
						pageInfo: { 
							pageName: "web:SecureWordPage"
						}, 
						category: {
							pageType: "input", 
							primaryCategory: "LoginModule", 
							subCategory1: "SecureWord", 
							subCategory2: "", 
							subCategory3: "" 		
						}
					};
                });

                $('.login-form .btn-primary').on('click', function () {
                  
                    var selectedOption = $('select.quickstart').val();

                    console.log('Selected Item in dropdown', selectedOption);
                    console.log('TOUCH ACTIVATION status', touchActivationFlow);
                    console.log('Messenger ACTIVATION status', msgerActivationFlow);

                    if (touchActivationFlow) {
                        localStorage.setItem('activateSession', 'touch');
                        selectedOption = 'overview';
                    }
                    else if (msgerActivationFlow) {
                        localStorage.setItem('activateSession', 'messenger');
                        selectedOption = 'overview';
                    }
                    else if (quickActivationFlow) {
                        localStorage.setItem('activateSession', 'quick');
                        selectedOption = 'overview';
                    }
                    else {
                        localStorage.setItem('activateSession', 'normal');
                    }

                    if (selectedOption === 'NV') {
                        localStorage.setItem('goToOtherPageUrl', 'pay-bills');

                    } else if (selectedOption === 'CA') {
                        localStorage.setItem('goToOtherPageUrl', 'fund-transfer');

                    } else if (selectedOption === 'JP') {
                        localStorage.setItem('goToOtherPageUrl', 'jom-pay');

                    } else if (selectedOption === 'OR') {
                        localStorage.setItem('goToOtherPageUrl', 'pay-loan');

                    } else if (selectedOption === 'topUp') {
                        localStorage.setItem('goToOtherPageUrl', 'topup');

                    }

                    if (loginTimes >= 3) {
                        return false;
                    }

                    // if (validateForm(formStep1, formStep2, null)) {
                    // $('.js_blocked_message').hide();
                    // $('.js_error_message').hide();
                    // } 

                });

                $('.login-form .btn-next').on('click', function () {

                    

                    //window.history.pushState("", "CIMB Clicks", window.location.protocol + "//" + window.location.hostname + window.location.pathname);

                    $('#password').val('');
                    $('.passwordsInputId').removeClass('label-on');
                    $('#loginCheckBox').prop('checked', false);
                    self.isCheckSecureWord = false;
                    validateForm(formStep1, formStep2, null);
                });


                $('.login-form .btn-login').on('click', function () {
                    if (loginTimes >= 3) {
                        return false;
                    }
                    validateForm(formStep2, null, null);
                });

                $('.login-form .btn-fa').on('click', function () {
                    if (faanswer.val() == '') {
                        $('#fatext-error').show();
                        return false;
                    }
                    validateForm(formStep1, null, formStep3)
                });

                $('.service-activation').hide();

                $('.js-about-us-page').on('click', function () {
                    console.log('js-about-us-page ');
                    showService(aboutUsPage);
                    serviceActivation.fadeIn();

                    $('.js-help-support-title').show();
                    $('.js-logo-header').hide();
					
                    // Adobe Analytics
                    window.clearDigitalData();
                    digitalData.page = {
                        pageInfo: {
                            pageName: "web:Help&SupportPage"
                        },
                        category: {
                            pageType: "content",
                            primaryCategory: "LoginModule",
                            subCategory1: "Help&Support",
                            subCategory2: "",
                            subCategory3: ""
                        }
                    };
                });


                $('#cancelHolderId').on('click', function () {
                    console.log('im clickig on cancel');
                    touchActivationFlow = false;
                    msgerActivationFlow = false;
                    $('#startHolderId').show();
                    $('#cancelHolderId').hide();
                    $('.js-touch-id-wrapper').show()
                    $('.touch-container').hide();
                    $('.service-activation').hide();
                    usn.val('');
                    usn.prev('label.label-on').removeClass('label-on');
                    usn.blur();

                });

                $('.js-login').on('click', function () {
                    touchActivationFlow = false;
                    msgerActivationFlow = false;
                    $('#startHolderId').show();
                    $('#cancelHolderId').hide();
                    $('.js-touch-id-wrapper').show()
                    $('.touch-container').hide();
                    $('.service-activation').hide();
                    usn.val('');
                    usn.prev('label.label-on').removeClass('label-on');
                    usn.blur();

                    console.log('********** .js-login **********');
                    // if (isMobile) {
                    // 	WL.Client.reloadApp();
                    // } else {
                    // 	window.location.assign('./');
                    // }
                });

                $('#modal-term-condition .show-touch').on('click', function () {
                    $('#modal-term-condition').modal('hide');
                    showService(serviceTouchId);

                });

                serviceActivation.find('.show-touch').on('click', function () {
                    $('#modal-term-condition').modal('hide');
                    showService(serviceTouchId);

                });

                serviceActivation.find('.show-t-c').on('click', function () {
                    console.log('show t&c');
                    $('#modal-term-condition').modal({
                        show: true,
                        backdrop: false
                    });
                });

                serviceActivation.find('.show-login').on('click', function () {
                    $('select.quickstart').val('overview');

                    serviceActivation.fadeOut(function () {
                        serviceTacMobile.hide();
                    });
                    $('.mobile .main-content').addClass('tac-activation-login');
                    if (!localStorage.getItem('tacOnApp')) {
                        localStorage.setItem('tacOnApp', false);
                    }
                });

                serviceActivation.find('.show-tac-sms').on('click', function () {
                    showService(serviceTac);
                    // Adobe Analytics
                    window.clearDigitalData();
                    digitalData.page = {
                        pageInfo: {
                            pageName: "web:TACRequestPage"
                        },
                        category: {
                            pageType: "input",
                            primaryCategory: "FTLModule",
                            subCategory1: "TACRequest",
                            subCategory2: "",
                            subCategory3: ""
                        }
                    };	
                });

                serviceActivation.find('.show-tac').on('click', function () {
                    userProfile.forEach(function (item) {
                        if (item.userName.toLowerCase() === usn.val().toLowerCase()) {
                            delete item.password;
                            item.quickbalance = true;
                            //localStorage.setItem('userSession', JSON.stringify(item));
                        }
                    });

                    self.changePage('dashboard');
                });


                serviceActivation.find('.confirm-quick-balance').on('click', function () {
                    self.changePage('dashboard');
                });


                $('.tac-activation-cancel').on('click', function () {
                    serviceActivation.fadeOut(function () {
                        $('.mobile .main-content').removeClass('tac-activation-login');
                        serviceActivation.find('.activate').hide();
                        serviceActivation.css({ height: '' });
                        $('.mobile .login-wrapper .override-scroller').css({ 'margin-top': '' });
                        serviceActivation.removeClass('show-login');
                    });
                });

                serviceActivationClose.on('click', function () {
                    serviceActivation.fadeOut(function () {
                        $('.mobile .main-content').removeClass('tac-activation-login');
                        serviceActivation.find('.activate').hide();
                        serviceActivation.css({ height: '' });
                        $('.mobile .login-wrapper .override-scroller').css({ 'margin-top': '' });
                        serviceActivation.removeClass('show-login');
                    });
                    $('#octo-screen').css('z-index', 10000);
                });

                //arrow back form-step-1
                $('.login-form .arrow-back').on('click', function (/*e*/) {

                    secureWord.attr('src', '');
                    faanswer.val('');
                    faErrorCode = "";
                    faErrorMessage = "";

                    formStep2.fadeOut(function () {
                        formStep3.hide();
                        nextForm(formStep1);
                        $('.js_blocked_message').hide();
                        $('.js_error_message').hide();
                        // Adobe Analytics
                        window.clearDigitalData();
                        digitalData.page = {
                            pageInfo: {
                                pageName: "web:Pre-loginPage"
                            },
                            category: {
                                pageType: "input",
                                primaryCategory: "LoginModule",
                                subCategory1: "Pre-login",
                                subCategory2: "",
                                subCategory3: ""
                            }
                        };
                        digitalData.user = {
                            loginStatus: "not logged-in"
                        };
                    });
                });

                // Init SideBar
                initSideBar();

                $('.scrollable').scrollbar({
                    ignoreMobile: true,
                    ignoreOverlay: true
                });

                // Init Carousel

                $('.owl-carousel').owlCarousel({
                    slideSpeed: 400,
                    paginationSpeed: 400,
                    singleItem: true,
                    addClassActive: true,
                    afterMove: function () {
                        var imgBg = $('.carousel-bg img.login-sl');
                        var indexNo = this.currentItem;
                        imgBg.removeClass('active');

                        $(imgBg[indexNo])
                            .css({ opacity: 0, display: 'block' })
                            .animate({ opacity: 1 }, function () {
                                $(this).addClass('active');
                                $('.carousel-bg img.login-sl:not(.active)').animate({ opacity: 0 });
                            });
                    }
                });

                $('input').keyup(function (event) {
                    // formStep1.valid();
                    if (event.keyCode !== 13) {
                        $('.js_error_message').removeClass('active-error');
                        jQuery(document).find('input.error').removeClass('invalid').removeClass('error');
                        $('div.error').hide();
                        // console.log("hiding div.error...");
                    }
                });

                $('input#password').keyup(function (event) {
                    if (event.keyCode !== 13) {
                        var hasvalue = $(this).val();
                        if (!hasvalue) {
                            $('.login-form .btn-login').trigger('click');
                        }
                    } else {
                        $('.login-form .btn-login').trigger('click');
                    }
                });

                $('input#user-id').keyup(function (event) {
                    if (event.keyCode !== 13) {
                        var hasvalue = $(this).val();
                        if (!hasvalue) {
                            $('.login-form .btn-next').trigger('click');
                        }
                    } else {
                        $('.login-form .btn-next').trigger('click');
                    }
                });

                $('input#fatext').keyup(function (event) {
                    if (event.keyCode !== 13) {
                        var hasvalue = $(this).val();
                        if (!hasvalue) {
                            $('.login-form .btn-fa').trigger('click');
                        }
                    } else {
                        $('.login-form .btn-fa').trigger('click');
                    }
                });

                jQuery(document).on('keyup', 'input.error', function () {
                    // $(document).find('input.error').removeClass('invalid').removeClass('error');
                });

            };

            proto.unbindEvents = function () { };

            proto.destroy = function () {
                this.unbindEvents();
            };

            proto.initMFP = function () {
                var self = this;
                //Check for config versions
                if (localStorage.getItem('defaultConfigData')) {

                    console.log('defaultConfigData');

                    // Locator Settings Ver
                    if (localStorage.getItem('LocatorConfigVer')) {
                        LocatorConfigVer = localStorage.getItem('LocatorConfigVer');
                    }
                    else {
                        if (localStorage.getItem('defaultConfigData').locatorSetting) {
                            localStorage.setItem('LocatorConfigVer', localStorage.getItem('defaultConfigData').locatorSetting.version);
                            LocatorConfigVer = localStorage.getItem('defaultConfigData').locatorSetting.version;
                        }
                        localStorage.setItem('LocatorConfigVer', '1.0.0');
                        LocatorConfigVer = '1.0.0';
                    }

                    // Transaction Confing Ver
                    if (localStorage.getItem('TransactionConfigVer')) {
                        TransactionConfigVer = localStorage.getItem('TransactionConfigVer');
                    }
                    else {
                        if (localStorage.getItem('defaultConfigData').trxSetting) {
                            localStorage.setItem('TransactionConfigVer', localStorage.getItem('defaultConfigData').trxSetting.version);
                            TransactionConfigVer = localStorage.getItem('defaultConfigData').trxSetting.version;
                        }
                        localStorage.setItem('TransactionConfigVer', '1.0.0');
                        TransactionConfigVer = '1.0.0';
                    }

                    //Local Bank Config Ver
                    if (localStorage.getItem('LocalBankConfigVer')) {
                        LocalBankConfigVer = localStorage.getItem('LocalBankConfigVer');
                    }
                    else {
                        if (localStorage.getItem('defaultConfigData').localBankSetting) {
                            localStorage.setItem('LocalBankConfigVer', localStorage.getItem('defaultConfigData').localBankSetting.version);
                            LocalBankConfigVer = localStorage.getItem('defaultConfigData').localBankSetting.version;
                        }
                        localStorage.setItem('LocalBankConfigVer', '1.0.0');
                        LocalBankConfigVer = '1.0.0';
                    }
                }
                else {
                    console.log('getDefaultAppConfig');
                    getDefaultAppConfig();
                }


                var confingVersions = {
                    locator: LocatorConfigVer,
                    transaction: TransactionConfigVer,
                    localBank: LocalBankConfigVer
                }

                if (window.cordova && window.cordova.exec) {
                    cordova.exec(function (info) {
                        console.log('Data:' + JSON.stringify(info));
                        deviceName = (info.name) || '';
                        deviceManufacturer = (info.manufacturer) || '';
                        localStorage.setItem('deviceName', deviceName);
                    }, function (error) {
                        console.log('Error executing cordova CDVDeviceExtention:' + e);
                    }, "Device", "getDeviceInfoExt", []);
                }

                new Fingerprint2().get(function (result, components) {

                    console.log('fingerprint ', result);

                    var uid = result;
                    deviceType = (window.device && window.device.platform) || 'Web';
                    deviceName = (window.device && window.device.name) || 'Browser';
                    modelName = (window.device && window.device.model) || '';
                    deviceManufacturer = (window.device && window.device.manufacturer) || '';
                    osVersion = (window.device && window.device.version) || '1.0';
                    appVersion = _config.appVersion;
                    appName = _config.appName;

                    console.log('deviceType', deviceType);
                    console.log('deviceName', deviceName);
                    console.log('modelName', modelName);
                    console.log('appVersion', appVersion);
                    console.log('deviceManufacturer', deviceManufacturer);
                    console.log('osVersion', osVersion);
                    console.log('appName', appName);
                    console.log('uid', uid);
                   
                    uniqueDeviceId = uid + new Date().getTime().toString().substr(6);
                    window.uniqueDeviceId = uniqueDeviceId;

                    localStorage.setItem('deviceId', uniqueDeviceId);
                    localStorage.setItem('deviceType', deviceType);
                    localStorage.setItem('deviceName', deviceName);
                    localStorage.setItem('modelName', modelName);
                    localStorage.setItem('appVer', appVersion);
                    localStorage.setItem('appId', appName);
                    var timestamp = getCurrentTime();

                    console.log('uniqueDeviceId', uniqueDeviceId);

                    var authorizationKey = _config.authorizationKey;

                    if (self.fromEPayment) {
                        authorizationKey = _config.authorizationKeyEP;
                    } else if (self.fromFPX) {
                        authorizationKey = _config.authorizationKeyFPX;
                    }

                    if (self.mfpInited) {
                        MFPInit.callInitService({
                            authorizationKey: authorizationKey,
                            configVers: confingVersions,
                            timeStamp: timestamp,
                            onSuccess: self.initSuccess.bind(self),
                            onFailure: self.initFailure.bind(self)
                        });
                    } else {
                        var loadConfigComplete = function (data) {
                            _config = data;
                            console.log('_config', _config);
                            var authorizationKey = _config.authorizationKey;

                            if (self.fromEPayment) {
                                authorizationKey = _config.authorizationKeyEP;
                            } else if (self.fromFPX) {
                                authorizationKey = _config.authorizationKeyFPX;
                            }
                            window.authorizationKey = authorizationKey;

                            MFPInit.init({
                                uniqueDeviceId: uniqueDeviceId,
                                initMFPSuccess: self.initMFPSuccess.bind(self),
                                initFailure: self.initFailure.bind(self),
                                //passAuthResponse: self.passAuthResponse.bind(self),
                                authorizationKey: authorizationKey,
                                configVers: confingVersions,
                                timeStamp: timestamp,
                                config: data,
                                //SIT
                                // rsaKeyModulusHex: "809477E24FADD4E26E9A75AF2E7DF31A3ED092F792C75DD0250B40A07E06248CA809ED406360CE4AF096C0D832EDCE20B0AA063580F8B19DD75CE06526149F5EBEF74FF6E666CFE9715C582B8AB69AC73E3B2119CD38D5EE62CBF9442D14948C4015A7ECC12407543077AC7D7AF762FCFA0CA25F87698C4914213D27425CC803",

                                //UAT
                               rsaKeyModulusHex: "8A90B14B2F2D0BA1CEDC1C4E050291F70687BB5A8875D89D98EC3108AD767FD1AD1BADEECA6412212935293843B5D35C47CB0A582ACA886484C47E65A98C12F82F16DEE8CFB8EFFFE32C9B4193E2B0D92F55975E0AB60D13DD3A0A9A74B241DAB3D9A76B16AEFBCDC8D432C0D7AB99A42B7BE65671FA6580A881593F1577F39B",

                                //DR
                                // rsaKeyModulusHex: "8A90B14B2F2D0BA1CEDC1C4E050291F70687BB5A8875D89D98EC3108AD767FD1AD1BADEECA6412212935293843B5D35C47CB0A582ACA886484C47E65A98C12F82F16DEE8CFB8EFFFE32C9B4193E2B0D92F55975E0AB60D13DD3A0A9A74B241DAB3D9A76B16AEFBCDC8D432C0D7AB99A42B7BE65671FA6580A881593F1577F39B",

                                exponentHex: "10001"
                            });
                        };
                        if (initOptions.config) {
                            loadConfigComplete(initOptions.config);
                        } else {
                            getConfigFiles(loadConfigComplete);
                        }
                    }
                });;
              

                // Get windows device version
                var deviceVersion = (window && window.device && window.device.version) || 1;
            };

            proto.initMFPSuccess = function () {
                var self = this;
                self.mfpInited = true;
                var authorizationKey = _config.authorizationKey;

                if (self.fromEPayment) {
                    authorizationKey = _config.authorizationKeyEP;
                } else if (self.fromFPX) {
                    authorizationKey = _config.authorizationKeyFPX;
                }

                if (initOptions.logout) {
                    MFPInit.logoutUser({
                        onSuccess: function () {
                            // callInitService();
                            MFPInit.callInitService({
                                authorizationKey: authorizationKey,
                                onSuccess: self.initSuccess.bind(self),
                                onFailure: self.initFailure.bind(self)
                            });
                        },
                        onFailure: function () {
                            // callInitService();
                            MFPInit.callInitService({
                                authorizationKey: authorizationKey,
                                onSuccess: self.initSuccess.bind(self),
                                onFailure: self.initFailure.bind(self)
                            });
                        }
                    });
                } else {
                    MFPInit.callInitService({
                        authorizationKey: authorizationKey,
                        onSuccess: self.initSuccess.bind(self),
                        onFailure: self.initFailure.bind(self)
                    });
                }
            };

            proto.backToStep1 = function () {
                formStep2.fadeOut(function () {
                    nextForm(formStep1);
                    // Adobe Analytics
                    window.clearDigitalData();
                    digitalData.page = {
                        pageInfo: {
                            pageName: "web:Pre-loginPage"
                        },
                        category: {
                            pageType: "input",
                            primaryCategory: "LoginModule",
                            subCategory1: "Pre-login",
                            subCategory2: "",
                            subCategory3: ""
                        }
                    };
                    digitalData.user = {
                        loginStatus: "not logged-in"
                    };
                });
            };

            proto.changePage = function (page) {
                console.log('StartWith Page selected ', page);
                // if(page != '' && page != 'overview' && page != 'dashboard' ){
                // 	localStorage.setItem('goToOtherPage', true);
                // }else{
                // 	localStorage.setItem('goToOtherPage', false);
                // }
                switch (page) {
                    case 'NV':
                        window.location = 'dashboard.html#/dashboard/pay-bills';
                        // Adobe Analytics
                        window.clearDigitalData();
                        digitalData.page = {
                            pageInfo: {
                                pageName: "web:PayBillInputPage"
                            },
                            category: {
                                pageType: "input",
                                primaryCategory: "PayBillModule",
                                subCategory1: "PayBillInput",
                                subCategory2: "",
                                subCategory3: ""
                            }
                        };
                        break;
                    case 'CA':
                        window.location = 'dashboard.html#/dashboard/fund-transfer';
                        // Adobe Analytics
                        window.clearDigitalData();
                        digitalData.page = {
                            pageInfo: {
                                pageName: "web:TransferMoneyInputPage"
                            },
                            category: {
                                pageType: "input",
                                primaryCategory: "TransferMoneyModule",
                                subCategory1: "TransferMoneyInput",
                                subCategory2: "",
                                subCategory3: ""
                            }
                        };
                        break;
                    case 'JP':
                        window.location = 'dashboard.html#/dashboard/jom-pay';
                        // Adobe Analytics
                        window.clearDigitalData();
                        digitalData.page = {
                            pageInfo: {
                                pageName: "web:JomPAYInputPage"
                            },
                            category: {
                                pageType: "input",
                                primaryCategory: "JomPAYModule",
                                subCategory1: "JomPAYInput",
                                subCategory2: "",
                                subCategory3: ""
                            }
                        };
                        break;
                    case 'OR':
                        window.location = 'dashboard.html#/dashboard/pay-loan';
                        // Adobe Analytics
                        window.clearDigitalData();
                        digitalData.page = {
                            pageInfo: {
                                pageName: "web:PayLoan&CardInputPage"
                            },
                            category: {
                                pageType: "input",
                                primaryCategory: "PayLoan&CardModule",
                                subCategory1: "PayLoan&CardInput",
                                subCategory2: "",
                                subCategory3: ""
                            }
                        };
                        break;
                    case 'topUp':
                        window.location = 'dashboard.html#/dashboard/topup';
                        // Adobe Analytics
                        window.clearDigitalData();
                        digitalData.page = {
                            pageInfo: {
                                pageName: "web:TopupInputPage"
                            },
                            category: {
                                pageType: "input",
                                primaryCategory: "TopupModule",
                                subCategory1: "TopupInput",
                                subCategory2: "",
                                subCategory3: ""
                            }
                        };
                        break;
                    // case 'quickpay':
                    // 	window.location = 'dashboard.html#/dashboard/pay-bills';
                    // 	localStorage.setItem('goToOtherPageUrl', 'topup');						
                    // 	break;
                    case 'dashboard':
                        window.location = DashboardPageUrl;
                        // Adobe Analytics
                        window.clearDigitalData();
                        digitalData.page = {
                            pageInfo: {
                                pageName: "web:AccountSummaryPage"
                            },
                            category: {
                                pageType: "content",
                                primaryCategory: "DashboardModule",
                                subCategory1: "AccountSummary",
                                subCategory2: "",
                                subCategory3: ""
                            }
                        };
                        break;
                    default:
                        window.location = DashboardPageUrl;
                        // Adobe Analytics
                        // window.clearDigitalData();
                        // digitalData.page = {
                        //     pageInfo: {
                        //         pageName: "web:AccountSummaryPage"
                        //     },
                        //     category: {
                        //         pageType: "content",
                        //         primaryCategory: "DashboardModule",
                        //         subCategory1: "AccountSummary",
                        //         subCategory2: "",
                        //         subCategory3: ""
                        //     }
                        // };
                        break;
                }
            };

            proto.showLoading = function () {
                loadingIcon.fadeIn();
            };

            proto.hideLoading = function () {
                loadingIcon.fadeOut();
            };

            proto.parseVersioning = function (v1, v2, options) {
                var lexicographical = options && options.lexicographical,
                    zeroExtend = options && options.zeroExtend,
                    v1parts = v1.split('.'),
                    v2parts = v2.split('.');

                function isValidPart(x) {
                    return (lexicographical ? /^\d+[A-Za-z]*$/ : /^\d+$/).test(x);
                }

                if (!v1parts.every(isValidPart) || !v2parts.every(isValidPart)) {
                    return NaN;
                }

                if (zeroExtend) {
                    while (v1parts.length < v2parts.length) v1parts.push("0");
                    while (v2parts.length < v1parts.length) v2parts.push("0");
                }

                if (!lexicographical) {
                    v1parts = v1parts.map(Number);
                    v2parts = v2parts.map(Number);
                }

                for (var i = 0; i < v1parts.length; ++i) {
                    if (v2parts.length == i) {
                        return 1;
                    }

                    if (v1parts[i] == v2parts[i]) {
                        continue;
                    }
                    else if (v1parts[i] > v2parts[i]) {
                        return 1;
                    }
                    else {
                        return -1;
                    }
                }

                if (v1parts.length != v2parts.length) {
                    return -1;
                }

                return 0;
            };

            proto.google_reCaptha_generatedKey = "";
            proto.googleCaptchaReoccurrence = 1;
            proto.thresholdSeconds = 0;
            proto.enableGoogleCaptcha = false;
            proto.googleCapcha = function (){
                
                try{ 
                    grecaptcha.render(self.captchaRenderId, {
                        "sitekey": self.siteKey,"badge":"bottomright", 
                        "callback":self.capchaCallback,"size":"invisible",
                        "expired-callback":self.capchaExpiryCallback,
                        "error-callback" : self.capchaErrorCallback });
                    onMFPInit();
                    //$('.googleCapthaCls').removeAttr("disabled");
                    //setTimeout(function(){grecaptcha.execute();},1500);
                }catch(err){
                    self.googleCaptchaReoccurrence = self.googleCaptchaReoccurrence+1;
                    console.log('googleCaptchaReoccurrence >>> '+ self.googleCaptchaReoccurrence)
                    self.loadGcaptcha();                        
                }                    	
            };

            proto.capchaExpiryCallback =function(){
                
                console.log('google recaptcha expried');
                onMFPInit();
                //$('.googleCapthaCls').removeAttr("disabled");
            };

            proto.capchaErrorCallback = function(){
                
                console.log('google captcha error callback');
                onMFPInit();
               // $('.googleCapthaCls').removeAttr("disabled");
                if($('#user-id').val().length>5){
                    callSecureLogin1($('#user-id').val(), 'normal');
                }
            };

            proto.capchaCallback = function (e){
                console.log('Google Recaptcha generated code : ' + e);
                self.google_reCaptha_generatedKey = e;
                if($('#user-id').val().length>5){
                    callSecureLogin1($('#user-id').val(), 'normal');
                }
            };

            proto.loadGcaptcha = function(){
                loginBtnDisable();
               // $('.googleCapthaCls').attr("disabled","disabled");
                self.google_reCaptha_generatedKey = "";
                if(self.googleCaptchaReoccurrence < self.thresholdSeconds){
                    setTimeout(function(){
                        self.googleCapcha(self.siteKey,self.captchaRenderId);                          
                    },500); 
                }
            };
           proto.loadGoogleApi = function(){
                var po = document.createElement('script');
                po.type = 'text/javascript';
                po.src = 'https://www.google.com/recaptcha/api.js?onload=loadedGoogleApifile&render=explicit';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(po, s);
           };
            proto.loadGoogleCaptcha = function(resBody, capid){
                
                if(resBody && resBody.googleCaptcha && resBody.googleCaptcha.enable){
                    //$('.googleCapthaCls').attr("disabled","disabled");
                    loginBtnDisable();
                    console.log('google Enabled');
                    self.thresholdSeconds = resBody.googleCaptcha.thresholdSeconds;
                    self.siteKey = resBody.googleCaptcha.siteKey;
                    self.enableGoogleCaptcha = resBody.googleCaptcha.enable;                   
                    self.captchaRenderId = capid;
                    self.loadGoogleApi();
                 }else{
                    //$('.googleCapthaCls').removeAttr("disabled");
                    onMFPInit();
                 }
            }
            proto.initSuccess = function (result) {
                console.log('Init success RESULT >>', result);
                var timestamp = moment().toISOString();
                console.log('Init Response TimeStamp', timestamp);                    
                
               

                if (result.invocationResult.statusCode === 200) {

                    if (result.invocationResult.responseHeaders['x-cs-status'] === 'error') {
                        togglePreLoginScreen('INIT_FAIL');
                    } else {

                        var isFirstTime = false; 

                        if (localStorage.getItem('InitLoginBanner') == null) {
                            isFirstTime = true;
                        }

                        if (result.invocationResult.array) {

                            if (result.invocationResult.array.sessionTimeout) {
                                if (result.invocationResult.array.sessionTimeout.postlogin) {
                                    localStorage.setItem('postLoginSessionTime', JSON.stringify(result.invocationResult.array.sessionTimeout.postlogin));
                                    window.postLoginTime = parseFloat(result.invocationResult.array.sessionTimeout.postlogin) * 1000;
                                    window.preLoginTime = parseFloat(result.invocationResult.array.sessionTimeout.prelogin) * 1000;
                                    console.log('my prelogintime: ', window.preLoginTime);

                                    if (self.fromFPX || self.fromEPayment) {
                                        console.log('start calling prelogin idletime');
                                        startPreLoginIdleTime();
                                    }
                                }
                            }

                            //remove the TouchId if server sends false flag
                            console.log('touchIdActivated value', result.invocationResult.array.touchIdActivated);
                            if (!result.invocationResult.array.touchIdActivated) {
                                if (localStorage.getItem('deviceKey')) {
                                    localStorage.removeItem('deviceKey');
                                }
                            }

                            localStorage.setItem('appState', 'PreLogin');
                            loginType = result.invocationResult.array.login_type;

                            //set the layout of login
                            if (loginType === 'otp') {
                                $('#user-password-holder-id').attr('class', 'input-field input-field-pass');
                                $('#login-btn-secure-id').attr('class', 'btn-primary btn-block btn-next hidden');
                                $('#login-btn-otp-id').attr('class', 'btn-primary btn-block');
                            } else {
                                $('#user-password-holder-id').attr('class', 'input-field input-field-pass hidden');
                                $('#login-btn-secure-id').attr('class', 'btn-primary btn-block btn-next');
                                $('#login-btn-otp-id').attr('class', 'btn-primary btn-block btn-next hidden');
                            }

                            // Get new Config versions
                            if (result.invocationResult.array.locatorSetting) {
                                if (localStorage.getItem('LocatorConfigVer')) {
                                    if (proto.parseVersioning(result.invocationResult.array.locatorSetting.version, localStorage.getItem('LocatorConfigVer')) === 1) {
                                        localStorage.setItem('LocatorConfig', JSON.stringify(result.invocationResult.array.locatorSetting));
                                        localStorage.setItem('LocatorConfigVer', result.invocationResult.array.locatorSetting.version);
                                    }
                                }
                            }
                            if (result.invocationResult.array.trxSetting) {
                                if (localStorage.getItem('TransactionConfigVer')) {
                                    if (proto.parseVersioning(result.invocationResult.array.trxSetting.version, localStorage.getItem('TransactionConfigVer')) === 1) {
                                        localStorage.setItem('TransactionConfig', JSON.stringify(result.invocationResult.array.trxSetting));
                                        localStorage.setItem('TransactionConfigVer', result.invocationResult.array.trxSetting.version);
                                    }
                                }

                            }
                            if (result.invocationResult.array.localBankSetting) {
                                if (localStorage.getItem('LocalBankConfigVer')) {

                                    console.log('localStorage get item');
                                    console.log('version', result.invocationResult.array.localBankSetting.version, localStorage.getItem('LocalBankConfigVer'));

                                    if (proto.parseVersioning(result.invocationResult.array.localBankSetting.version, localStorage.getItem('LocalBankConfigVer')) === 1) {
                                        localStorage.setItem('LocalBankConfig', JSON.stringify(result.invocationResult.array.localBankSetting));
                                        localStorage.setItem('LocalBankConfigVer', result.invocationResult.array.localBankSetting.version);
                                    }
                                    else {
                                        console.log('localStorage update existing');
                                    }
                                }
                            }
                            if (result.invocationResult.array.cmsSecuredBanner) {
                                localStorage.setItem('InitCmsBanner', JSON.stringify(result.invocationResult.array.cmsSecuredBanner));
                                console.log("InitCmsBanner >>>> : ", localStorage.getItem('InitCmsBanner'));
                            }
                            if (result.invocationResult.array.loginSecurityTips) {
                                localStorage.setItem('InitLoginSecurityTips', JSON.stringify(result.invocationResult.array.loginSecurityTips));
                                console.log("InitLoginSecurityTips >>>> : ", localStorage.getItem('InitLoginSecurityTips'));
                            }
                            if (result.invocationResult.array.loginBanners) {
                                localStorage.setItem('InitLoginBanner', JSON.stringify(result.invocationResult.array.loginBanners));
                                console.log("InitLoginBanner >>>> : ", localStorage.getItem('InitLoginBanner'));
                            }
                            if (result.invocationResult.array.clicksAppAcqBanner) {
                                localStorage.setItem('InitClicksAppAcqBanner', JSON.stringify(result.invocationResult.array.clicksAppAcqBanner));
                                console.log("InitClicksAppAcqBanner >>>> : ", localStorage.getItem('InitClicksAppAcqBanner'));
                                
                            }
                            else {
                                console.log("Delete image");
                                localStorage.removeItem('InitClicksAppAcqBanner');
                            }

                            if (result.invocationResult.array.adobeMonitor !== undefined) {
                                console.log("result.invocationResult.array.adobeMonitor");
                                // localStorage.setItem('InitAdobeMonitor', JSON.stringify(result.invocationResult.array.adobeMonitor));
                                // console.log("InitAdobeMonitor >>>> : ", localStorage.getItem('InitAdobeMonitor'));
                                if (result.invocationResult.array.adobeMonitor === false) {
                                    console.log("KILL ADOBE ANALYTICS");
                                    window._satellite = {};
                                    window._satellite.settings = {};
                                    window._satellite.track = function (s) { }
                                    window.salesAbandonment = function () { }
                                } else {
                                    console.log("DON'T KILL ADOBE ANALYTICS");
                                }
                            }
                            else {
                                console.log("Delete image");
                                localStorage.removeItem('InitClicksAppAcqBanner');
                            }

                        }

                        //onMFPInit();
                        //set the config for postlogin idle timeout
                        //web login banner reload
                        // if(!isMobileDevice()){
                        if (isFirstTime == true && !self.fromFPX && !self.fromEPayment) {
                            setTimeout(function () {
                                window.location.reload();
                            }, 20);
                        }
                        // }

                        //Check for firt time app launch to show welcome screen
                        // if (!localStorage.getItem('firstTime') || localStorage.getItem('firstTime') === true) {
                        //     togglePreLoginScreen('GET_STARTED');
                        // }
                    }


                    //prompt verify user finger popup
                    //check whether we have touchId or not

                }
                else if (result.invocationResult.statusCode === 503) {
                    showDowntimeTemplate(result.invocationResult.array.downTime);
                }
                else if (result.invocationResult.statusCode === 500) {

                    var downtime = {
                        "title":"We apologize for the inconvenience caused. Thank you for your understanding, we will be back online soon.",
                        "message":"We are currently undergoing system maintenance.",
                        "init": true
                    }

                    showDowntimeTemplate(downtime);
                }
                else {
                    if (result.invocationResult['error_description']) {
                        togglePreLoginScreen('INIT_FAIL');
                    } else {
                        console.log('Failed to load this page. Please check your connection and try again.');
                    }
                }

                loadingIcon.fadeOut();

                if (initOptions.onInitSuccess) {
                    initOptions.onInitSuccess();
                }
            };

            proto.initFailure = function (result) {
                var self = this;
                self.mfpInited = true;
                loadingIcon.fadeOut();
                togglePreLoginScreen('INIT_FAIL');
            };

            //new method
            proto.generateOTP = function (callback) {

            };

            proto.checkTouchIdAvailable = function (callback) {
                if (callback) {
                    callback(true);
                }
            };

            proto.checkRegisterFinger = function (callback) {
                if (callback) {
                    callback(true);
                }
            };

            proto.verifyFingerprint = function (successCallback, failedCallback) {
                console.log('verifyFingerprint done >> ');
				/*
				if (successCallback) {
					successCallback();
				}*/
                if (failedCallback) {
                    failedCallback();
                }
            };

            proto.getDeviceKey = function () {
                var deviceKey = localStorage.getItem('deviceKey');
                return deviceKey;
            };

            proto.showConfirmationPopupForRegisterTouch = function (callback) {
                if (callback) {
                    callback();
                }
            };

            proto.moveUserToSetting = function () {

            };

            proto.touchIdFlow = function () {
                var deviceKey = this.getDeviceKey();
                console.log('touchIdFlow ', deviceKey);
                if (deviceKey) {
                    var verifySuccess = function () {
                        var quickstart = $('.quickstart').val();

                        console.log('deviceKey ', deviceKey, quickstart);
                        // Adobe Analytics Tracking
                        digitalData.user = {
                            loginType: "touch id"
                        };

                        if (deviceKey) {
                            //already activated touchId
                            //touchId-normal flow
                            console.log('secure Login with Touch');
                            self.showLoading();
                            if (localStorage.getItem('activateSession')) {
                                localStorage.removeItem('activateSession');
                            }
                            callSecureLogin1(deviceKey, 'touch');

                        } else {
                            //not activated touchId
                            console.log('touchID doesnt have deviceKey');
                        }
                    };

                    var verifyFailed = function () {
                        console.log('verifyFailed ');
                        // do nothing
                    };

                    self.verifyFingerprint(verifySuccess, verifyFailed);


                } else {
                    console.log('touchID is not activated');
                    touchActivationFlow = true;
                    msgerActivationFlow = false;
                    $('#startHolderId').hide();
                    $('#cancelHolderId').show();
                    $('.js-touch-id-wrapper').hide();
                    touchContainer.show();
                    usn.val('');
                    usn.prev('label.label-on').removeClass('label-on');
                    usn.blur();
                }
            };

            // _.extend(proto);

            return proto;
        }

        var _instance = null;
        var exports = {
            getInstance: function (scope) {
                var args = Array.prototype.slice.call(arguments, 1);
                if (!_instance) {
                    scope = scope === window ? {} : scope;
                    _instance = run.apply(scope, args);
                }
                return _instance;
            }
        };

        return exports;
    }
)();

function onBackKeyDown() {
    return false;
}
document.addEventListener("backbutton", onBackKeyDown, false);

// set digitalData as global object for tracking
var digitalData = {};
var _satellite = window._satellite;

// Implement global timeout interval
var timeoutCB = null;
var TimeOutInterval = null;
var reminderCalled = false;
window.globalReminderFlag = true;

var startCheckingTimeOut = function (loginTime) {
    console.log('GLOBAL TIMER STARTING....');
    reminderCalled = false;
    var currentTime = moment().toISOString();
    var expires = parseFloat(loginTime) * 1000;
    TimeOutInterval = setInterval(function () { checkTime(currentTime, expires) }, 1000);
}
function checkTime(loginTime, expires) {
    var lastLoginTime = moment(loginTime).unix();
    var currentTime = moment().unix();
    // var reminderTime = moment(loginTime).add(1500000, 'milliseconds').unix();
    // var sessionTime = moment(loginTime).add(1800000, 'milliseconds').unix();
    // var reminderTime = moment(loginTime).add(expires - 500000, 'milliseconds').unix();
    var sessionTime = moment(loginTime).add(expires, 'milliseconds').unix();
    var logoutSession = moment.unix(sessionTime);
    var reminderTime = moment(logoutSession).subtract(30000, 'milliseconds').unix();

    // console.warn("global_ss session time up:", logoutSession._d);
    // console.warn("global_ss reminder time:", moment.unix(reminderTime)._d);
    // console.warn("global_ss current time:", moment.unix(currentTime)._d);

    if (currentTime >= reminderTime && currentTime < sessionTime && !reminderCalled && window.globalReminderFlag) {
        console.log('Timeout Reminder event Fired');
        reminderCalled = true;
        timeoutCB('REMINDER');
    }
    if (currentTime >= sessionTime && window.globalReminderFlag) {
        console.log('Timeout event Fired');
        clearInterval(TimeOutInterval);
        timeoutCB('TIMEOUT');
    }
}


// Implement Idle Timeout interval
var idleTimeoutCB = null;
var idleTimeOutInterval = null;
window.idleReminderCalled = false;
window.idleReminderFlag = true;

var preLoginIdleTimeoutCB = null;
var preLoginIdleTimeOutInterval = null;

var startIdleTimeout = function () {
    console.log('IDLE TIMER STARTING....');
    window.idleReminderCalled = false;

    //here is the init value (this value will reset upon each service call)
    window.currentTimeSession = moment(moment().toISOString()).unix();
    console.log('Init value for idle Session ', window.currentTimeSession);

    // RESET TIMER DURING MOUSEMOVE OR KEYPRESS
    $(document).mousemove(function (e) {
        if (!window.idleReminderCalled && window.idleReminderFlag) {
            window.currentTimeSession = moment(moment().toISOString()).unix();
            // console.log("idle reset");
        }
    });
    $(document).keypress(function (e) {
        if (!window.idleReminderCalled && window.idleReminderFlag) {
            window.currentTimeSession = moment(moment().toISOString()).unix();
            console.log("idle click reset");
        }
    });
    idleTimeOutInterval = setInterval(function () { checkIdleTime() }, 1000);
}
function checkIdleTime() {
    var currentTime = moment().unix();
    if (window.postLoginTime && window.currentTimeSession) {
        var currentSession = moment.unix(window.currentTimeSession);
        var logoutTime = moment(currentSession).add(window.postLoginTime, 'milliseconds').unix();
        var logoutSession = moment.unix(logoutTime);
        var reminderTime = moment(logoutSession).subtract(30000, 'milliseconds').unix();

        // console.warn("idle session time up:", logoutSession._d);
        // console.warn("idle reminder time:", moment.unix(reminderTime)._d);
        // console.warn("idle current time:", moment.unix(currentTime)._d);

        if (currentTime >= reminderTime && currentTime < logoutTime && !window.idleReminderCalled && window.idleReminderFlag) {
            console.log('Idle Timeout Reminder event Fired');
            window.idleReminderCalled = true;
            idleTimeoutCB('REMINDER');
        }
        if (currentTime >= logoutTime && window.idleReminderFlag) {
            console.log('Idle Timeout event Fired');
            clearInterval(idleTimeOutInterval);
            idleTimeoutCB('TIMEOUT');
        }
    }
}

function startPreLoginIdleTime() {
    console.log('PRE-LOGIN IDLE TIMER STARTING....');

    //here is the init value (this value will reset upon each service call)
    window.currentTimeSession = moment(moment().toISOString()).unix();
    console.log('Init value for idle Session ', window.currentTimeSession);

    // RESET TIMER DURING MOUSEMOVE OR KEYPRESS
    // $(document).mousemove(function (e) {
    //     window.currentTimeSession = moment(moment().toISOString()).unix();
    //     // console.log("idle reset");
    // });
    // $(document).keypress(function (e) {
    //     window.currentTimeSession = moment(moment().toISOString()).unix();
    //     console.log("idle click reset");
    // });
    preLoginIdleTimeOutInterval = setInterval(function () { checkPreLoginIdleTime() }, 1000);
}

function checkPreLoginIdleTime() {
    var currentTime = moment().unix();

    if (window.preLoginTime && window.currentTimeSession) {
        var currentSession = moment.unix(window.currentTimeSession);
        var logoutTime = moment(currentSession).add(window.preLoginTime, 'milliseconds').unix();
        var logoutSession = moment.unix(logoutTime);

        // console.warn("prelogin idle session time up:", logoutSession._d);
        // console.warn("prelogin idle current time:", moment.unix(currentTime)._d);

        if (currentTime >= logoutTime) {
            console.log('Idle Timeout event Fired');
            clearInterval(preLoginIdleTimeOutInterval);
            preLoginIdleTimeoutCB('TIMEOUT');
        }
    }
}

//save File
var saveAs = saveAs || (function (view) {
    "use strict";
    // IE <10 is explicitly unsupported
    if (typeof view === "undefined" || typeof navigator !== "undefined" && /MSIE [1-9]\./.test(navigator.userAgent)) {
        return;
    }
    var
        doc = view.document
        // only get URL when necessary in case Blob.js hasn't overridden it yet
        , get_URL = function () {
            return view.URL || view.webkitURL || view;
        }
        , save_link = doc.createElementNS("http://www.w3.org/1999/xhtml", "a")
        , can_use_save_link = "download" in save_link
        , click = function (node) {
            var event = new MouseEvent("click");
            node.dispatchEvent(event);
        }
        , is_safari = /constructor/i.test(view.HTMLElement)
        , is_chrome_ios = /CriOS\/[\d]+/.test(navigator.userAgent)
        , throw_outside = function (ex) {
            (view.setImmediate || view.setTimeout)(function () {
                throw ex;
            }, 0);
        }
        , force_saveable_type = "application/octet-stream"
        // the Blob API is fundamentally broken as there is no "downloadfinished" event to subscribe to
        , arbitrary_revoke_timeout = 1000 * 40 // in ms
        , revoke = function (file) {
            var revoker = function () {
                if (typeof file === "string") { // file is an object URL
                    get_URL().revokeObjectURL(file);
                } else { // file is a File
                    file.remove();
                }
            };
            setTimeout(revoker, arbitrary_revoke_timeout);
        }
        , dispatch = function (filesaver, event_types, event) {
            event_types = [].concat(event_types);
            var i = event_types.length;
            while (i--) {
                var listener = filesaver["on" + event_types[i]];
                if (typeof listener === "function") {
                    try {
                        listener.call(filesaver, event || filesaver);
                    } catch (ex) {
                        throw_outside(ex);
                    }
                }
            }
        }
        , auto_bom = function (blob) {
            // prepend BOM for UTF-8 XML and text/* types (including HTML)
            // note: your browser will automatically convert UTF-16 U+FEFF to EF BB BF
            if (/^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(blob.type)) {
                return new Blob([String.fromCharCode(0xFEFF), blob], { type: blob.type });
            }
            return blob;
        }
        , FileSaver = function (blob, name, no_auto_bom) {
            if (!no_auto_bom) {
                blob = auto_bom(blob);
            }
            // First try a.download, then web filesystem, then object URLs
            var
                filesaver = this
                , type = blob.type
                , force = type === force_saveable_type
                , object_url
                , dispatch_all = function () {
                    dispatch(filesaver, "writestart progress write writeend".split(" "));
                }
                // on any filesys errors revert to saving with object URLs
                , fs_error = function () {
                    if ((is_chrome_ios || (force && is_safari)) && view.FileReader) {
                        // Safari doesn't allow downloading of blob urls
                        var reader = new FileReader();
                        reader.onloadend = function () {
                            var url = is_chrome_ios ? reader.result : reader.result.replace(/^data:[^;]*;/, 'data:attachment/file;');
                            var popup = view.open(url, '_blank');
                            if (!popup) view.location.href = url;
                            url = undefined; // release reference before dispatching
                            filesaver.readyState = filesaver.DONE;
                            dispatch_all();
                        };
                        reader.readAsDataURL(blob);
                        filesaver.readyState = filesaver.INIT;
                        return;
                    }
                    // don't create more object URLs than needed
                    if (!object_url) {
                        object_url = get_URL().createObjectURL(blob);
                    }
                    if (force) {
                        view.location.href = object_url;
                    } else {
                        var opened = view.open(object_url, "_blank");
                        if (!opened) {
                            // Apple does not allow window.open, see https://developer.apple.com/library/safari/documentation/Tools/Conceptual/SafariExtensionGuide/WorkingwithWindowsandTabs/WorkingwithWindowsandTabs.html
                            view.location.href = object_url;
                        }
                    }
                    filesaver.readyState = filesaver.DONE;
                    dispatch_all();
                    revoke(object_url);
                }
                ;
            filesaver.readyState = filesaver.INIT;

            if (can_use_save_link) {
                object_url = get_URL().createObjectURL(blob);
                setTimeout(function () {
                    save_link.href = object_url;
                    save_link.download = name;
                    click(save_link);
                    dispatch_all();
                    revoke(object_url);
                    filesaver.readyState = filesaver.DONE;
                });
                return;
            }

            fs_error();
        }
        , FS_proto = FileSaver.prototype
        , saveAs = function (blob, name, no_auto_bom) {
            return new FileSaver(blob, name || blob.name || "download", no_auto_bom);
        }
        ;
    // IE 10+ (native saveAs)
    if (typeof navigator !== "undefined" && navigator.msSaveOrOpenBlob) {
        return function (blob, name, no_auto_bom) {
            name = name || blob.name || "download";

            if (!no_auto_bom) {
                blob = auto_bom(blob);
            }
            return navigator.msSaveOrOpenBlob(blob, name);
        };
    }

    FS_proto.abort = function () { };
    FS_proto.readyState = FS_proto.INIT = 0;
    FS_proto.WRITING = 1;
    FS_proto.DONE = 2;

    FS_proto.error =
        FS_proto.onwritestart =
        FS_proto.onprogress =
        FS_proto.onwrite =
        FS_proto.onabort =
        FS_proto.onerror =
        FS_proto.onwriteend =
        null;

    return saveAs;
}(
    typeof self !== "undefined" && self
    || typeof window !== "undefined" && window
    || this.content
    ));
//end save File
function retrievePushNotificationMsg(msg) {
    alert('message receive ' + msg);
    console.log('message receive ', msg);
}


var cancelWs = false;
function logoutOnExit(){

    console.log('logoutOnExit >>>>>>>>>');

    var success = function (result) {
        console.log('Success >>>', result);
        MFPInit.logoutUser({});
    }
    var fail = function (result) {
        
        console.log('Fail >>>', result);
        MFPInit.logoutUser({});
    }
    var successFpx = function (result) {
        console.log('Success >>>', result);
        cancelWs = true;
        MFPInit.logoutUser({});
    }

    var failFpx = function (result) {
        cancelWs = false;
        console.log('Fail >>>', result);
        MFPInit.logoutUser({});
    }

    if (window.fromFPX){

        var hashKey = window.hashKeyValue;
        var hashMac = MFPInit.getHashMAC('', hashKey, moment().toISOString());
        requestHeader = { Authorization: window.authorizationKey, ChannelAuthCode: hashMac, FpxRefId: self.refId };
        if(!cancelWs && localStorage.getItem('isCancel') !== 'yes'){
             
            cancelWs = true;
            ServiceProvider.ServiceHub.getDataByService(ServiceProvider.ServiceType.SERVICE_FPX_CANCEL_PRE_LOGIN, [requestHeader,'','loginpage'], {},successFpx,failFpx);
        }
    }
    else {
        ServiceProvider.ServiceHub.getDataByService(ServiceProvider.ServiceType.SERVICE_LOGOUT, [uniqueDeviceId], {}, success, fail);
    }

    console.log('End logoutOnExit');
}

function cmIdPassCheck() {
    var cmId = localStorage.getItem("cmId");
    var cmPassword = localStorage.getItem("cmPass");
    if (cmId && cmPassword) {
        return true;
    }
    return false;
}

function onMessengerNewMessage(openWindow) {
    var cmId = localStorage.getItem("cmId");
    var appVersion = localStorage.getItem("appVer");
    var msgCountData = "cmId=" + cmId + "&appCode=1&appVersion=" + appVersion + "msgType=0";
    // show the bell
    if (cmId) {
        jQuery('.navbar-note').show();
        console.log("CMServer: msgCount.do: call: ", msgCountData);
        jQuery.ajax({
            type: "POST",
            url: "http://49.50.12.54/CMService/msgCount.do",
            crossDomain: true,
            data: msgCountData,
            dataType: "xml",
            success: function (xml) {
                console.log("CMServer: msgCount.do: success: ", xml);
                var msgCount = jQuery(xml).find("count").text();
                var msgCountInt = parseInt(msgCount);
                console.log("CMServer: msgCount.do: success: msgCount: " + msgCountInt);
                localStorage.setItem("msgCount", msgCountInt);

                if (msgCountInt > 0) {
                    // show the black circle
                    jQuery('.notice').show();
                    jQuery('.notice').text(msgCountInt);
                    if (openWindow) {
                        $('.navbar-note').click();
                    }
                } else {
                    jQuery('.notice').hide();
                    jQuery('.notice').text('');
                }
            }
        });
    }
}

function increaseMessengerMessageCount(count) {
    var count = count || 1;
    var existingCount = jQuery('.notice').text() || 0;
    var newCount = count + parseInt(existingCount);
    jQuery('.notice').show();
    jQuery('.notice').text(newCount);
}


function loadedGoogleApifile(){
    return Login.getInstance().loadGcaptcha();
}
