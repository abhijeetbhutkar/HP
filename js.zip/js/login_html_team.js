//global encryptMY
var AuthRealmChallengeHandler = WL.Client.createChallengeHandler('AuthRealm');
var loadingIcon = $('#preload');
var loginType = null;
var XAuthId = null;
var uniqueDeviceId = '';

loadingIcon.fadeIn();
(function() {
	'use strict';
	var quickstartHtml = $('select.quickstart').html();
	var secureWord = $('#secure-img');
	if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
		$('body').addClass('mobile');
		//add quick start mobile with quick balance option
		$('select.quickstart').html($('#mobile-quickstart').html() + quickstartHtml);
	//	$('select.quickstart').html($('#desktop-quickstart').html() + quickstartHtml);
	} else {
		//add quick start mobile without quick balance
		$('select.quickstart').html($('#desktop-quickstart').html() + quickstartHtml);
	}

	var formStep1 = $('#login-form-step1');
	var formStep2 = $('#form-login_step2');
	var usn = $('#user-id');
	var pas = $('#password');
	var serviceActivation = $('.mobile .service-activation');
	var serviceActivationClose = serviceActivation.find('.back-btn, .close-service');
	var serviceQuickBalance = serviceActivation.find('.quick-balance');
	var serviceTac = serviceActivation.find('.tac-verification');
	var serviceTouchId = serviceActivation.find('.touch-id-verification');
	var serviceTacMobile = serviceActivation.find('.tac-on-mobile');
	var serviceTacGen = serviceActivation.find('.tac-generator');
	var loginTimes = 0;

	var userProfile = [
		{
			'id': '1',
			'userType': 'new_user',
			'userName': 'newUser1',
			'password': '9999',
			'lastLogin': '',
			'quickbalance': false,
			'authorized': false,
			'status': '1'

		}, {
			'id': '2',
			'userType': 'exist_user',
			'userName': 'existingUser',
			'password': '9999',
			'lastLogin': '2015-12-25 12:00:00',
			'quickbalance': false,
			'authorized': false,
			'status': '1'
		}, {
			'id': '3',
			'userType': 'block_user',
			'userName': 'blockUser',
			'password': '9999',
			'lastLogin': '2015-12-25 12:00:00',
			'quickbalance': false,
			'authorized': false,
			'status': '0'
		}, {
			'id': '4',
			'userType': 'exist_user',
			'userName': 'vijay1980',
			'password': '9999',
			'quickbalance': false,
			'authorized': false,
			'lastLogin': '2016-01-31 13:00:00'
		}, {
			'id': '5',
			'userType': 'exist_user',
			'userName': 'username',
			'password': '9999',
			'quickbalance': false,
			'authorized': false,
			'lastLogin': '2016-01-31 13:00:00'
		}
	];

	var showConfirmation = function (tl, msg, yesCb, noCb) {
		var md = $('#modal-confirm-mobile');
		md.find('#header h1').text(tl);
		md.find('#content p').html(msg);
		md.fadeIn();
		md.find('.btn-yes').on('click', function() {
			md.fadeOut();
			yesCb();
		});

		md.find('.btn-no').on('click', function() {
			md.fadeOut();
			noCb();
		});
	};

	var isQuickBalanceRegister = function (user) {
		//Apply logic to get account register Quick Balance on page
		// this is just Simple switch new user as unregister quick balance.
		if (user === 'new_user') {
			return false;
		}
		return false;
	};

	var showService = function (service) {
		serviceActivation.find('.activate').fadeOut(function () {
			service.fadeIn();
		});
	};


	var validateForm = function(FormObj, FormObj2) {
		var validate = false;
		// var validUsername = false;
		// var validateUsername = function() {
		// 	userProfile.forEach(function(item) {
		// 		if (item.userName.toLowerCase() === usn.val().toLowerCase()) {
		// 			// validateUsername = true;
		// 			return true;
		// 		} else {
		// 			return false;
		// 		}
		// 	});
		// };
		var validateUsername = function() {
			//Verifying username and get Secure word
			console.log('trigger loading status & verify username');
			loadingIcon.fadeIn();
			localStorage.setItem('userSession', usn.val());
			callSecureLogin1(usn.val());

			//FIXME: temporary hardcode this for not having broken flow
			var temporaryData = {
				"id":"2",
				"userType":"exist_user",
				"userName":"existingUser",
				"lastLogin":"2015-12-25 12:00:00",
				"quickbalance":false,
				"authorized":true,
				"status":"1"
			};
			localStorage.setItem('userSession', JSON.stringify(temporaryData));
		};
		var verifyData = function() {
			//Verifying username and password
			console.log('show loading and verify username - password');
			loadingIcon.fadeIn();
			callSecureLogin2(usn.val(), pas.val());
			/*
			//Sample Loop through data to validate data user
			userProfile.forEach(function(item) {
				if (item.userName.toLowerCase() === usn.val().toLowerCase() && item.password.toLowerCase() === pas.val().toLowerCase()) {
					console.log('valid username & password', 'check status and lastLogin');
					if (item.status === '0') {
						console.log('blocked account');
						loginTimes = 2;
					} else {
						var redirectUrl = 'dashboard.html';
						var selectedOption = $('select.quickstart').val();

						switch (selectedOption) {
							case 'NV':
								localStorage.setItem('NV', true);
								redirectUrl = 'dashboard.html#/dashboard/pay-bills';
								break;
							case 'quickpay':
								localStorage.setItem('quickPay', true);
								redirectUrl = 'dashboard.html#/dashboard/pay-bills';
								break;
							case 'CA':
								localStorage.setItem('CA', true);
								redirectUrl = 'dashboard.html#/dashboard/fund-transfer';
								break;
							case 'JP':
								localStorage.setItem('JP', true);
								redirectUrl = 'dashboard.html#/dashboard/jom-pay';
								break;
							case 'OR':
								localStorage.setItem('OR', true);
								redirectUrl = 'dashboard.html#/dashboard/pay-loan';
								break;
							case 'topUp':
								localStorage.setItem('topUp', true);
								redirectUrl = 'dashboard.html#/dashboard/topup';
								break;
							// case 'quickpay':
							// 	localStorage.setItem('OR', true);
							// 	redirectUrl = 'dashboard.html#/dashboard/pay-loan';
							// 	break;
							default:
								if (document.body.classList.contains('mobile')) {
									redirectUrl = 'dashboard.html#/tac-activation';
								} else {
									redirectUrl = 'dashboard.html#/dashboard';
								}

						}

						delete item.password;
						item.authorized = true;
						localStorage.setItem('userSession', JSON.stringify(item));
						validate = true;
						if (localStorage.getItem('tacOnApp') && $('.main-content').hasClass('tac-activation-login')) {
							serviceActivation.fadeIn(function() {
								showService(serviceTac);
							});
						} else {
							window.location.href = redirectUrl;
						}
					}
				}
			});
			if (!validate) {
				loginTimes++;

				if (loginTimes >= 3) {
					$('.js_blocked_message').addClass('active-error');
					usn.prop('disabled', true).removeClass('valid');
					pas.prop('disabled', true).removeClass('valid');
				} else {
					console.log('invalid login');
					$('.js_error_message').addClass('active-error');
					usn.val('').removeClass('valid').addClass('invalid error');
					pas.val('').removeClass('valid').addClass('invalid error');
				}

				//invalid show step 1 login
				formStep2.fadeOut(function() {
					nextForm(formStep1);
					usn.blur();
					$('div.error').remove();
				});
				// formStep2.css({opacity: 1})
				// 		.animate({opacity: 0}, function() {
				// 			$(this).hide();
				// 			nextForm(formStep1);
				// 			usn.blur();
				// 			$('div.error').remove();
				// 		});
			}
			*/
		};

		FormObj.validate({
			errorElement: 'div',
			submitHandler: function() {
				console.log('checking Quick Balance Register Status');
				var quickstart = $('.quickstart').val();
				if (usn.val().toLowerCase() === 'existinguser' &&  quickstart.toLowerCase() === 'quickbalance') {
					console.log('start quick balance modal confirmation');
					showConfirmation(
						'Quick Balance',
						'You have yet enable Quick Balance.<br>Enable Now',
						function() {
							if (!isQuickBalanceRegister(usn.val())) {
								serviceActivation.fadeIn(function () {
									serviceQuickBalance.fadeIn();
								});
							}
						},
						function() {
							console.log('no option callback');
						}
					);
				} else {
					console.log('other user login validate password before show quickbalance activation');
					//$('#modal-confirm-mobile').fadeIn();
					formStep1.fadeOut(function() {
						nextForm(formStep2);
						if (!checkMobile()) {
							setTimeout(function() {$('#password').focus();}, 700);
						}
					});
					// formStep1.animate({opacity: 0}, function() {
					// 	formStep1.hide();
					// 	nextForm(formStep2);
					// 	if (!checkMobile()) {
					// 		setTimeout(function() {$('#password').focus();}, 700);
					// 	}
					// });
				}

				if (!FormObj2) {
					verifyData();
				} else {
					validateUsername();
				}
			},
			invalidHandler: function() {
				validate = false;
			},
			messages: {
				username: {
					required: 'This field is required',
					minlength: 'Please enter at least 8 characters'
				},

				password: {
					required: 'This field is required'
				}
			}
		});
		return validate;
	};

	var nextForm = function($FormObj) {
		$FormObj.fadeIn();
	};

	//Move to password screen on quick balance return
	if (localStorage.getItem('userSession')) {
		var session = JSON.parse(localStorage.getItem('userSession'));
		if (session.quickbalance) {
			usn.val(session.userName);
			$('select.quickstart').val('overview');
			formStep1.hide();
			nextForm(formStep2);
		}
	}

	//dropdown
	$('.dropdown-menu li').on('click', function(e) {
		// console.log("selected" , e.currentTarget);
		var targetElement = $(e.currentTarget);
		targetElement.addClass('active');
		$(this).next().removeClass('active');
		$(this).prev().removeClass('active');
	});

	var $customSelects = $('select.quickstart');
	$customSelects.select2({
		minimumResultsForSearch: Infinity
	});

	$customSelects.each(function(index, el) {
		/**
		 * Init scroll
		 */
		var select2Data = $(el).data('select2');
		select2Data.$dropdown.find('.select2-results__options').scrollbar({
			ignoreMobile: true,
			ignoreOverlay: true
		});
	});

	$('.login-form .btn-primary').on('click', function() {
		if (loginTimes >= 3) {
			return false;
		}

		if (validateForm(formStep1, formStep2)) {
			$('.js_blocked_message').hide();
			$('.js_error_message').hide();
			console.log('login times', loginTimes);
		}
	});

	$('.login-form .btn-next').on('click', function() {
		console.log('Clear passssssssss');
		$('#password').val('');
		$('.passwordsInputId').removeClass('active');
	});

	$('.btn-login').on('click', function() {
		if (loginTimes >= 3) {
			return false;
		}

		if (validateForm(formStep2, null)) {
			console.log('login times', loginTimes);
		}
	});

	$('.js-tac-activation').on('click', function() {
		if (localStorage.getItem('tacOnApp')) {
			showService(serviceTacGen);
		} else {
			showService(serviceTacMobile);
		}
		serviceActivation.fadeIn();
	});

	serviceActivation.find('.show-touch').on('click', function() {
		showService(serviceTouchId);
	});

	serviceActivation.find('.show-login').on('click', function() {
		console.log('show login processing add class show and element on login form');
		$('select.quickstart').val('overview');
		serviceActivation.fadeOut(function() {
			serviceTacMobile.hide();
		});
		$('.mobile .main-content').addClass('tac-activation-login');
		if (!localStorage.getItem('tacOnApp')) {
			localStorage.setItem('tacOnApp', false);
		}
	});

	serviceActivation.find('.show-tac-sms').on('click', function() {
		showService(serviceTac);
	});

	serviceActivation.find('.show-tac').on('click', function() {
		// showService(serviceTac);
		userProfile.forEach(function(item) {
			if (item.userName.toLowerCase() === usn.val().toLowerCase()) {
				delete item.password;
				item.quickbalance = true;
				localStorage.setItem('userSession', JSON.stringify(item));
			}
		});
		window.location.href = 'dashboard.html#/dashboard/home';
	});

	serviceActivation.find('.get-new-tac').on('click', function() {
		var ranNumber = Math.ceil(Math.random() * 1000000);
		serviceTacGen.find('.tac-value').html(ranNumber);
	});

	serviceActivation.find('.confirm-quick-balance').on('click', function() {
		console.log('validate TAC SMS');
		window.location = 'dashboard.html';
	});

	// serviceActivation.find('.confirm-quick-balance').on('click', function() {
	// 	userProfile.forEach(function(item) {
	// 		if (item.userName.toLowerCase() === usn.val().toLowerCase()) {
	// 			delete item.password;
	// 			item.quickbalance = true;
	// 			localStorage.setItem('userSession', JSON.stringify(item));
	// 		}
	// 	});
	// 	window.location.href = 'dashboard.html#/dashboard/home';
	// 	// serviceActivation.fadeOut(function() {
	// 	// 	this.find('.activate').hide();
	// 	// });
	// });

	$('.tac-activation-cancel').on('click', function() {
		serviceActivation.fadeOut(function() {
			$('.mobile .main-content').removeClass('tac-activation-login');
			serviceActivation.find('.activate').hide();
			serviceActivation.css({height: ''});
			$('.mobile .login-wrapper .override-scroller').css({'margin-top': ''});
			serviceActivation.removeClass('show-login');
		});
	});
	serviceActivationClose.on('click', function() {
		serviceActivation.fadeOut(function() {
			$('.mobile .main-content').removeClass('tac-activation-login');
			serviceActivation.find('.activate').hide();
			serviceActivation.css({height: ''});
			$('.mobile .login-wrapper .override-scroller').css({'margin-top': ''});
			serviceActivation.removeClass('show-login');
		});
	});

	//arrow back form-step-1
	$('.login-form .arrow-back').on('click', function(/*e*/) {
		formStep2.fadeOut(function () {
			nextForm(formStep1);
		});
		// formStep2.css({opacity: 1})
		// 		.animate({opacity: 0}, function() {
		// 			$(this).hide();
		// 			nextForm(formStep1);
		// 		});
	});

	initSideBar();

	//Event handler Keypress Enter
	// $('#user-id').keypress(function(event) {

	// 	if (event.which === 13) {
	// 		event.preventDefault();
	// 		// $('select').select2('open');
	// 		// console.log('Enter');
	// 		// return false;
	// 	}
	// });


	// $(document).keypress(function(event) {
	// 	if (event.which === 13) {
	// 		event.preventDefault();
	// 		if (formStep1.css('display') === 'block') {
	// 			alert('Please click \'Next\' to proceed.');
	// 		} else {
	// 			alert('Please click \'Login\' to proceed.');
	// 		}
	// 	}
	// });


	//for fixing issue: keyboard overlap textinput
	var $targetElement = null;

	$('#user-id, #password').focusin(function(event) {
		$targetElement = $(event.currentTarget);
		$('.js_error_message').removeClass('active-error');
		$(document).find('input.error').removeClass('invalid').removeClass('error');
	});
	$('#user-id, #password').focusout(function() {
		$targetElement = null;
		// $('.js_error_message').removeClass('active-error');
	});

	$(window).resize(function() {
		// console.log('resize');
		if (!$targetElement) { return; }
		//fix me, move up depend on the height of the top banner on mobile
		var bannerHeight = $('.banner-mob.login-mob').height();

		var $mainElement = $('.mobile .main-content');
		// var windowHeight = $(window).height();
		// //console.log('windowHeight ', windowHeight);
		// var userIdPos = $targetElement.offset().top;
		// var topPos = userIdPos - windowHeight + 50;

		setTimeout(function() {
			$mainElement.animateScroll(bannerHeight);
		}, 200);
	});



	// init Fastclick on doc ready
	$(function() {
		/*global FastClick*/
		if ('FastClick' in window) {
			FastClick.attach(document.body);
		}

		// binding hybrid Messenger module
		/* global WebView*/
		if ('WebView' in window) {
			$('.navbar-note').on('click', function() {
				// TODO: temporary hardcode the messenger URL for now
				WebView.show('messenger/index.html');
			});
		}
	});

	var currentState = '';

	$(function() {
		//add event listener
		/*
		$('.octo-update-available .octo-button').on('click', function() {
			togglePreLoginScreen('UPDATE_AVAILABLE_SKIP');
		});*/
		$('.js-get-started-container .js-get-start-btn').on('click', function() {
			togglePreLoginScreen('UPDATE_AVAILABLE');
		});
		$('#octo-screen .btn-close').on('click', function() {
			togglePreLoginScreen('HIDE_ALL');
		});
		$('.octo-update-available .octo-link-skip-container').on('click', function() {
			togglePreLoginScreen('DEVICE_JAILBROKEN');
		});
		$('.octo-update-available .octo-button').on('click', function() {
			//console.log('aaaa', currentState);
			if (currentState === 'UPDATE_AVAILABLE') {
				togglePreLoginScreen('UPDATE_AVAILABLE_SKIP');
			} else if (currentState === 'UPDATE_AVAILABLE_SKIP') {
				togglePreLoginScreen('DEVICE_ROOTED');
			} else if (currentState === 'DEVICE_ROOTED') {
				togglePreLoginScreen('DEVICE_JAILBROKEN');
			} else if (currentState === 'DEVICE_JAILBROKEN') {
				togglePreLoginScreen('HIDE_ALL');
			} else if (currentState === 'OPEN_IN_APP') {
				togglePreLoginScreen('OPEN_IN_APP');
			} else if (currentState === 'INSTALL_APP') {
				togglePreLoginScreen('INSTALL_APP');
			}
		});

		$('.js-touch-id').on('click', function() {
			//Turn Off Get Started
			if (checkMobile()) {
				togglePreLoginScreen('UPDATE_AVAILABLE');
			}
		});

		/*
		//Turn Off Get Started
		if (checkMobile()) {
			togglePreLoginScreen('UPDATE_AVAILABLE');
		}*/
	});

	function checkMobile() {
		if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Toggle screens for "Update Available", Update Available with Skip", "Device Rooted", "Device Jailbroken", "Hide All".
	 *
	 * @param {string} screenType - Screen type should be
	 * - UPDATE_AVAILABLE
	 * - UPDATE_AVAILABLE_SKIP
	 * - DEVICE_ROOTED
	 * - DEVICE_JAILBROKEN
	 * - HIDE_ALL
	 * - GET_STARTED
	 *
	 * @returns {undefined} - Nothing is returned
     */
	function togglePreLoginScreen(screenType) {
		var octoScreen = $('#octo-screen');
		var octoGrayMobile = $('.octo-gray-mobile');
		var octoGrayWink = $('.octo-gray-wink');
		var octoTitle = $('.octo-title');
		var octoDescription = $('.octo-description');
		var octoButtonText = $('.octo-button-text');
		// var octoButton = $('.octo-button');
		var octoLinkSkipContainer = $('.octo-link-skip-container');
		// var octoLinkSkip = $('.octo-link-skip');

		var btnClose = octoScreen.find('.btn-close');
		var isIos = /iPad|iPhone|iPod/.test(navigator.userAgent);
		//$(octoLinkSkip).click(skip);
		currentState = screenType;
		btnClose.hide();

		if (screenType === 'UPDATE_AVAILABLE') {
			$(octoScreen).show();
			$(octoGrayMobile).show();
			$(octoGrayWink).hide();
			$(octoTitle).text('Update is Available');
			$(octoDescription).text('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur orci orci, vehicula non semper quis, efficitur at velit.');
			$(octoButtonText).text('Update Now');
			//octoButton.on('click', updateNow);
			$(octoLinkSkipContainer).hide();
		} else if (screenType === 'UPDATE_AVAILABLE_SKIP') {
			$(octoScreen).show();
			$(octoGrayMobile).show();
			$(octoGrayWink).hide();
			$(octoTitle).text('Update is Available');
			$(octoDescription).text('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur orci orci, vehicula non semper quis, efficitur at velit.');
			$(octoButtonText).text('Update Now');
			//$(octoButton).click(updateNow);
			$(octoLinkSkipContainer).show();
		} else if (screenType === 'DEVICE_ROOTED') {
			$(octoScreen).show();
			$(octoGrayMobile).hide();
			$(octoGrayWink).show();
			if (isMobile) {
				if (isIos) {
					$(octoTitle).text('This device is jailbroken');
				} else {
					$(octoTitle).text('This device is rooted');
				}
			}
			$(octoDescription).text('You will not be able to use CIMB Clicks on this device due to security vulnerability');
			$(octoButtonText).text('Exit');
			//$(octoButton).click(okIUnderstand);
			$(octoLinkSkipContainer).hide();
		} else if (screenType === 'DEVICE_JAILBROKEN') {
			$(octoScreen).show();
			$(octoGrayMobile).hide();
			$(octoGrayWink).show();
			$(octoTitle).text('Your Device is Jailbroken');
			$(octoDescription).text('Your device appears to jailbroken. It may cause serious security issue. For further information, please contact xxx@cimb.com');
			$(octoButtonText).text('Ok, I Understand');
			//$(octoButton).click(okIUnderstand);
			$(octoLinkSkipContainer).hide();
		} else if (screenType === 'GET_STARTED') {
			$('.login-wrapper').hide();
			$('.js-get-started-container').show();

		} else if (screenType === 'HIDE_ALL') {
			$(octoScreen).hide();
			$('.login-wrapper').show();
			$('.js-get-started-container').hide();
		} else if (screenType === 'OPEN_IN_APP') {
			$(octoScreen).show();
			$(octoGrayMobile).show();
			$(octoGrayWink).hide();
			$(octoTitle).text('');
			$(octoDescription).text('Try the all new CIMB Clicks app for better and faster experience.');
			$(octoButtonText).text('Open in app');
			btnClose.show();
			$(octoLinkSkipContainer).hide();
		} else if (screenType === 'INSTALL_APP') {
			$(octoScreen).show();
			$(octoGrayMobile).show();
			$(octoGrayWink).hide();
			$(octoTitle).text('');
			$(octoDescription).text('Try the all new CIMB Clicks app for better and faster experience.');
			$(octoButtonText).text('Install app');
			btnClose.show();
			$(octoLinkSkipContainer).hide();
		}
	}

	// function getStart() {
	// 	togglePreLoginScreen('UPDATE_AVAILABLE');
	// }

	/**
	 * Do an instant update, after the user clicks on "Update Now" button in the "Update Available" screen.
	 * @return {undefined} - TBC
	 */
	// function updateNow() {
	// 	//console.log('Action: Update now');
	// 	togglePreLoginScreen('UPDATE_AVAILABLE_SKIP');
	// }

	/**
	 * Proceed to login, after the user clicks on "Ok, I Understand" button in the "Device Rooted" and "Device Jailbroken" screen.
	 * @return {undefined} - TBC
	 */
	// function okIUnderstand() {
	// 	console.log('Action: Ok, I Understand');
	// }

	/**
	 * Skip the instant update
	 * @return {undefined} - TBC
	 */
	// function skip() {
	// 	console.log('Action: Skip');
	// }

	function initSideBar() {
		var $loginWraper = $('.login-wrapper');
		var $body = $('body');

		var removeEvent = function() {
			$body.off('click', '.js-sidebar-overlay-slide');
		};

		var toggleSideBar = function() {
			var openCls = 'sidebar-open';
			var $sidebarElement = $('.login-wrapper .sidebar-login');

			if ($sidebarElement.hasClass(openCls)) {
				$sidebarElement.removeClass(openCls);
				document.body.classList.remove('sidebar-open');
			} else {
				$sidebarElement.addClass(openCls);
				document.body.classList.add('sidebar-open');
			}
		};

		var getSidebarStatus = function() {
			return $('.login-wrapper .sidebar-login').hasClass('sidebar-open');
		};

		$loginWraper.on('click', '.navbar-toggle', function() {
			// var openCls = 'sidebar-open';

			// toggle the sidebar
			toggleSideBar();

			if (getSidebarStatus()) {
				$body.on('click', '.js-sidebar-overlay-slide', function(e) {
					e.preventDefault();
					e.stopPropagation();

					toggleSideBar();
					removeEvent();
				}.bind(this));
			} else {
				removeEvent();
			}
		});

		$loginWraper.on('click', '.menu-items .clickable', function() {
			$('li').removeClass('active');
			$(this).parent().addClass('active');
			toggleSideBar();
			removeEvent();
		});
	}

	$('.scrollable').scrollbar({
		ignoreMobile: true,
		ignoreOverlay: true
	});

	$('.owl-carousel').owlCarousel({
		slideSpeed: 400,
		paginationSpeed: 400,
		singleItem: true,
		addClassActive: true,
		afterMove: function() {
			var imgBg = $('.carousel-bg img.login-sl');
			var indexNo = this.currentItem;
			imgBg.removeClass('active');

			$(imgBg[indexNo]).css({opacity: 0, display: 'block'})
							.animate({opacity: 1}, function() {
								$(this).addClass('active');
								$('.carousel-bg img.login-sl:not(.active)').animate({opacity: 0});
							});
		}
	});
	$('input').keyup(function(event) {
		// formStep1.valid();
		if (event.keyCode !== 13) {
			$('.js_error_message').removeClass('active-error');
			$(document).find('input.error').removeClass('invalid').removeClass('error');
		}
	});

	$('input#password').keyup(function (event) {
		if (event.keyCode !== 13) {
			var hasvalue = $(this).val();
			if (!hasvalue) {
				$('.btn-login').trigger('click');
			}
		}
	});

	$('input#user-id').keyup(function (event) {
		if (event.keyCode !== 13) {
			var hasvalue = $(this).val();
			if (!hasvalue) {
				$('.login-form .btn-next').trigger('click');
			}
		}
	});

	$(document).on('keyup', 'input.error', function () {
		// $(document).find('input.error').removeClass('invalid').removeClass('error');
	});



	// Secure Login Step 1--------------------
	function callSecureLogin1(username) {
		console.log('username Step1: ', username);
		var timeStamp = getCurrentTime();

		var requestBody = {
			'requestHeader': {
				'channelTime': timeStamp,
				'deviceId': uniqueDeviceId
			},
			'requestBody': {
				'username' : username,
				'grant_type': 'ibs_credential'
			}
		};
		var hashKey = window.hashKeyValue;
		var hashMac = getHashMAC(JSON.stringify(requestBody), hashKey, timeStamp);

		var requestHeader = {
			Authorization : window.configData.authorizationKey,
			ChannelAuthCode : hashMac
		};

		var invocationData = {
			adapter: 'authAdapter',
			procedure: 'SecureWordLoginStep1',
			parameters: [requestHeader, requestBody]
		};
		var options = {
			onSuccess: loginStep1Success,
			onFailure: loginStep1Failure,
			invocationContext: {}
		};

		console.log('Request Header loginstep1 : ', JSON.stringify(requestHeader));
		console.log('Request Body loginstep1 : ', JSON.stringify(requestBody));
		WL.Client.invokeProcedure(invocationData, options);
	}

	function loginStep1Success(result) {
		if (result.invocationResult.statusCode === 200) {
			if (result.invocationResult.responseHeaders['x-cs-status']  === 'error') {
				alert(result.invocationResult['error_description']);
			}
			else {
				console.log ('Response Success LoginStep1 : ', result);
				XAuthId = result.invocationResult.authId;
				console.log('XAUTHHHHID', XAuthId);

				var imgType = 'data:image/png;base64,';
				formStep1.animate({opacity: 0}, function() {
					formStep1.hide();
					secureWord.attr('src', imgType + result.invocationResult.secureWord);
					nextForm(formStep2);
				});
			}
		}
		else {
			if (result.invocationResult['error_description']) {
				alert(result.invocationResult['error_description']);
			}
			else {
				alert('Failed to load this page. Please check your connection and try again.');
			}

		}

		loadingIcon.fadeOut();
	}
	function loginStep1Failure(result) {
		console.log('Response Failed LoginStep1 : ', result);
		alert(result.errorMsg);
		loadingIcon.fadeOut();
	}

	window.completeStep2 = function() {
		console.log('window.completeStep2');

		$('.js_error_message').addClass('active-error');
		usn.val('').removeClass('valid').addClass('invalid error');
		pas.val('').removeClass('valid').addClass('invalid error');
		formStep2.css({opacity: 1})
				.animate({opacity: 0}, function() {
					$(this).hide();
					nextForm(formStep1);
					usn.blur();
					$('div.error').remove();
					loadingIcon.fadeOut();
				});
	};

	// Secure Login Step 2---------------------------
	function callSecureLogin2(username, password) {
		var encryptedPass = encryptMY(password);
		var timeStamp = getCurrentTime();
		console.log('username Step2: ', username);
		console.log('encryp pass Step2: ', encryptedPass);

	//TODO App related details should either come from Native or MFP
	//TODO jailbroken should be dynamic added in ver 1.2
		var requestBody = {
			'requestHeader': {
				'channelTime': timeStamp,
				'deviceId': uniqueDeviceId
			},
			'requestBody': {
				'authId': XAuthId,
				'password' : encryptedPass,
				'grant_type': 'ibs_credential',
				'jailbroken': false,
				'appId': 'ClicksMalaysia',
				'appVersion': '1.00',
				'deviceType': 'Android'
			}
		};
		var hashKey = window.hashKeyValue;
		var hashMac = getHashMAC(JSON.stringify(requestBody), hashKey, timeStamp);

		var requestHeader = {
			Authorization : window.configData.authorizationKey,
			ChannelAuthCode : hashMac
		};

		var invocationData = {
			adapter: 'authAdapter',
			procedure: 'SecureWordLoginStep2',
			parameters : [username, requestHeader, requestBody]
		};

		console.log('Request Header LoginStep2 : ', JSON.stringify(requestHeader));
		console.log('Request Body LoginStep2 : ', JSON.stringify(requestBody));
		AuthRealmChallengeHandler.submitAdapterAuthentication(invocationData, {});
	}


	//TODO OTP Step 1 function ----------------------------------
	function callOtpLoginStep1(username, password) {
		console.log('username OTP: ', username);
		console.log('Password OTP: ', password);
		var encryptedPass = encryptMY(password);

		var requestBody = {
			'requestHeader':{
				'channelAuthCode': 'HMACSTRING',
				'channelTime': '2012-04-23T18:25:43.511Z',
				'pageId': 'PAGEID',
				'requestId': 'REQUESTUUIDSTRING',
				'deviceId': 'DEVICEVENDORID'
			},
			'requestBody':{
				'sessionString': 'SESSIONSTRING',
				'username': username,
				'password': encryptedPass,
				'grant_type': 'ibs_credential'
			}
		};

		var invocationData = {
			adapter: 'authAdapter',
			procedure: 'OTPLoginStep1',
			parameters: [requestBody]
		};
		var options = {
			onSuccess: loginOTPStep1Success,
			onFailure: loginOTPStep1Failure,
			invocationContext: {}
		};

		console.log('Request Body OTPstep1  : ', JSON.stringify(requestBody));
		WL.Client.invokeProcedure(invocationData, options);
	}

	function loginOTPStep1Success(result) {
		console.log ('Success Respond from OTPStep1', result);
		loadingIcon.fadeOut();
		window.location = 'tempPage.html';
	}

	function loginOTPStep1Failure(result) {
		console.log ('Failed Respond from OTPStep1', result);
		loadingIcon.fadeOut();
	}

}());


function passAuthResponse (response) {
	console.log('Raw Authentication Respond ', response);
	if (response.responseJSON.data.statusCode === 200) {
		if (response.responseJSON.data.responseHeaders['x-cs-status']  === 'error') {
			alert(response.responseJSON.data['error_description']);
			window.completeStep2();
		}
		else {
			var authRequired = response.responseJSON.authRequired;

			if (authRequired === true) {
				// Login failed -----------------------------
				console.log ('Respond Body after Auth failed: ', response);

				if (response.responseJSON.errorMessage) {
					console.log(response.responseJSON.errorMessage);
				}

				window.completeStep2();

			} else if (authRequired === false) {
				// Login success -----------------------------
				console.log ('Respond Body after Auth success : ', response);

				//we submit the success as authentication has been done
				AuthRealmChallengeHandler.submitSuccess();

				//Redirect to main app
				window.location = 'dashboard.html';
			}
		}
	}
	else {
		if (response.responseJSON.data['error_description']) {
			alert(response.responseJSON.data['error_description']);
		}
		else {
			alert('Failed to load this page. Please check your connection and try again.');
		}

		window.completeStep2();
	}
}

function initMFPSuccess() {
	logoutUser();
	callInitService();
}

// Get Initilization------------------------
function callInitService() {
	console.log('window.configData.authorizationKey', window.configData.authorizationKey);
	var requestHeader = {
		Authorization : window.configData.authorizationKey
	};
	/*global getHashKey*/
	var currentHashKey = getHashKey();
	console.log('currentHashKey', currentHashKey);

	var requestBody = {
		'requestHeader':{
			'deviceId': uniqueDeviceId
		},
		'requestBody':{
			'hashKey' : currentHashKey
		}
	};
	window.hashKeyValue = currentHashKey;


	var invocationData = {
		adapter: 'authAdapter',
		procedure: 'InitializationService',
		parameters: [requestHeader, requestBody]
	};
	var options = {
		onSuccess: initSuccess,
		onFailure: initFailure,
		invocationContext: {}
	};

	console.log('Request Header inti : ', JSON.stringify(requestHeader));
	console.log('Request Body inti : ', JSON.stringify(requestBody));
	WL.Client.invokeProcedure(invocationData, options);
}
function initSuccess(result) {
	if (result.invocationResult.statusCode === 200) {
		if (result.invocationResult.responseHeaders['x-cs-status']  === 'error') {
			alert(result.invocationResult['error_description']);
		}
		else {
			loginType = result.invocationResult.login_type;
			console.log ('Init Success Result ', result);
			console.log ('LOGIN TYPE', loginType);

			if (loginType === 'otp') {
				$('#user-password-holder-id').attr('class', 'input-field input-field-pass');
				$('#login-btn-secure-id').attr('class', 'btn-primary btn-block btn-next hidden');
				$('#login-btn-otp-id').attr('class', 'btn-primary btn-block');
			}
			else {
				$('#user-password-holder-id').attr('class', 'input-field input-field-pass hidden');
				$('#login-btn-secure-id').attr('class', 'btn-primary btn-block btn-next');
				$('#login-btn-otp-id').attr('class', 'btn-primary btn-block btn-next hidden');
			}
		}

	}
	else {
		if (result.invocationResult['error_description']) {
			alert(result.invocationResult['error_description']);
		}
		else {
			alert('Failed to load this page. Please check your connection and try again.');
		}

	}

	loadingIcon.fadeOut();
}
function initFailure(result) {
	loadingIcon.fadeOut();
	console.log('Failed  Step Init : ', result);
	alert(result.errorMsg);
}

function logoutUser () {
	//WL.Client.logout('AuthRealm', {onSuccess:WL.Client.reloadApp});
	WL.Client.logout('AuthRealm', {onSuccess:
		function() {
			//WL.Client.reloadApp();
			console.log('Logged out the user');
		}
	});
}


//TEMP if u click on OTP btn step 2
$('#otp-btn-id').on('click', function() {
	var userPas = $('#otp-tag-id');
	console.log('im Clicking on OTP Btn 2', userPas.val());
	if (userPas.val()) {
		callOtpLoginStep2('anyPerson', userPas.val());
	}
});


//TODO OTP Login Step 2---------------------------
function callOtpLoginStep2(username, tag) {
	console.log('Tag entered: ', tag);
	console.log('username : ', username);

	var requestBody = {
		'requestHeader':{
			'channelAuthCode': 'HMACSTRING',
			'channelTime': '2012-04-23T18:25:43.511Z',
			'pageId': 'PAGEID',
			'requestId': 'REQUESTUUIDSTRING',
			'deviceId': 'DEVICEVENDORID',
			'authId': 'AUTHIDFROMSERVER'
		},
		'requestBody':{
			'otpType': 'SMS',
			'otp': tag,
			'grant_type': 'ibs_credential'
		}
	};

	var invocationData = {
		adapter: 'authAdapter',
		procedure: 'OTPLoginStep2',
		parameters : [username, requestBody]
	};


	console.log('Request Body OTP step2 : ', JSON.stringify(requestBody));
	AuthRealmChallengeHandler.submitAdapterAuthentication(invocationData, {});
}


// Generate the HashMAC
function getHashMAC (payload, secretKeyEncrypted, time) {
	var shaObj = new jsSHA('SHA-256', 'TEXT');
	shaObj.setHMACKey(secretKeyEncrypted, 'HEX');
	shaObj.update(payload + time);
	var hmac = shaObj.getHMAC('HEX');

	return hmac;
}

//Get Current Time in ISO format
function getCurrentTime () {
	return moment().toISOString();
}

//Get the DeviceID from Cordova
document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
	console.log('Cordova deviceID ', device.uuid);
	uniqueDeviceId = device.uuid;
}
