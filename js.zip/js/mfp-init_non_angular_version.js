/*eslint no-unused-vars:0*/
function wlCommonInit() {
	/*
	 * Use of WL.Client.connect() API before any connectivity to a MobileFirst Server is required.
	 * This API should be called only once, before any other WL.Client methods that communicate with the MobileFirst Server.
	 * Don't forget to specify and implement onSuccess and onFailure callback functions for WL.Client.connect(), e.g:
	 *
	 */

	// Common initialization code goes here
	console.log('wlCommonInit');

	// WL.Client.connect({
	// 	onSuccess: function() {
	// 		console.log('WL.Client.connect SUCCESS');
	// 	},
	// 	onFailure: function() {
	// 		console.log('WL.Client.connect FAILED');
	// 	}
	// });

	/*global initMFPSuccess*/
	getConfigFiles(function() {
		if (typeof initMFPSuccess === 'function') {
			// only call this method if defined (login.js)
			initMFPSuccess();
		}
	});
}



var Messages = {
	// Add here your messages for the default language.
	// Generate a similar file with a language suffix containing the translated messages
	// key1 : message1,
	// key2 : message2

	// Uncomment if you use the Authenticator example.
	// usernameLabel : "Username:",
	// passwordLabel : "Password:",
	// invalidUsernamePassword : 'Invalid username or password.'
};


// Uncomment the initialization options as required. For advanced initialization options please refer to IBM MobileFirst Platform Foundation Knowledge Center

var wlInitOptions = {

	// # To disable automatic hiding of the splash screen uncomment this property and use WL.App.hideSplashScreen() API
	//autoHideSplash: false,

	// # The callback function to invoke in case application fails to connect to MobileFirst Server
	//onConnectionFailure: function (){},

	// # MobileFirst Server connection timeout
	//timeout: 30000,

	// # How often heartbeat request will be sent to MobileFirst Server
	//heartBeatIntervalInSecs: 7 * 60,

	// # Enable FIPS 140-2 for data-in-motion (network) and data-at-rest (JSONStore) on iOS or Android.
	//   Requires the FIPS 140-2 optional feature to be enabled also.
	//enableFIPS : false,

	// # The options of busy indicator used during application start up
	//busyOptions: {text: "Loading..."}
	showIOS7StatusBar: false
};

if (window.addEventListener) {
	window.addEventListener('load', function() { WL.Client.init(wlInitOptions); }, false);
} else if (window.attachEvent) {
	window.attachEvent('onload',  function() { WL.Client.init(wlInitOptions); });
}


/**
 * Manually wrapping webview plugin for cordova
 * TODO: The code is temporary placed here.
 */
/*global cordova*/
var WebView = (function() {
	'use strict';

	var _show = function(url, successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'WebViewPlugin', 'show', [url]);
	};

	var _hide = function(successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'WebViewPlugin', 'hide', []);
	};

	var _subscribeCallback = function(successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'WebViewPlugin', 'subscribeCallback', []);
	};


	return {
		show: _show,
		hide: _hide,
		close: _hide,
		subscribeCallback: _subscribeCallback
	};

})();


// Initilize the authenticator handler
var AuthRealmChallengeHandler = WL.Client.createChallengeHandler('AuthRealm');

//Authenticator custome response
AuthRealmChallengeHandler.isCustomResponse = function(response) {
	if (!response || !response.responseJSON	|| response.responseText === null) {
		return false;
	}
	if (typeof (response.responseJSON.authRequired) !== 'undefined') {
		return true;
	} else {
		return false;
	}
};


// Authentication Handler (we pass data to UI)
AuthRealmChallengeHandler.handleChallenge = function(response) {
	passAuthResponse(response);
};


//Loadout user
function logoutUser () {
	//WL.Client.logout('AuthRealm', {onSuccess:WL.Client.reloadApp});
	WL.Client.logout('AuthRealm', {onSuccess:
		function() {
			//WL.Client.reloadApp();
			console.log('Logged out the user');
		}
	});
}


// Encrypt for MY password
function encryptMY(plainText) {
	//These values are in confing.js / confing.local.js
	// var nvalue = "REPLACE_WITH_RSA_KEY_MODULUS_HEX_VALUE";
	// var evalue = "REPLACE_WITH_EXPONENT_HEX_VALUE";
	var nvalue = window.configData.rsaKeyModulusHex;
	var evalue = window.configData.exponentHex;

	var rsa = new RSAKey();
	rsa.setPublic(nvalue, evalue);
	var res = rsa.encrypt(plainText);
	return res;
}

function getHashKey() {
	var secretKey = uuid();
	var secretKeyEncrypted = encryptMY(secretKey);

	return secretKeyEncrypted;
}

function getConfigFiles(callback) {
	$.ajax({
		url: 'data/config.json',
		type: 'GET',
		contentType: 'application/json;charset=UTF-8',
		dataType: 'json',
		async: true,
		cache: false,
		success: function (res, status, xhr) {
			console.log('Config Data ', res);
			if (typeof res === 'string') {
				res = JSON.parse(res);
			}
			window.configData = res;
			if (callback) {
				callback();
			}
		}
	});
}
