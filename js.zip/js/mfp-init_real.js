/*eslint no-unused-vars:0*/

/**
 * Manually wrapping webview plugin for cordova
 * TODO: The code is temporary placed here.
 */
/*global cordova, uuid, RSAKey, WL, _, jsSHA*/
var WebView = (function () {
	'use strict';

	var _show = function (url, successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'WebViewPlugin', 'show', [url]);
	};

	var _hide = function (successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'WebViewPlugin', 'hide', []);
	};

	var _subscribeCallback = function (successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'WebViewPlugin', 'subscribeCallback', []);
	};

	return {
		show: _show,
		hide: _hide,
		close: _hide,
		subscribeCallback: _subscribeCallback
	};
})();

/**
 * Wrapping Cordova plugin PushNotificationPlugin
 */
var DeviceToken = (function () {
	'use strict';
	var _getDeviceToken = function (successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, "DeviceTokenPlugin", "getDeviceToken", []);
	};

	return {
		getDeviceToken: _getDeviceToken
	}
})();


var Utilities = (function () {
	var getJailbreakResult = function (successCallback, errorCallback) {
		//console.log('successCallback', successCallback);
		//console.log('errorCallback', errorCallback);
		if (window.cordova) {
			window.cordova.exec(successCallback, errorCallback, 'RootDetection', 'isDeviceRooted', []);
		} else {
			setTimeout(function () {
				errorCallback('can not connect plugin');
			}, 1000);
		}

	};

	return {
		isJailbreak: getJailbreakResult
	};
})();


var MFPInit = MFPInit || (function () {
	'use strict';
	// Initilize the authenticator handler
	//var AuthRealmChallengeHandler = WL.Client.createChallengeHandler('AuthRealm');

	var options = {
		passAuthResponse: function () {
			console.log('self.options.passAuthResponse(response);');
		},
		handleChallenge: function () { },
		isCustomResponse: function () { },
		uniqueDeviceId: '',
		initMFPSuccess: function () { }
	};

	function wlCommonInit() {
		/*
		 * Use of WL.Client.connect() API before any connectivity to a MobileFirst Server is required.
		 * This API should be called only once, before any other WL.Client methods that communicate with the MobileFirst Server.
		 * Don't forget to specify and implement onSuccess and onFailure callback functions for WL.Client.connect(), e.g:
		 *
		 */

		// Common initialization code goes here
		console.log('wlCommonInit');

		//Override Direct Update
		var directUpdateCustomListener = {
			onStart: function (totalSize) {
				console.log('progress started');
			},
			onProgress: function (status, totalSize, completedSize) {
				console.log('onProgress: status = ' + status + ' completeSize = ' + completedSize + 'Byte');
				var precentage = Math.round((completedSize * 100) / totalSize);
				$('#sliderBar').css('width', precentage + '%');
				$('#precentage').html(precentage + '%');
			},
			onFinish: function (status) {
				console.log('progress ended', status);
				if (status === 'SUCCESS') {
					//show success message
					WL.Client.reloadApp();
				}
				else {
					//show custom error message
					//submitFailure must be called is case of error
					wl_directUpdateChallengeHandler.submitFailure();
				}
			}
		};


		wl_directUpdateChallengeHandler.handleDirectUpdate = function (directUpdateData, directUpdateContext) {
			console.log('Direct Update Event');
			var octoScreen = $('#octo-screen');
			var octoGrayMobile = $('.octo-gray-mobile');
			var octoGrayWink = $('.octo-gray-wink');
			var octoTitle = $('.octo-title');
			var octoDescription = $('.octo-description');
			var octoButtonText = $('.octo-button-text');
			var progressBar = $('.update-progressbar');
			var updateBtn = $('.octo-update-available .octo-button');
			var octoLinkSkipContainer = $('.octo-link-skip-container');
			var btnClose = octoScreen.find('.btn-close');
			var loader = $('.preloader');
			var minorUpdateText = 'Minor Update Available';
			var clickOnUpdateText = 'Please Click on Update Now to start the process.';

			btnClose.hide();
			progressBar.hide();
			$(octoScreen).show();
			$(octoGrayMobile).show();
			$(octoGrayWink).hide();
			$(octoLinkSkipContainer).hide();
			$(octoTitle).text(minorUpdateText);
			$(octoDescription).text(clickOnUpdateText);
			$(octoButtonText).text('Update Now');
			loader.hide();

			$('.octo-update-available .octo-button').on('click', function () {
				console.log('Direct Update started');
				$(octoTitle).text('Updating');
				$(octoDescription).text('Updating in progress. Please wait.');
				updateBtn.hide();
				progressBar.show();
				directUpdateContext.start(directUpdateCustomListener);
			});

		};

		if (WL.StaticAppProps['ENVIRONMENT'] != 'desktopbrowser') {
			WL.Client.connect({
				onSuccess: function () {
					console.log('WL.Client.connect SUCCESS');
					if (typeof options.initMFPSuccess === 'function') {
						// only call this method if defined (login.js)
						options.initMFPSuccess();
					}
				},
				onFailure: function (error) {
					console.log('WL.Client.connect FAILED');
					options.initFailure();
				}
			});
		} else {
			if (typeof options.initMFPSuccess === 'function') {
				// only call this method if defined (login.js)
				options.initMFPSuccess();
			}
		}
	}



	var Messages = {
		// Add here your messages for the default language.
		// Generate a similar file with a language suffix containing the translated messages
		// key1 : message1,
		// key2 : message2

		// Uncomment if you use the Authenticator example.
		// usernameLabel : "Username:",
		// passwordLabel : "Password:",
		// invalidUsernamePassword : 'Invalid username or password.'
	};


	// Uncomment the initialization options as required. For advanced initialization options please refer to IBM MobileFirst Platform Foundation Knowledge Center


	var wlInitOptions = {

		// # To disable automatic hiding of the splash screen uncomment this property and use WL.App.hideSplashScreen() API
		//autoHideSplash: false,

		// # The callback function to invoke in case application fails to connect to MobileFirst Server
		//onConnectionFailure: function (){},

		// # MobileFirst Server connection timeout
		//timeout: 30000,

		// # How often heartbeat request will be sent to MobileFirst Server
		//heartBeatIntervalInSecs: 7 * 60,

		// # Enable FIPS 140-2 for data-in-motion (network) and data-at-rest (JSONStore) on iOS or Android.
		//   Requires the FIPS 140-2 optional feature to be enabled also.
		//enableFIPS : false,

		// # The options of busy indicator used during application start up
		//busyOptions: {text: "Loading..."}


		showIOS7StatusBar: false,
		onErrorRemoteDisableDenial: function (message, downloadLink) {
			console.log('MFP DOWNLOAD MSG :', message);
			console.log('MFP DOWNLOAD LINK :', downloadLink);

			var octoScreen = $('#octo-screen');
			var octoGrayMobile = $('.octo-gray-mobile');
			var octoGrayWink = $('.octo-gray-wink');
			var octoTitle = $('.octo-title');
			var octoDescription = $('.octo-description');
			var octoButtonText = $('.octo-button-text');
			var progressBar = $('.update-progressbar');
			var octoLinkSkipContainer = $('.octo-link-skip-container');
			var btnClose = octoScreen.find('.btn-close');
			var loader = $('.preloader');

			btnClose.hide();
			$(octoScreen).show();
			$(octoGrayMobile).show();
			$(octoGrayWink).hide();
			$(progressBar).hide();
			$(octoLinkSkipContainer).hide();
			$(octoTitle).text('Update available');
			$(octoDescription).text(message);
			$(octoButtonText).text('Update now');
			loader.hide();

			$('.octo-update-available .octo-button').on('click', function () {
				console.log('im clicing on it update now');
				window.open(downloadLink, '_blank');
			});
		}
	};



	var proto = {};
	proto.options = options;

	var options = proto.options = {
		passAuthResponse: function () { },
		handleChallenge: function () { },
		isCustomResponse: function () { },
		uniqueDeviceId: ''
	};


	// Get Initilization------------------------
	/* @ifdef MFP */
	proto.callInitService = function (_options) {
		var requestHeader = {
			Authorization: options.authorizationKey
		};
		var currentHashKey = this.getHashKey();
		var encryptedHashKey = this.encryptMY(currentHashKey);
		window.hashKeyValue = currentHashKey;

		var requestBody = {
			'requestHeader': {
				'channelTime': options.timeStamp,
				'deviceId': options.uniqueDeviceId
			},
			'requestBody': {
				'hashKey': encryptedHashKey,
				'version': {
					'locatorSetting': options.configVers.locator,
					'trxSetting': options.configVers.transaction,
					'localBankSetting': options.configVers.localBank
				}
			}
		};
		var requestBodyString = JSON.stringify(requestBody);
		console.log('Init Body Reuqest ', requestBodyString);
		//localStorage.setItem('hashKey', currentHashKey);

		var invocationData = {
			adapter: 'authAdapter',
			procedure: 'InitializationService',
			parameters: [requestHeader, requestBodyString]
		};
		delete options.authorizationKey;
		var invokeProcedureOption = {
			onSuccess: _options.onSuccess || function () { },
			onFailure: _options.onFailure || function () { },
			invocationContext: {}
		};

		console.log('Init Request TimeStamp', options.timeStamp);
		console.log('Request Header inti : ', JSON.stringify(requestHeader));
		console.log('Request Body inti : ', requestBodyString);
		WL.Client.invokeProcedure(invocationData, invokeProcedureOption);

		/********* Messenger/CMServer stuff goes here *********/
		if (cmIdPassCheck()) {
			onMessengerNewMessage();
		}

		/********** End Messenger Stuff **********/
	};
	/* @endif */

	// Generate the HashMAC
	proto.getHashMAC = function (payload, secretKey, time) {
		//var sortedPayload = JSON.stringify(proto.sortObjs(payload));
		console.log('prelogin secretKey ', secretKey)
		console.log('prelogin time ', time)
		console.log('prelogin string PAYLOADDDD ', payload)

		var shaObj = new jsSHA('SHA-256', 'TEXT');
		shaObj.setHMACKey(secretKey, 'TEXT');
		shaObj.update(payload + time);
		var hmac = shaObj.getHMAC('B64');

		return hmac;
	};

	//Sort the payload
	proto.sortObjs = function (obj) {
		var ordered = {};
		Object.keys(obj).sort().forEach(function (key) {
			var sortedObj = obj[key];

			if (obj[key] instanceof Array) {
				var arrObj = obj[key];
				var newObj = [];
				Object.keys(arrObj).forEach(function (index) {
					newObj[index] = sortObject(arrObj[index]);
				});
				sortedObj = newObj;
			}
			else if (obj[key] != null && typeof obj[key] == "object") {
				sortedObj = proto.sortObjs(obj[key]);
			}
			ordered[key] = sortedObj;
		});
		return ordered;
	};


	// Encrypt for MY password
	proto.encryptMY = function encryptMY(plainText) {
		//These values are in confing.js / confing.local.js
		// var nvalue = "REPLACE_WITH_RSA_KEY_MODULUS_HEX_VALUE";
		// var evalue = "REPLACE_WITH_EXPONENT_HEX_VALUE";
		var configData = this.options.config;

		var nvalue = this.options.rsaKeyModulusHex;
		var evalue = this.options.exponentHex;

		localStorage.setItem('configData', JSON.stringify(configData));

		var rsa = new RSAKey();
		rsa.setPublic(nvalue, evalue);
		var res = rsa.encrypt(plainText);
		return res;
	};


	proto.aesEncyption = function aesEncyption(deviceId, timeStamp, secretKey) {
		console.log('AES deviceId', deviceId);
		console.log('AES timeStamp', timeStamp);
		console.log('AES secretKey', secretKey);
		var content = deviceId + "||" + timeStamp;

		var encryptedContent = CryptoJS.AES.encrypt(content, secretKey).toString();
		// var decryptedContent = CryptoJS.AES.decrypt(encryptedContent, passphrase).toString(CryptoJS.enc.Utf8);

		return encryptedContent;
	}

	proto.getHashKey = function getHashKey() {
		var secretKey = uuid();
		//var secretKeyEncrypted = this.encryptMY(secretKey);

		return secretKey;
	};

	proto._hookMFPNative = function () {
		var self = this;
		//Authentication Handler (we pass data to UI)
		AuthRealmChallengeHandler.handleChallenge = function (response) {
			self.options.passAuthResponse(response);
		};

		//Authenticator custome response
		AuthRealmChallengeHandler.isCustomResponse = function (response) {
			console.log('AuthRealmChallengeHandler response', response)
			// if (!response || !response.responseJSON	|| response.responseText === null) {
			// 	return false;
			// }
			if (response && response.responseJSON && typeof (response.responseJSON.authRequired) !== 'undefined') {
				console.log('challenge return true')
				return true;
			} else {
				console.log('challenge return false')
				return false;
			}
		};
	};

	proto._initWLClient = function () {
		WL.Client.init(wlInitOptions);
		/*if (window.addEventListener) {
			window.addEventListener('load', function() { WL.Client.init(wlInitOptions); }, false);
		} else if (window.attachEvent) {
			window.attachEvent('onload',  function() { WL.Client.init(wlInitOptions); });
		}*/
	};

	/* @ifdef MFP **/
	proto.init = function (_options) {

		this.options = _.merge(this.options, _options);

		this._initWLClient();
		this._hookMFPNative();
	};


	//Loadout user
	proto.logoutUser = function (_options) {
		_options = _.extend({
			onSuccess:
			function () {
				//WL.Client.reloadApp();
				console.log('Logged out the user');
			},
			onFailure: function () {
				console.log('Logged out fail');
			}
		}, _options);
		//WL.Client.logout('AuthRealm', {onSuccess:WL.Client.reloadApp});
		WL.Client.logout('AuthRealm', _options);
	};

	proto.submitSuccess = function () {
		AuthRealmChallengeHandler.submitSuccess();
	};

	proto.submitAdapterAuthentication = function (handleCallback, invocationData) {
		//provide callback for submitAdapterAuthentication
		var previousHandleChallenge = AuthRealmChallengeHandler.handleChallenge;
		AuthRealmChallengeHandler.handleChallenge = function (response) {
			console.log('handleChallenge ', response);
			if (handleCallback) {
				handleCallback(response);
			}

			//reset the response handler
			AuthRealmChallengeHandler.handleChallenge = previousHandleChallenge;
		};
		console.log('invocationData', invocationData);
		//AuthRealmChallengeHandler.submitAdapterAuthentication.apply(this, arguments);
		AuthRealmChallengeHandler.submitAdapterAuthentication.apply(this, [invocationData, {}]);
	};
	/* @endif */

	/* @ifdef AJAX */
	// simulated MFP init function for HTML demo
	proto.init = function (_options) {
		console.log("AJAX init")
		this.options = _.merge(this.options, _options);
		//this.options.initMFPSuccess();
		// this._initWLClient();

		if (typeof this.options.initMFPSuccess === 'function') {
			// simulate mfp init success
			var initMFPSuccess = this.options.initMFPSuccess;
			setTimeout(initMFPSuccess, 10);
		}
	};

	proto.callInitService = function (_options) {
		var temporaryFail = function (result) {
			if (failCallback) {
				failCallback('Sorry, we can not connect to server right now. Please check your connection.');
			}
		};

		var temporarySuccess = function (result) {
			console.log('RESULT >>>', result);
			var errorMessage = '';
			//handle the error exception here
			//var result = result.invocationResult;
			_options.onSuccess({
				invocationResult: {
					array: result.invocationResult.array,
					responseHeaders: {},
					statusCode: result.invocationResult.statusCode
				}
			});
		}

		this.getDataByService(temporarySuccess, temporaryFail);
	};

	proto.getDataByService = function (successCallback, failCallback) {
		var currentHashKey = this.getHashKey();
		var encryptedHashKey = this.encryptMY(currentHashKey);
		window.hashKeyValue = currentHashKey;

		var requestBody = {
			'requestHeader': {
				'channelTime': options.timeStamp,
				'deviceId': options.uniqueDeviceId
			},
			'requestBody': {
				'hashKey': encryptedHashKey,
				'version': {
					'locatorSetting': options.configVers.locator,
					'trxSetting': options.configVers.transaction,
					'localBankSetting': options.configVers.localBank
				}
			}
		};
		console.log('Request Body init : ', JSON.stringify(requestBody));
		//localStorage.setItem('hashKey', currentHashKey);

		// var serviceUrl = "https://sit.cimbclicks.com.my/api/v1/public/init";
		// var serviceUrl = "https://sit2.cimbclicks.com.my/api/v1/public/init";

		//UAT
		// var serviceUrl = "https://uat3.cimbclicks.com.my/api/v1/public/init";

		//DR
		// var serviceUrl = "https://apps.cimbclicks.com.my/api/v1/public/init";

		var serviceUrl = window.location.protocol + "//" + window.location.hostname + "/api/v1/public/init";

		return $.ajax({
			method: "post",
			dataType: "json",
			url: serviceUrl,
			contentType: "application/json",
			data: JSON.stringify(requestBody),
			beforeSend: function (xhr) {
				xhr.setRequestHeader("Authorization", options.authorizationKey);
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
				xhr.setRequestHeader("Accept-Language", "en");
				xhr.setRequestHeader("PageId", "LOGIN");
				return xhr;
			}
		}).done(function (respJson, status, header) {
			var resultData;
			//_this.authId = respJson.authId;
			console.log("SUCCESS", respJson);
			console.log("SUCCESS", status);
			console.log("SUCCESS", header);

			resultData = {
				invocationResult: {
					responseHeaders: {},
					statusCode: 200,
					array: respJson
				}
			};
			delete options.authorizationKey;
			successCallback(resultData);

		}).fail(function (jqXhr) {
			var resultData;
			var responseText;

			if(jqXhr.status !== 500) {
				responseText = jQuery.parseJSON(jqXhr.responseText);
			}
			console.log('jqXhr.responseText json', responseText);

			resultData = {
				invocationResult: {
					responseHeaders: {},
					statusCode: jqXhr.status,
					array: responseText
				}
			};
			successCallback(resultData);

			// alert("Internal HTTP Error " + jqXhr.status);
		});
	};

	proto.logoutUser = function (_options) {
		if (typeof _options.onSuccess === 'function') {
			setTimeout(function () {
				// simulate MFP invokation result
				_options.onSuccess();
			}, 10);
		}
	};

	proto.submitSuccess = function () {
		//empty
	};
	proto.submitAdapterAuthentication = function (handleCallback, invocationData) {
		//empty
	};
	/* @endif */



	// export
	window.wlCommonInit = wlCommonInit;
	// window.getHashKey = proto.getHashKey;
	// window.encryptMY = proto.encryptMY;
	// window.getHashMAC = getHashMAC;

	return proto;
})();

// MFPInit.init(options);
