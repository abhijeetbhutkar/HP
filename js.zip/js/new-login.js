/*global encryptMY, device, MFPInit*/
// var AuthRealmChallengeHandler = WL.Client.createChallengeHandler('AuthRealm');
var loadingIcon = $('#preload');
var loginType = null;
var XAuthId = null;
var uniqueDeviceId = '';

// loadingIcon.fadeIn();
(function() {
	'use strict';
	// This logic has been moved to LoginPage.ts
	return;


	// status data
	// 1 is open
	// 0 is suppended
	// //////
	// lastLogin data
	// null is first time login to app users
	// has data is existing users
	/*eslint no-unused-vars: 0*/



	// serviceActivation.find('.confirm-quick-balance').on('click', function() {
	// 	userProfile.forEach(function(item) {
	// 		if (item.userName.toLowerCase() === usn.val().toLowerCase()) {
	// 			delete item.password;
	// 			item.quickbalance = true;
	// 			localStorage.setItem('userSession', JSON.stringify(item));
	// 		}
	// 	});
	// 	window.location.href = 'dashboard.html#/dashboard/home';
	// 	// serviceActivation.fadeOut(function() {
	// 	// 	this.find('.activate').hide();
	// 	// });
	// });

	//Event handler Keypress Enter
	// $('#user-id').keypress(function(event) {

	// 	if (event.which === 13) {
	// 		event.preventDefault();
	// 		// $('select').select2('open');
	// 		// console.log('Enter');
	// 		// return false;
	// 	}
	// });


	// $(document).keypress(function(event) {
	// 	if (event.which === 13) {
	// 		event.preventDefault();
	// 		if (formStep1.css('display') === 'block') {
	// 			alert('Please click \'Next\' to proceed.');
	// 		} else {
	// 			alert('Please click \'Login\' to proceed.');
	// 		}
	// 	}
	// });

}());

/**
 * This function will be override by a method inside LoginPage.ts
 */
function passAuthResponse (response) {
	console.log('Raw Authentication Respond ', response);
	if (response.responseJSON.data.statusCode === 200) {
		if (response.responseJSON.data.responseHeaders['x-cs-status']  === 'error') {
			alert(response.responseJSON.data['error_description']);
			window.completeStep2();
		}
		else {
			var authRequired = response.responseJSON.authRequired;

			if (authRequired === true) {
				// Login failed -----------------------------
				console.log ('Respond Body after Auth failed: ', response);

				if (response.responseJSON.errorMessage) {
					console.log(response.responseJSON.errorMessage);
				}

				window.completeStep2();

			} else if (authRequired === false) {
				// Login success -----------------------------
				console.log ('Respond Body after Auth success : ', response);

				//we submit the success as authentication has been done
				MFPInit.submitSuccess();

				//Redirect to main app
				window.location = 'dashboard.html';
			}
		}
	}
	else {
		if (response.responseJSON.data['error_description']) {
			alert(response.responseJSON.data['error_description']);
		}
		else {
			alert('Failed to load this page. Please check your connection and try again.');
		}

		window.completeStep2();
	}
}

function initMFPSuccess() {
	MFPInit.logoutUser();
	// callInitService();
	MFPInit.callInitService({
		authorizationKey: window.configData.authorizationKey,
		onSuccess: initSuccess,
		onFailure: initFailure
	});
}

function initSuccess(result) {
	if (result.invocationResult.statusCode === 200) {
		if (result.invocationResult.responseHeaders['x-cs-status']  === 'error') {
			alert(result.invocationResult['error_description']);
		}
		else {
			loginType = result.invocationResult.login_type;
			console.log ('Init Success Result ', result);
			console.log ('LOGIN TYPE', loginType);

			if (loginType === 'otp') {
				$('#user-password-holder-id').attr('class', 'input-field input-field-pass');
				$('#login-btn-secure-id').attr('class', 'btn-primary btn-block btn-next hidden');
				$('#login-btn-otp-id').attr('class', 'btn-primary btn-block');
			}
			else {
				$('#user-password-holder-id').attr('class', 'input-field input-field-pass hidden');
				$('#login-btn-secure-id').attr('class', 'btn-primary btn-block btn-next');
				$('#login-btn-otp-id').attr('class', 'btn-primary btn-block btn-next hidden');
			}
		}

	}
	else {
		if (result.invocationResult['error_description']) {
			alert(result.invocationResult['error_description']);
		}
		else {
			alert('Failed to load this page. Please check your connection and try again.');
		}

	}

	loadingIcon.fadeOut();
}

function initFailure(result) {
	loadingIcon.fadeOut();
	console.log('Failed  Step Init : ', result);
	alert(result.errorMsg);
}

function getConfigFiles(callback) {
	$.ajax({
		url: 'data/config.json',
		type: 'GET',
		contentType: 'application/json;charset=UTF-8',
		dataType: 'json',
		async: true,
		cache: false,
		success: function (res, status, xhr) {
			console.log('Config Data ', res);
			if (typeof res === 'string') {
				res = JSON.parse(res);
			}
			window.configData = res;
			if (callback) {
				callback(res);
			}
		}
	});
}

//Get Current Time in ISO format
function getCurrentTime () {
	return moment().toISOString();
}

function initMFP() {
	var uuid = (window.device && window.device.uuid) || '12313124234';
	console.log('Cordova deviceID ', uuid);
	uniqueDeviceId = uuid;
	var loadConfigComplete = function (data) {
		MFPInit.init({
			uniqueDeviceId: uniqueDeviceId,
			initMFPSuccess: initMFPSuccess,
			passAuthResponse: passAuthResponse,
			authorizationKey: data.authorizationKey,
			config: data
		});
	};
	getConfigFiles(loadConfigComplete);
}
//Get the DeviceID from Cordova
document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
	initMFP();
}
// localStorage.clear();
//on desktop
// onDeviceReady();
