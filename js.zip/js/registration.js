// registration
(function() {
	'use strict';

	// Step 2
	$('.regist-tac-list a').on('click', function() {
		$(this).closest('li').toggleClass('active');
		$(this).closest('li').siblings('li').toggleClass('hidden');
		$('.tacnumber-container, .regist-footer .btn-next').toggleClass('hidden');
	});

	// $(function() {
	// 	$('[data-toggle="popover"]').popover();
	// 	$('[data-toggle="tooltip"]').tooltip();

	// 	var $select = $('select');
	// 	// var $placeholder = $('select + .placeholder').text();

	// 	$select.select2({
	// 		minimumResultsForSearch: Infinity
	// 	});

	// 	$('#investment-type').select2({
	// 		placeholder: 'Select Investment Type',
	// 		allowClear: true
	// 	});

	// 	$('#country').select2({
	// 		placeholder: 'Country of Issuance',
	// 		allowClear: true
	// 	});
	// });

	// validateForme = function(formObj1, formObj2) {
	// 	var validate = false;
	// 	return validate;
	// };

	// var nextForm = function($FormObj) {
	// 	$FormObj.fadeIn();
	// };

}());
