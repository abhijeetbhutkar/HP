/*global MFPInit*/
/**
 * Service for Login
 * @return {Object}   Provider
 */

window.ServiceProvider = (function() {
	var ServiceType = {
		SERVICE_LOGIN_STEP1: 'SERVICE_LOGIN_STEP1',
		SERVICE_LOGIN_STEP2: 'SERVICE_LOGIN_STEP2',
		SERVICE_USER_INFO : 'SERVICE_USER_INFO',
		SERVICE_INCREMENTAL_AUTH : 'SERVICE_INCREMENTAL_AUTH',

		SERVICE_FPX_CANCEL_PRE_LOGIN: 'SERVICE_FPX_CANCEL_PRE_LOGIN',

		SERVICE_OTP_STEP1: 'SERVICE_OTP_STEP1',
		SERVICE_OTP_STEP2: 'SERVICE_OTP_STEP1'
	};

	var SecureServiceType = {
		SERVICE_SECURE_LOGIN_STEP2: 'SERVICE_SECURE_LOGIN_STEP2',
		SERVICE_SECURE_OTP_STEP2: 'SERVICE_SECURE_OTP_STEP2',
		SERVICE_TOUCH_ID_AUTH: 'SERVICE_TOUCH_ID_AUTH'
	};

	var ServiceHubType = {
		MFP_SERVICE : 'MFP_SERVICE',
		AJAX_SERVICE: 'AJAX_SERVICE'
	};

	var WFPService = function() {

	};

	WFPService.prototype = {
		constructor: WFPService,
		getDataByService: function(serviceType, parameters, invocationContext, successCallback, failCallback) {
		},
		submitSuccess: function() {
		}
	};

	/**
	 * Service using AJAX
	 * @return {undefined} return nothing
	 */
	var AJAXService = function() {

	};

	AJAXService.prototype = {
		constructor: AJAXService,
		getDataByService: function(serviceType, parameters, invocationContext, successCallback, failCallback) {
			var serviceUrl = '';
			var isSecure = false;

			switch (serviceType) {
				case ServiceType.SERVICE_LOGIN_STEP1:
					serviceUrl = 'mock/login/login-step-1.json';
					break;
				case ServiceType.SERVICE_OTP_STEP1:
					serviceUrl = 'mock/login/login-step-2.json';
					break;
				case ServiceType.SERVICE_USER_INFO:
					serviceUrl = 'mock/mock-user-info.json';
					break;
				case SecureServiceType.SERVICE_SECURE_LOGIN_STEP2:
					var pass = parameters[3];
					console.log('pass ', pass);
					isSecure = true;

					if (pass === '12345678') {
						serviceUrl = 'mock/login/login-step-2-error.json';
					} else {
						serviceUrl = 'mock/login/login-step-2-secure.json';
					}
					//uncomment to local test whether user is selected pilot user
					// serviceUrl = 'mock/login/login-step-2-error.json';
					break;
				case SecureServiceType.SERVICE_SECURE_OTP_STEP2:
					isSecure = true;
					serviceUrl = 'mock/login/login-step-2-secure.json';
					break;
				case ServiceType.SERVICE_TOUCH_ID_AUTH:
					isSecure = true;
					serviceUrl = 'mock/login/touch-id-auth.json';
					break;
				case ServiceType.SERVICE_INCREMENTAL_AUTH:
					serviceUrl = 'mock/login/auth-incremental.json';
					break;
				case ServiceType.SERVICE_FPX_CANCEL_PRE_LOGIN:
					serviceUrl = 'mock/fpx/mock-rpp-payment-cancel.json';
					break;
			}

			// Use AJAX of jQuery to
			$.get(serviceUrl)
			.done(function(data) {
				var resultData;

				if (typeof data !== 'object') {
					data = JSON.parse(data);
				}

				if (isSecure) {
					// response for secure service call
					resultData = {
						responseJSON: data
					};
				} else {
					resultData = {
						invocationResult: {
							responseHeaders: {},
							statusCode: 200,
							array: data
						}
					};
				}

				successCallback(resultData);
			})
			.fail(function(error) {
				failCallback(error);
			});
		},
		submitSuccess: function() {

		}
	};


	//service Hub
	var ServiceHub = {
		//hubType: ServiceHubType.MFP_SERVICE,
		hubType: ServiceHubType.AJAX_SERVICE,

		handleException: function(result, successCallback, failCallback) {
			console.log('RESULT >>> ', result);
			var errorMessage = '';
			//handle the error exception here

			if (result.invocationResult.statusCode === 200) {
				if (result.invocationResult.responseHeaders['x-cs-status'] === 'error') {
					errorMessage =  result.invocationResult['error_description'] + ' [' + result.invocationResult['error'] + ']';
					failCallback(errorMessage);
				} else {
					var resultContent = result.invocationResult['array'];
					if (!resultContent) {
						resultContent = result.invocationResult;
					}
					successCallback(resultContent);
				}
			}
			else if(result.invocationResult.statusCode === 503){
				console.log('Pre Login DOWNTIME thrown 1');
				successCallback(result.invocationResult, 'DOWNTIME');
			}
			 else {
				if (result.invocationResult['error_description']) {
					errorMessage =  result.invocationResult['error_description'] + ' [' + result.invocationResult['error'] + ']';
					failCallback(errorMessage);
				} else {
					//alert('Failed to load this page. Please check your connection and try again.');
					failCallback('Failed to load this page. Please check your connection and try again.');
				}
			}
		},

		handleExceptionForSecure: function(result, successCallback, failCallback) {
			console.log('handleExceptionForSecure', result);
			var errorMessage = '';
			//handle the error exception here

			if(result.responseJSON.faContext){

				console.log('FA handleExceptionForSecure');
				failCallback(result.responseJSON.faContext);

			}
			else if (result.responseJSON.data.statusCode === 200) {
				if (result.responseJSON.data.responseHeaders['x-cs-status'] === 'error' || result.responseJSON.data.responseHeaders['X-CS-Status'] === 'error') {
					errorMessage =  result.responseJSON.data['error_description'] + ' [' + result.responseJSON.data['error'] + ']';
					/// uncomment to local test whether user is selected PILOT user.///
					// errorMessage={
					// 	"error":"error code la",
					// 	"error_description":"error desc la",
					// 	"data":{
					// 		"location":"LINK_TO_BAU"
					// 	}
					// }
					failCallback(errorMessage);
				} else {
					var authRequired = result.responseJSON.authRequired;

					if (authRequired === true) {
						failCallback('Authenticate fail');
					} else if (authRequired === false) {
						successCallback(result.responseJSON.data);
					}
				}
			}
			else if (result.responseJSON.data.statusCode === 503){
				console.log('Pre Login DOWNTIME thrown 2');
				successCallback(result.responseJSON.data, 'DOWNTIME');
			}
			else if (result.responseJSON.data.statusCode === 500){
				if (result.responseJSON.data['error_description']) {
					errorMessage =  result.responseJSON.data['error_description'] + ' [' + result.responseJSON.data['error'] + ']';
					failCallback(errorMessage, result);
				} else {
					failCallback('Failed to load this page. Please check your connection and try again.');
				}
			}
			 else {
				if (result.responseJSON.data['error_description']) {
					errorMessage =  result.responseJSON.data['error_description'] + ' [' + result.responseJSON.data['error'] + ']';
					failCallback(errorMessage);
				} else {
					failCallback('Failed to load this page. Please check your connection and try again.');
				}
			}
		},

		getDataByService: function(serviceType, parameters, invocationContext, successCallback, failCallback) {
			var self = this;
			var temporarySuccess;

			switch (serviceType) {
				case ServiceType.SERVICE_LOGIN_STEP1:
				case ServiceType.SERVICE_USER_INFO:
				case ServiceType.SERVICE_OTP_STEP1:
				case ServiceType.SERVICE_FPX_CANCEL_PRE_LOGIN:
					temporarySuccess = function(result) {
						console.log('login first step logged in success', result);
						self.handleException(result, successCallback, failCallback);
					};
					break;
				case SecureServiceType.SERVICE_SECURE_LOGIN_STEP2:
				case SecureServiceType.SERVICE_TOUCH_ID_AUTH:
				case SecureServiceType.SERVICE_SECURE_OTP_STEP2:
					temporarySuccess = function(result) {
						console.log('login second step logged in success', result);

						self.handleExceptionForSecure(result, successCallback, failCallback);

						/*if (serviceType === SecureServiceType.SERVICE_SECURE_LOGIN_STEP2) {
							// FIXME
							// For testing only (make login flow work on desktop)
							// console.log('parameters', parameters);
							failCallback({
								errorMsg: 'Invalid User ID or Password'
							});
						} else {
							self.handleExceptionForSecure(result, successCallback, failCallback);
						}*/
					};
					break;
			}

			var temporaryFail = function(result) {
				if (failCallback) {
					failCallback('We are unable to connect to the server now. Please try again later');
					// failCallback("Sorry. You are not selected pilot",true);
				}
			};

			var servicePoint = null;
			switch (ServiceHub.hubType) {
				case ServiceHubType.MFP_SERVICE:
					servicePoint = new WFPService();
					break;
				case ServiceHubType.AJAX_SERVICE:
					servicePoint = new AJAXService();
					break;
			}

			console.log('servicePoint >>> ', servicePoint);

			if (servicePoint) {
				servicePoint.getDataByService(serviceType, parameters, invocationContext, temporarySuccess, temporaryFail);
			}
		},

		submitSuccess: function() {
			if (ServiceHub.hubType === ServiceHubType.MFP_SERVICE) {
				MFPInit.submitSuccess();
			}
		}

		// getDataBySecureService: function(serviceType, parameters, successCallback, failCallback) {
		// 	var self = this;
		// 	console.log('parameters ', parameters);

		// 	var responseCallbackHandler = function(result) {
		// 		self.handleExceptionForSecure(result, successCallback, failCallback);

		// 		if (serviceType === SecureServiceType.SERVICE_SECURE_LOGIN_STEP2) {
		// 			// FIXME
		// 			// For testing only (make login flow work on desktop)
		// 			// console.log('parameters', parameters);
		// 			failCallback({
		// 				errorMsg: 'Invalid User ID or Password'
		// 			});
		// 		} else {
		// 			self.handleExceptionForSecure(result, successCallback, failCallback);
		// 		}
		// 	};

		// 	var servicePoint = null;
		// 	switch (ServiceHub.hubType) {
		// 		case ServiceHubType.MFP_SERVICE:
		// 			servicePoint = new WFPService();
		// 			break;
		// 		case ServiceHubType.AJAX_SERVICE:
		// 			servicePoint = new AJAXService();
		// 			break;
		// 	}

		// 	if(servicePoint) {
		// 		servicePoint.getDataBySecureService(serviceType, parameters, responseCallbackHandler);
		// 	}
		// },


	};

	return {
		ServiceType: ServiceType,
		ServiceHubType: ServiceHubType,
		ServiceHub: ServiceHub,
		SecureServiceType: SecureServiceType
	};
}());
