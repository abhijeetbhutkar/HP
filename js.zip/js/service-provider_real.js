/*global MFPInit*/
/**
 * Service for Login
 * @return {Object}   Provider
 */

var token_type;
var access_token;

window.ServiceProvider = (function () {
	var ServiceType = {
		SERVICE_LOGIN_STEP1: 'SERVICE_LOGIN_STEP1',
		SERVICE_LOGIN_STEP2: 'SERVICE_LOGIN_STEP2',
		SERVICE_USER_INFO: 'SERVICE_USER_INFO',
		SERVICE_INCREMENTAL_AUTH: 'SERVICE_INCREMENTAL_AUTH',

		SERVICE_FPX_CANCEL_PRE_LOGIN: 'SERVICE_FPX_CANCEL_PRE_LOGIN',

		SERVICE_OTP_STEP1: 'SERVICE_OTP_STEP1',
		SERVICE_OTP_STEP2: 'SERVICE_OTP_STEP1',
		SERVICE_LOGOUT: 'SERVICE_LOGOUT'
	};

	var SecureServiceType = {
		SERVICE_SECURE_LOGIN_STEP2: 'SERVICE_SECURE_LOGIN_STEP2',
		SERVICE_SECURE_OTP_STEP2: 'SERVICE_SECURE_OTP_STEP2',
		SERVICE_TOUCH_ID_AUTH: 'SERVICE_TOUCH_ID_AUTH'
	};

	var ServiceHubType = {
		MFP_SERVICE: 'MFP_SERVICE',
		AJAX_SERVICE: 'AJAX_SERVICE'
	};

	var WFPService = function () {

	};

	WFPService.prototype = {
		constructor: WFPService,
		getDataByService: function (serviceType, parameters, invocationContext, successCallback, failCallback) {
		},
		submitSuccess: function () {
		}
	};

	/**
	 * Service using AJAX
	 * @return {undefined} return nothing
	 */
	var AJAXService = function () {

	};

	AJAXService.prototype = {
		constructor: AJAXService,
		serviceReponseCall: function (isSecure, respJson, header) {
			var resultData;
			if (isSecure) {
				// response for secure service call
				resultData = {
					responseJSON: {
						authRequired: false,
						data: {
							array: respJson,
							statusCode: header.status,
							responseHeaders: {}
						}
					}
				}
			} else {
				resultData = {
					invocationResult: {
						responseHeaders: {},
						statusCode: 200,
						array: respJson
					}
				};
			}
			return resultData;
		},
		getDataByService: function (serviceType, parameters, invocationContext, successCallback, failCallback) {
			var serviceUrl = '';
			var isSecure = false;
		
			// var baseurl = "https://sit.cimbclicks.com.my/api/v1";
			// var baseurl = "https://sit2.cimbclicks.com.my/api/v1";

			//UAT
			// var baseurl = "https://uat3.cimbclicks.com.my/api/v1";

			//DR
			// var baseurl = "https://apps.cimbclicks.com.my/api/v1";

			var baseurl = window.location.protocol+"//"+window.location.hostname+"/api/v1";

			var _this = this;
			var resultData;
			if (localStorage.getItem("account")) {
				try {
					this.account = JSON.parse(localStorage.getItem("account"));
					token_type = this.account.token_type;
					access_token = this.account.access_token;

				} catch (_error) {
					e = _error;
					return console.warn(e);
				}
			}
			console.log("serviceType = " + serviceType);
			console.log("parameters", parameters);

			switch (serviceType) {
				case ServiceType.SERVICE_LOGIN_STEP1:
					serviceUrl = baseurl + "/public/secure";
					break;
				case ServiceType.SERVICE_OTP_STEP1:
					serviceUrl = 'mock/login/login-step-2.json';
					break;
				case ServiceType.SERVICE_USER_INFO:
					serviceUrl = baseurl + "/common/user/inquiry?device-id=" + parameters[0] + "&fresh-install=true";
					break;
				case ServiceType.SERVICE_LOGOUT:
					serviceUrl = baseurl + "/common/logout-summary";
					break;
				case SecureServiceType.SERVICE_SECURE_LOGIN_STEP2:
					isSecure = true;
					serviceUrl = baseurl + '/oauth/token';
					break;
				case SecureServiceType.SERVICE_SECURE_OTP_STEP2:
					isSecure = true;
					serviceUrl = 'mock/login/login-step-2-secure.json';
					break;
				case ServiceType.SERVICE_TOUCH_ID_AUTH:
					isSecure = true;
					serviceUrl = baseurl + '/oauth/token';
					break;
				case ServiceType.SERVICE_INCREMENTAL_AUTH:
					serviceUrl = baseurl + '/transaction/increment/auth';
					break;
				case ServiceType.SERVICE_FPX_CANCEL_PRE_LOGIN:
					// serviceUrl = baseurl + '/transaction/increment/auth';
					serviceUrl = baseurl + '/public/rpp-payment/cancel?timeout=' + false;
					break;
			}

			if (serviceType == ServiceType.SERVICE_LOGIN_STEP1) {

				var isFromFpx = false;
				if (parameters[0].FpxRefId) {
					var isFromFpx = true;
				}

				return $.ajax({
					method: "post",
					dataType: "json",
					url: serviceUrl,
					timeout:70000,
					data: parameters[1],
					contentType: "application/json",
					beforeSend: function (xhr) {
						xhr.setRequestHeader("Authorization", parameters[0].Authorization);
						xhr.setRequestHeader("Accept", "application/json");
						xhr.setRequestHeader("Channel-Auth-Code", parameters[0].ChannelAuthCode);
						xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
						xhr.setRequestHeader("Accept-Language", "en");
						xhr.setRequestHeader("PageId", "LOGIN");

						if (isFromFpx) {
							xhr.setRequestHeader('RPP_REF_TOKEN', parameters[0].FpxRefId);
						}
						return xhr;
					}
				}).done(function (respJson, status, header) {
					var resultData;
					_this.authId = respJson.authId;
					$("#secure-img").attr("src", "data:image/png;base64," + respJson.secureWord);

					resultData = _this.serviceReponseCall(isSecure, respJson, header);
					successCallback(resultData);

				}).fail(function (jqXhr) {

					console.log('HTTP header status', jqXhr.status);
					
					if (jqXhr.status === 0) {
						failCallback('Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.');
					
					} else if (jqXhr.status == 404) {
						// failCallback('Requested page not found. [404]');
						console.log("In 404");
						setTimeout(function () {
							$('.preloader').fadeOut();
						}, 500);

						$('.not-found-wrapper').css('display', 'block');
						$('.page-level1-container').css('display', 'none');
					
					} else if (jqXhr.status == 500) {
						failCallback("Sorry. We've encountered connection error. Please try again.");
					
					}
					else {
						/*302,401*/
						if(jqXhr.responseText){

							var resultData;
							var responseText = jQuery.parseJSON(jqXhr.responseText);
							console.log('jqXhr.responseText json', responseText);

							resultData = {
								invocationResult: {
									responseHeaders: {},
									statusCode: jqXhr.status,
									array: responseText
								}
							};
							successCallback(resultData);
						}
						else {
							failCallback('Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.');
						}
					}

					$('.preloader').fadeOut();
				});
			} else if (serviceType == ServiceType.SERVICE_LOGOUT) {
				console.log("SERVICE_LOGOUT start");

				try {
					return $.ajax({
					dataType: "json",
					method:"delete",
					url: serviceUrl,
					timeout:70000,
					contentType: "application/json",
					beforeSend: function (xhr) {
						xhr.setRequestHeader("Authorization", token_type + " " + access_token);
						return xhr;
					}
					}).done(function (respJson, status, header) {
						successCallback(respJson);
					}).fail(function (jqXhr) {

						failCallback(jqXhr.responseText);
						$('.preloader').fadeOut();
					});
				} catch (_error){
					console.log('Calling logout >>>', _error);
				}
				
			} else if (serviceType == ServiceType.SERVICE_USER_INFO) {
				console.log("SERVICE_USER_INFO start");
				return $.ajax({
					dataType: "json",
					url: serviceUrl,
					timeout:70000,
					contentType: "application/json",
					beforeSend: function (xhr) {
						xhr.setRequestHeader("Authorization", _this.account.token_type + " " + _this.account.access_token);

						if (isFromFpx) {
							xhr.setRequestHeader('RPP_REF_TOKEN', parameters[0]);
						}
						return xhr;
					}
				}).done(function (respJson, status, header) {
					resultData = _this.serviceReponseCall(isSecure, respJson, header);
					successCallback(resultData);
				}).fail(function (jqXhr) {

					console.log('HTTP header status', jqXhr.status);
					
					if (jqXhr.status === 0) {
						failCallback('Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.');
					
					} else if (jqXhr.status == 404) {
						// failCallback('Requested page not found. [404]');
						console.log("In 404");
						setTimeout(function () {
							$('.preloader').fadeOut();
						}, 500);

						$('.not-found-wrapper').css('display', 'block');
						$('.page-level1-container').css('display', 'none');
					
					} else if (jqXhr.status == 500) {
						failCallback("Sorry. We've encountered connection error. Please try again.");
					
					}
					else {
						/*302,401*/
						if(jqXhr.responseText){

							var resultData;
							var responseText = jQuery.parseJSON(jqXhr.responseText);
							console.log('jqXhr.responseText json', responseText);

							resultData = {
								invocationResult: {
									responseHeaders: {},
									statusCode: jqXhr.status,
									array: responseText
								}
							};
							successCallback(resultData);
						}
						else {

							failCallback('Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.');
						}
					}

					$('.preloader').fadeOut();
				});
			} else if (serviceType == SecureServiceType.SERVICE_SECURE_LOGIN_STEP2) {
				console.log("@@@  SERVICE_SECURE_LOGIN_STEP2", parameters);

				var isFromFpx = false;
				if (parameters[1].FpxRefId) {
					var isFromFpx = true;
				}

				return $.ajax({
					method: "post",
					dataType: "json",
					url: serviceUrl,
					timeout:70000,
					data: parameters[2],
					contentType: "application/json",
					beforeSend: function (xhr) {
						xhr.setRequestHeader("Authorization", parameters[1].Authorization);
						xhr.setRequestHeader("Accept", "application/json");
						xhr.setRequestHeader("Channel-Auth-Code", parameters[1].ChannelAuthCode);
						xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
						xhr.setRequestHeader("Accept-Language", "en");
						xhr.setRequestHeader("PageId", "LOGIN");

						if (isFromFpx) {
							xhr.setRequestHeader('RPP_REF_TOKEN', parameters[1].FpxRefId);
						}
						return xhr;
					}
				}).done(function (respJson, status, header) {

					console.log('Config Data @@@@@@@ ', respJson);
					console.log('Config Data @@@@@@@ ', status);
					console.log('Config Data @@@@@@@ ', header);
					console.log('Config Data @@@@@@@ ', isSecure);
					localStorage.setItem("account", JSON.stringify(respJson));
					resultData = _this.serviceReponseCall(isSecure, respJson, header);
					successCallback(resultData);
				}).fail(function (jqXhr) {
					//alert("Internal HTTP Error " + jqXhr.status);
					var msg;
					if (jqXhr.status === 0) {
						msg = 'Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.';
						failCallback(msg);
					} else if (jqXhr.status == 404) {
						console.log("In 404");
						setTimeout(function () {
							$('.preloader').fadeOut();
						}, 500);

						$('.not-found-wrapper').css('display', 'block');
						$('.page-level1-container').css('display', 'none');
						// msg = 'Requested page not found. [404]';
					} else if (jqXhr.status == 500) {

						console.log('jqXhr.responseText 500', jqXhr.responseText);

						if (jqXhr.responseJSON) {
							msg = jqXhr.responseJSON;
						}
						else msg = "Sorry. We've encountered connection error. Please try again.";

						failCallback(msg);

					} else if (jqXhr.status == 302 || jqXhr.status == 308) {
						msg = jqXhr.responseJSON;
						failCallback(msg);
					} else if (jqXhr.status == 401) {
						msg = jqXhr.responseJSON;
						failCallback(msg);
					}
					else {
						msg = 'Uncaught Error.\n' + jqXhr.responseText;
						failCallback(msg);
					}
					
				});
			} else if (serviceType == ServiceType.SERVICE_FPX_CANCEL_PRE_LOGIN && parameters[2] == "loginpage") {
				console.log("SERVICE_FPX_CANCEL_PRE_LOGIN start");

				try {
					return $.ajax({
					dataType: "json",
					method:"delete",
					url: serviceUrl,
					timeout:70000,
					async: false,
					contentType: "application/json",
					beforeSend: function (xhr) {
						xhr.setRequestHeader("Authorization", parameters[0].Authorization);
						xhr.setRequestHeader("Channel-Auth-Code", parameters[0].ChannelAuthCode);
						xhr.setRequestHeader('PageId', 'FPX_CANCEL');
						xhr.setRequestHeader("RPP_REF_TOKEN", parameters[0].FpxRefId);
						return xhr;
					}
					}).done(function (respJson, status, header) {
						successCallback(respJson);
					}).fail(function (jqXhr) {

						failCallback(jqXhr.responseText);
						$('.preloader').fadeOut();
					});
				} catch (_error){
					console.log('Calling logout >>>', _error);
				}
				
			} else {
				console.log("@@ else");
			}
		}
	};

	//service Hub
	var ServiceHub = {
		//hubType: ServiceHubType.MFP_SERVICE,
		hubType: ServiceHubType.AJAX_SERVICE,

		handleException: function (result, successCallback, failCallback) {
			console.log('RESULT >>>', result);
			var errorMessage = '';
			//handle the error exception here

			if (result.invocationResult.statusCode === 200) {
				if (result.invocationResult.responseHeaders['x-cs-status'] === 'error') {
					errorMessage = '[' + result.invocationResult['error'] + '] ' + result.invocationResult['error_description'];
					failCallback(errorMessage);
				} else {
					var resultContent = result.invocationResult['array'];
					if (!resultContent) {
						resultContent = result.invocationResult;
					}
					successCallback(resultContent);
				}
			}
			else if (result.invocationResult.statusCode === 503) {
				console.log('Pre Login DOWNTIME thrown 1');
				successCallback(result.invocationResult, 'DOWNTIME');
			}
			else {
				if (result.invocationResult['error_description']) {
					errorMessage = result.invocationResult['error_description'] + ' [' + result.invocationResult['error'] + ']';
					failCallback(errorMessage);
				} else if (result.invocationResult.array['error_description']) {
					errorMessage = result.invocationResult.array['error_description'] + ' [' + result.invocationResult.array['error'] + ']';
					console.log('errorMessage', errorMessage);
					failCallback(errorMessage);
				} else {
					//alert('Failed to load this page. Please check your connection and try again.');
					failCallback('Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.');
				}
			}
		},

		handleExceptionForSecure: function (result, successCallback, failCallback) {
			console.log('handleExceptionForSecure', result);
			var errorMessage = '';
			//handle the error exception here
			
			if (result.responseJSON.data.array && result.responseJSON.data.array.faContext) {

				console.log('FA');
				failCallback(result.responseJSON.data.array.faContext);

			}
			else if (result.responseJSON.data.statusCode === 200) {
				if (result.responseJSON.data.responseHeaders['x-cs-status'] === 'error' || result.responseJSON.data.responseHeaders['X-CS-Status'] === 'error') {
					errorMessage = '[' + result.responseJSON.data['error'] + '] ' + result.responseJSON.data['error_description'];
					failCallback(errorMessage);
				} else {
					var authRequired = result.responseJSON.authRequired;

					if (authRequired === true) {
						failCallback('Authenticate fail');
					} else if (authRequired === false) {
						successCallback(result.responseJSON.data);
					}
				}
			}
			else if (result.responseJSON.data.statusCode === 503) {
				console.log('Pre Login DOWNTIME thrown 2');
				successCallback(result.responseJSON.data, 'DOWNTIME');
			}
			else if (result.responseJSON.data.statusCode === 500) {
				if (result.responseJSON.data['error_description']) {
					errorMessage = '[' + result.responseJSON.data['error'] + '] ' + result.responseJSON.data['error_description'];
					failCallback(errorMessage, result);
				} else {
					failCallback('Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.');
				}
			}
			else {
				if (result.responseJSON.data['error_description']) {
					errorMessage = '[' + result.responseJSON.data['error'] + '] ' + result.responseJSON.data['error_description'];
					failCallback(errorMessage);
				} else {
					failCallback('Unable to login at the moment due to some connection issue. Please ensure that you are connected to the internet all the time and try again later.');
				}
			}
		},

		getDataByService: function (serviceType, parameters, invocationContext, successCallback, failCallback) {
			var self = this;
			var temporarySuccess;

			switch (serviceType) {
				case ServiceType.SERVICE_LOGIN_STEP1:
				case ServiceType.SERVICE_USER_INFO:
				case ServiceType.SERVICE_LOGOUT:
				case ServiceType.SERVICE_OTP_STEP1:
					temporarySuccess = function (result) {
						console.log('login first step logged in success', result);
						self.handleException(result, successCallback, failCallback);
					};
					break;
				case SecureServiceType.SERVICE_SECURE_LOGIN_STEP2:
				case SecureServiceType.SERVICE_TOUCH_ID_AUTH:
				case SecureServiceType.SERVICE_SECURE_OTP_STEP2:
					temporarySuccess = function (result) {
						console.log('login second step logged in success', result);
						self.handleExceptionForSecure(result, successCallback, failCallback);
					};
					break;
			}

			var temporaryFail = function (result) {
				if (failCallback) {
					//failCallback('We are unable to connect to the server now. Please try again later');
					console.log('failCallback >> ', result);
					failCallback(result);
				}
			};

			var servicePoint = null;
			switch (ServiceHub.hubType) {
				case ServiceHubType.MFP_SERVICE:
					servicePoint = new WFPService();
					break;
				case ServiceHubType.AJAX_SERVICE:
					servicePoint = new AJAXService();
					break;
			}

			console.log('servicePoint >>> ', servicePoint);

			if (servicePoint) {
				servicePoint.getDataByService(serviceType, parameters, invocationContext, temporarySuccess, temporaryFail);
			}
		},

		submitSuccess: function () {
			if (ServiceHub.hubType === ServiceHubType.MFP_SERVICE) {
				MFPInit.submitSuccess();
			}
		}
	};

	return {
		ServiceType: ServiceType,
		ServiceHubType: ServiceHubType,
		ServiceHub: ServiceHub,
		SecureServiceType: SecureServiceType
	};
}());
