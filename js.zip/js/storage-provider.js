window.StorageProvider = (function() {
	//Change this value in compile process (MFP jsonStore or Localstorage/Window)
	var isMobile = false;
	var collectionStateValue = {};
	function initStore (key, callback) {
		console.log('Init jSonStore started...');
		var collections = {
			key : {
				searchFields: {key: 'string'}
			}
		};

		WL.JSONStore.init(collections).then(function (collections) {
			console.log('jSon Store Init Successfully Key:' , collections);
			collectionStateValue[key] = true;
			callback();
		}).fail(function (error) {
			console.log('jSon Store Init Failed Key:' , error);
		});
	}

	// Set the data to jSonStore or LocalStorage
	var SaveData = function(key, value, returnData) {
		if(WL && isMobile) {
			var options = {};
			if(collectionStateValue[key]) {
				var collection = WL.JSONStore.get(key);

				// We check to add data or replace it
				if(collection.length == 0) {	
					collection.add(value, options).then(function () {
						console.log('Data Successfully Added to jSonStore', value);
					}).fail(function (error) {
						console.log('Failed to add data to jSonStore', error);
					});
				}
				else {
					var id = collection[0]._id;
					var json = collection[0].json;
					var newData = {
						_id : id,
						json : {key: value}
					}
					console.log('New Data to Replace', newData);
					collection.replace(newData, options).then(function (numberOfDocsReplaced) {
						console.log('Data Successfully Replaced to jSonStore', numberOfDocsReplaced);
					}).fail(function (error) {
						console.log('Data Failed to Replaced jSonStore', error);
					});
				}
			}
			else {
				initStore(key, function() {
					var collection = WL.JSONStore.get(key);

					// We check to add data or replace it
					if(collection.length == 0) {
						collection.add(value, options).then(function () {
							console.log('Data Successfully Added to after init jSonStore', value);
						}).fail(function (error) {
							console.log('Failed to add data to after init jSonStore', error);
						});
					}
					else {
						var id = collection[0]._id;
						var json = collection[0].json;
						var newData = {
							_id : id,
							json : {key: value}
						}
						console.log('New Data to Replace after init', newData);
						collection.replace(newData, options).then(function (numberOfDocsReplaced) {
							console.log('Data Successfully Replaced to jSonStore', numberOfDocsReplaced);
						}).fail(function (error) {
							console.log('Data Failed to Replaced jSonStore', error);
						});
					}
				});
			}
		}
		else {
			console.log('Im using localstorage to store data');
			localStorage.setItem(key, value);
		}
	};
	
	
	// Get the data from jSonStore or LocalStorage
	var GetData = function (key, returnData) {
		if(WL && isMobile) {
			if(collectionStateValue[key]) {
				if(WL.JSONStore.get(key)) {
					console.log('Get data successfully from jSonStore', WL.JSONStore.get(key));
					returnData(WL.JSONStore.get(key)[0].json[key]);
				}
				else {
					returnData(null);
				}
			}
			else {
				initStore(key, function() {
					if(WL.JSONStore.get(key)) {
						console.log('Get data successfully from jSonStore after init', WL.JSONStore.get(key));
						returnData(WL.JSONStore.get(key)[0].json[key]);
					}
					else {
						returnData(null);
					}
				});
			}
		}
		else {
			console.log('Im using localstorage/window to get data');
			// if(localStorage.getItem(key)) {
			// 	returnData(localStorage.getItem(key));
			// }
			if(window.hashKeyValue) {
				returnData(window.hashKeyValue);
			}
			else {
				returnData(null);
			}
		}
	}
	
	return {
		saveData:SaveData,
		getData: GetData
	}
}());