(function() {
	'use strict';

	var $tacCmp = $('.tac-activation-wrapper');
	var $select = $tacCmp.find('select');

	// init select2
	$select.select2({
		minimumResultsForSearch: Infinity
	});
}());
