'use strict';
/*jshint undef:false */
/*jshint unused:false*/

//For dynamic flags and asset sharing purpose
function fixAddFlag(_addFlag) {
    if (!_addFlag) {
        // $('.title-row-2').addClass('hidden-md').addClass('hidden-sm').addClass('hidden-xs');
    } else {
        $('.title-row-2').removeClass('hidden-md').removeClass('hidden-sm').removeClass('hidden-xs');
    }
}


function isLandscape() {
    // console.log($('body').width( )) ;
    return $('body').width() > 991;
}

function isPortrait() {
    return $('body').width() >= 320 && $('body').width() <= 991;
}

function isSmallPortrait() {
    return $('body').width() <= 321;
}

//For dropdown without search box
function fixDropDownThrowKeyboard() {
    if ($('body').hasClass('mobile')) {
        $('.select2-input').parent().remove();
        $('.select2-focusser').remove();
    }
}

//Dynamic sidebarheight on to loading time difference in  render
var screenHeightSidebar = 0;

function fixSidebar() {
    window.setTimeout(function() {
        if (!screenHeightSidebar) {
            if ($('body').hasClass('mobile')) {
                screenHeightSidebar = parseFloat($('body').height()) -
                    parseFloat($('.sidebar-header').height()) -
                    parseFloat($('.sidebar-footer').height());
            } else {
                screenHeightSidebar = parseFloat($('.sidebar-menu').height()) -
                    parseFloat($('.sidebar-footer').height());

            }
        }
        screenHeightSidebar = screenHeightSidebar ? screenHeightSidebar : '100%';
        // console.log( screenHeightSidebar);
        $('.sidebar-menu').height(screenHeightSidebar);
    }, 1000);

}


//Collapse mobile panels by default
var clickDisabled = false;

function fixClickCollapse() {
    //hide all by default
    if (!$('body').hasClass('mobile') || isLandscape()) {
        return; }

    $('[data-toggle="collapse_wholething"]').each(function(event) {
        var target = $(this);
        if ($(this).attr('data-collapse-manual')) {
            // console.log(  $(this) );
        } else {
            (target).click();
        }

    });
    $('#investAcc').click();

}

//Fix tooltip sizing
function fixToolTip() {

    if ($('body').hasClass('mobile') && !isLandscape()) {
        var screenWidth = $('.container-fluid').width();
        $('ul.dropdown-menu.tooltip-dropdown').css({
            width: screenWidth
        });

    }
}

function fixHeaderTitle() {

    if (!($('body').hasClass('mobile'))) {
        return; }
    var widthScreen = $('#headerPortlet').width();
    //iphone6plus
    if (parseFloat(widthScreen) >= 410 && parseFloat(widthScreen) <= 430) {
        // $('#headerPortlet').find('.title-row-1').find('.main-title-header').css('margin','-3px 2% 5px 65px');

    }
    //iphone6
    else if (parseFloat(widthScreen) >= 360 && parseFloat(widthScreen) <= 375) {
        // $('#headerPortlet').find('.title-row-1').find('.main-title-header').css('margin','-3px 2% 5px 45px');

    }

}


//For dynamic height panels content that overlap min length
function fixAccOverviewHeightPanel() {

    /*$('.cimb-portlet-scrollable').each(function(){

         var childHeight= $(this).find( ':first-child' ).height()  ;
         childHeight= $(this).find( '.content-section' ).height()  ;
       //min height is 70px
        childHeight= childHeight<70 ? 70  :childHeight ;
        // console.log(childHeight)

         if(!$(this).hasClass('long-list-wrapper')  ){
             $(this).height(childHeight);
         }

     });*/

    $('#mutualFundPortlet').find('.children-portlet').each(function() {
        var childHeight = $(this).find('.content-section').height();
        $(this).height(childHeight);

    });

}
//For dynamic nested panels with inderminate height due to inderminate content length
function resizeLongListPanels() {

    var longlistHeight = $('#mutualFundPortlet').height();
    $('.panel-body-mutualFund').height(parseFloat(longlistHeight) - 20);
    $('#mutualFundPortlet').height(parseFloat(longlistHeight) - 30);

}

function closeQuickView(_elemObj) { $('.quickview-wrapper').removeClass('open'); }


function triggerModal(_elemSel) {
    window.setTimeout(function() {
        $(_elemSel).modal('toggle');
    }, 300);
}

//For sticky floating header - integrated with infiniscroll
function runStickyHeaderLogin() {
    if (!isPortrait()) {
        return false; }
    $('.scrollForm').scroll(function() {

        var div = $(this);
        if (div.scrollTop() <= 0) {
            $('.login-wrapper .headMenuRow.potrait-login ').removeClass('sticky');
            $('.login-wrapper .headMenuRow.potrait-login img').removeClass('sticky');
            $('.login-wrapper .login-container .scrollForm').removeClass('sticky');


            $('.headArea.potrait-login').removeClass('sticky');
            $('.headArea.potrait-login .logoRow').removeClass('sticky');
            $('.headArea.potrait-login .logoRow .logo').removeClass('sticky');


            $('.background-image ').attr('src', 'assets/img/citybgheadmobile.png');
            $('.background-image ').attr('data-src', 'assets/img/citybgheadmobile.png');
            $('.background-image ').attr('data-src-retina', 'assets/img/citybgheadmobile.png');
        } else {
            //normal scroll
            $('.login-wrapper .headMenuRow.potrait-login ').addClass('sticky');
            $('.login-wrapper .headMenuRow.potrait-login img').addClass('sticky');
            $('.login-wrapper .login-container .scrollForm').addClass('sticky');

            $('.headArea.potrait-login').addClass('sticky');
            $('.headArea.potrait-login .logoRow').addClass('sticky');
            $('.headArea.potrait-login .logoRow .logo').addClass('sticky');


            $('.background-image ').attr('src', 'assets/img/citybgheadmobile_sticky.png');
            $('.background-image ').attr('data-src', 'assets/img/citybgheadmobile_sticky.png');
            $('.background-image ').attr('data-src-retina', 'assets/img/citybgheadmobile_sticky.png');


        }
    });

}

function runStickyHeader() {

    $('.page-container').on('scroll', function() {

        var div = $(this);

        //infini scroll
        /*//This code is moved into dashboard detail
         if( $('.btn-more-trx').length >0 ){
           //detail controller- scroll bottom --->infini loadmore rec
           if(div.scrollTop() + $(window).height() ===( $(document).height() )) {
                // $('.btn-more-trx').click();
                 addMoreRecords() ;
             }
         }*/


        if (div[0].scrollHeight - div.scrollTop() === div.height()) {} else if (div.scrollTop() <= 20) {
            //top scroll
            $('.sticky-button').addClass('hidden');
            $('.sticky-header .header').removeClass('sticky');
            $('.sticky-header .title-row-1').removeClass('sticky');
            $('.sticky-header .title-head-block').removeClass('sticky');
            //$('.sticky-header .title-row-2').show();
            $('.sticky-header .title-row-2').slideDown(200);
        } else {
            //normal scroll
            $('.sticky-button').removeClass('hidden');
            $('.sticky-header .title-row-1').addClass('sticky');
            $('.sticky-header .header').addClass('sticky');
            $('.sticky-header .title-head-block').addClass('sticky');
            $('.sticky-header .title-head-block').addClass('border-shadow');

            $('.sticky-header .title-row-2').slideUp(200);
        }

        var $selectedBillerEl = $('.selected-billers-wrap .selected-billers');
        var $header = $('.header .title-head-block');
        var headerHeight = $header.outerHeight();
        var $window = $(window);
        var $pageContainer = $('.page-container');

        // get warning block if the warning shown
        var $warning = $('.js-system-warning-block');
        var warningH = $warning.outerHeight();

        if ($window.width() > 992 && $selectedBillerEl.length > 0) {
            // if (warningH) {
            //     // headerHeight += warningH;
            //     warningH = parseInt(warningH, 10);
            //     $selectedBillerEl.css('top', warningH);
            // } else {
            //     $selectedBillerEl.removeAttr('style');
            // }

            if ($pageContainer.scrollTop() >= headerHeight) {
                $selectedBillerEl.addClass('sticky');
            } else {
                $selectedBillerEl.removeClass('sticky');
            }
        }
    });


}


//For sticky context menu at mouse click binding
(function($, window) {
    var settings;

    function getMenuPosition(mouse, direction, scrollDir) {
        var win = $(window)[direction](),
            scroll = $(window)[scrollDir](),
            menu = $(settings.menuSelector)[direction](),
            position = mouse + scroll;

        // opening menu would pass the side of the page
        if (mouse + menu > win && menu < mouse) {
            position -= menu;
        }

        return position;
    }


    $.fn.contextMenu = function(_settings) {
        settings = _settings;
        return this.each(function() {

            // Open context menu
            // $(this).on("contextmenu", function (e) {
            // return native menu if pressing control
            $(this).on('click', function(e) {
                if (e.ctrlKey) {
                    return; }

                //close any other tooltip opened
                $('.dropdown.open').removeClass('open');

                //close if opened


                //open menu
                var $menu = $(settings.menuSelector)
                    .data('invokedOn', $(e.target))
                    .show()
                    .css({
                        position: 'absolute',
                        left: getMenuPosition(e.clientX - 100, 'width', 'scrollLeft'),
                        top: getMenuPosition(e.clientY + 10, 'height', 'scrollTop')
                    })
                    .off('click')
                    .on('click', 'a', function(e) {
                        $menu.hide();

                        var $invokedOn = $menu.data('invokedOn');
                        var $selectedMenu = $(e.target);

                        settings.menuSelected.call(this, $invokedOn, $selectedMenu);
                    });

                return false;
            });

            //make sure menu closes on any click
            $(document).click(function() {
                $(settings.menuSelector).hide();
            });
            //hide when selected already

            $('.tick-dropdown').find('li').find('a').on('click', function(e) {
                $(settings.menuSelector).hide();
            });
            //close this tooltip when other opened
            $('[data-toggle="dropdown"]').click(function() {
                $(settings.menuSelector).hide();
            });

        });


    };
})(jQuery, window);




function initDropdownBinding(_elemSel) {
    $(_elemSel).contextMenu({
        menuSelector: '#contextMenuInfo',
        menuSelected: function(invokedOn, selectedMenu) {
            var msg = 'You selected the menu item "' + selectedMenu.text() +
                ' ' + invokedOn.text() + ' ';
            //   alert(msg);
        }
    });

}


//END CONTEXT MENU
(function(wd, doc) {
	'use strict';
	/**
	 * Detect keyboard open on mobile
	 *
	 */
	var $window = $(wd);
	var $document = $(doc);
	var resizeLastHeight = $window.outerHeight();
	console.log('resizeLastHeight', resizeLastHeight);

	var isMobile = /Mobile/.test(navigator.userAgent);
	var isIos = /iPad|iPhone|iPod/.test(navigator.userAgent);

	if (isMobile) {
		if (!isIos) {
			implementAutoScroll();
		}
	}

	function implementAutoScroll() {
		$window.on('resize.open.keyboard', function() {
			var windowH = $window.outerHeight();

			// var inputSelector = 'input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=number], input[type=search], textarea';
			// var focusInput = $(inputSelector + ':focus');
			var activeElement = document.activeElement;
			var gap = resizeLastHeight - windowH;

			// implement when window change the height of window
			if (windowH < resizeLastHeight) {
				if (activeElement.tagName === 'INPUT') {
					$document.trigger('showkeyboard', {
						input: activeElement,
						gap: gap
					});
				}
			} else {
				$document.trigger('hidekeyboard');
			}

			resizeLastHeight = windowH;
		});

		$document.on('showkeyboard', function(e, data) {
			var $scrollContainer = $('.js-scroll-container');
			var $input = $(data.input);
			var scrollTop = $scrollContainer.scrollTop();
			var $window = $(window);
			var headerHeight = $('.header').outerHeight();
			var fixButtonHeight = $('#fixed-footer').outerHeight();
			var inputOffsetTop = data.input.getBoundingClientRect().top;

			// if (inputOffsetTop > 0) return;

			var timeout = setTimeout(function() {
				var currInputPos = {
					top: inputOffsetTop + scrollTop - $window.outerHeight() + headerHeight + fixButtonHeight
				};

				console.log('keyboard shown', currInputPos);
				$scrollContainer.animateScroll(currInputPos.top);
				clearTimeout(timeout);
			}, 200)
		})
		.on('hidekeyboard', function() {
			console.log('hidden keyboard');
		});
	}
}(window, document));
