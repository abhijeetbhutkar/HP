
function swingToTop() {
	$('html, body').animate({
		scrollTop: 0
	}, 600);

}

$(document).on({
	'DOMNodeInserted': function() {
		$('.pac-item, .pac-item span', this).addClass('needsclick');
	}
}, '.pac-container');


$(document).ready(function() {

	swingToTop();
	runStickyHeader() ; /*global runStickyHeader*/
	fixHeaderTitle(); /*global fixHeaderTitle*/
	fixAccOverviewHeightPanel(); /*global fixAccOverviewHeightPanel*/
	fixDropDownThrowKeyboard(); /*global fixDropDownThrowKeyboard*/
	fixToolTip() ; /*global fixToolTip*/

	window.setTimeout(function() {
		fixClickCollapse(); /*global fixClickCollapse*/
		$( '.info-more-option' ).each(function( index, element ) {
			initDropdownBinding(element); /*global initDropdownBinding*/
		});
	}, 3100 );

	$(window).resize(function() {
		fixHeaderTitle(); /*global fixHeaderTitle*/
		fixAccOverviewHeightPanel(); /*global fixAccOverviewHeightPanel*/
		fixToolTip() ; /*global fixToolTip*/
	});

	/*global FastClick*/
	if ('FastClick' in window) {
		FastClick.attach(document.body);
	}

	// Hard add class to body when dropdown shown
	$(document)
		.on('show.bs.dropdown', '[aria-tooltip-fullscreen="true"]', function(e) {
			$('body').addClass('show-fullscreen-tooltip');
			var el = e.currentTarget;
			var dropdownMenu = el.querySelector('.dropdown-menu');

			dropdownMenu.classList.add('in');
		})
		.on('hide.bs.dropdown', '[aria-tooltip-fullscreen="true"]', function(e) {
			var el = e.currentTarget;
			var dropdownMenu = el.querySelector('.dropdown-menu');

			dropdownMenu.classList.remove('in');
			$('body').removeClass('show-fullscreen-tooltip');
		})
});
