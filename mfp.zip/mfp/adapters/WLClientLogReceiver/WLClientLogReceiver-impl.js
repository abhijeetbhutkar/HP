function log(deviceInfo, logMessages) {

  /* The adapter can choose to process the parameters, 
     for example to forward them to a backend server for 
     safekeeping and further analysis.

     The deviceInfo object may look like this:
     {
       "appName":       "wlapp",
       "appVersion":    "1.0",
       "deviceId":      "66eed0c9-ecf7-355f-914a-3cedac70ebcc",
       "model":         "Galaxy Nexus - 4.2.2 - API 17 - 720x1280",
       "systemName":    "Android",
       "systemVersion": "4.2.2",
       "os.arch":       "i686",           // Android only
       "os.version":    "3.4.0-qemu+"     // Android only
      }
      The logMessages parameter is a JSON array 
      that contains JSON object elements, and might look like this:

        [{
          "timestamp"    : "17-02-2013 13:54:23:745",  // "dd-MM-yyyy hh:mm:ss:S"
          "level"        : "ERROR",                    // ERROR || WARN || INFO || LOG || DEBUG
          "package"      : "your_tag",                 // typically a class name, app name, or JavaScript object name
          "msg"          : "the message",              // a helpful log message
          "threadid"     : 42,                         // (Android only) id of the current thread
          "metadata"     : { "$src" : "js" }           // additional metadata placed on the log call
        }]

  */

  return true;

}