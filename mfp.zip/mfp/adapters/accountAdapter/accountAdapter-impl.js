// Account Overview Service
function AccountOverviewService(contries, quick) {
	//var path = '/v1/enquiry/accounts/summary?service-type=all&country=MY&country=SG';
	
	if(quick){
		var path = '/api/v1/quick/accounts/summary?service-type=all';
		if (contries) {
			path = '/api/v1/quick/accounts/summary?service-type=all' + contries;
		}
	} else {
		var path = '/api/v1/enquiry/accounts/summary?service-type=all';
		if (contries) {
			path = '/api/v1/enquiry/accounts/summary?service-type=all' + contries;
		}
	}

    // var requestHeaders = WL.Server.getClientRequest();
	// WL.Logger.error("*******requestHeaders******** "+requestHeaders);
	// var headersEnum = requestHeaders.getHeaderNames();
	// while(headersEnum.hasMoreElements()){
	// 	var headerName = headersEnum.nextElement();
	// 	var headerValue = requestHeaders.getHeader(headerName);
	// 	WL.Logger.info("***********Header info ************\n"+headerName +" : "+headerValue);
	// }

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;
	WL.Logger.debug('ACCESS TYPE/TOKEN IN Account:');
	WL.Logger.debug(tokenType + ' ' + oauthToken);

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ACCOUNT_OVERVIEW'
		}
	};

	return WL.Server.invokeHttp(input);
}


// Account Details Service (id, type)
function AccountDetailsService(param) {
	var path = '/api/v1/enquiry/accounts/' + param.id + '?t=' + param.type;
	//var path = '/v1/enquiry/accounts/' + param.id + '?t=' + param.type;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ACCOUNT_DETAILS_' + param.type
		}
	};

	return WL.Server.invokeHttp(input);
}


//Account Transaction History (id, type, dateRange, pageKey)
function AccountTransactionHistory(param) {
	///v1/enquiry/history/{accRelId}?t=SA&select-type={selectType}&from-date ={fromDate}&to-date={toDate}&date-range={dateRange}&pagination-key={paginationKey}
	//dateRange is temp set to 90
	//select-type is set to P
	var path = '/api/v1/enquiry/history/' + param.id + '?t=' + param.type + '&select-type=' + 'P' + '&date-range=' + 90 + '&pagination-key=' + param.pageKey;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ACCOUNT_DETAILS_HISTORY_' + param.type
		}
	};

	return WL.Server.invokeHttp(input);
}


//Send to the sever the list of country flags to set as default
function UpdateCountryFlagService(requestHeader, requestBody) {
	var path = '/api/v1/enquiry/accounts/country';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ACCOUNT_OVERVIEW'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}