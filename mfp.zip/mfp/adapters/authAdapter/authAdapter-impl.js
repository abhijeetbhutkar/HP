// Get intilization
function InitializationService(requestHeader, requestBody) {
	//var path = '/clients/CIMB/json/InitializationService.json';
	var path = '/api/v1/public/init';
	//var path = '/v1/public/init';

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': requestHeader.Authorization,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'LOGIN'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


//First step Login on Secure Type
function SecureWordLoginStep1(requestHeader, requestBody) {
	var path = '/api/v1/public/secure';
	//var path = '/v1/public/secure';

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization' : requestHeader.Authorization,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'LOGIN'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


//Second step login on Secure Type
function SecureWordLoginStep2(userName, requestHeader, requestBody) {
	var path = '/api/v1/oauth/token';
	//var path = '/v1/public/oauth/token';

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers: {
			'Authorization' : requestHeader.Authorization,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'LOGIN'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	var result = WL.Server.invokeHttp(input);
	WL.Logger.info('Response SECURE Login:' + JSON.stringify(result));
	var accessToken = result.access_token;
	var tokenType = result.token_type;
	var loginType = 'secureLoginStep2';

	return submitAuthentication(userName, accessToken, tokenType, result, loginType);
}


//TODO First step Login on OTP Type (Should be updated on SG)
function OTPLoginStep1(requestBody) {
	var path = '/v1/public/oauth/token';

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


//TODO Second step login on OTP Type (Should be updated on SG)
function OTPLoginStep2(userName, requestBody) {
	var path = '/v1/public/oauth/token';

	var input = {
		method : 'post',
		headers: {
			Authorization: 'Basic Y2xpZW50MTpzZWNyZXQxMjM=',
			contentType : 'application/json'
		},
		returnedContentType : 'json',
		path : path,
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	var result = WL.Server.invokeHttp(input);
	WL.Logger.info('Response OTP Login:' + JSON.stringify(result));
	var accessToken = result.access_token;
	var tokenType = result.token_type;
	var loginType = 'optStep2';
	

	return submitAuthentication(userName, accessToken, tokenType, result, loginType);
}


//It is a secure mfp auth call when using touchId
function TouchIDLoginService(userName, requestHeader, requestBody) {
	var path = '/api/v1/oauth/token';

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers: {
			'Authorization' : requestHeader.Authorization,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'LOGIN_TOUCH_ID'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	var result = WL.Server.invokeHttp(input);
	WL.Logger.info('Response SECURE Touch Login:' + JSON.stringify(result));
	var accessToken = result.access_token;
	var tokenType = result.token_type;
	var loginType = 'TouchId';

	return submitAuthentication(userName, accessToken, tokenType, result, loginType);
}


// To change the auth from partial to full access  
function IncrementalAuthService(requestHeader, requestBody) {
	var path = '/api/v1/common/increment/auth';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'INCREMENTAL_LOGIN'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// load secureword upon going from quick balance to full login
function SecureWord() {
	var path = '/api/v1/common/secureWord';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'INCREMENTAL_LOGIN_SECURE_WORD'
		}
	};

	return WL.Server.invokeHttp(input);
}


// Auth related implenetatoins
function onAuthRequired(headers, errorMessage, result) {
	errorMessage = errorMessage ? errorMessage : null;

	return {
		authRequired: true,
		errorMessage: errorMessage,
		data : result
	};
}

// Submit Authentication
function submitAuthentication(username, accessToken, tokenType, result, authType) {
	WL.Logger.debug('Submited AUTHENTICATION');
	WL.Logger.debug(username);
	WL.Logger.debug(tokenType);
	WL.Logger.debug(accessToken);
	WL.Logger.debug(authType);
	WL.Logger.debug(result);

	if (accessToken != null) {

		var userIdentity = {
			userId: username,
			attributes :{
				oauthToken : accessToken,
				tokenType : tokenType
			}
		};

		WL.Server.setActiveUser('AuthRealm', userIdentity);

		return {
			authRequired: false,
			loginType: authType,
			data: result
		};
	}

	return onAuthRequired(null, 'Invalid login credentials', result);
}

function onLogout() {
	WL.Client.setActiveUser('AuthRealm', null);
	WL.Logger.debug('Logged out USER');
}
