//it is for retrieving the list of fixed deposit products
function FdProductService() {
	var path = '/api/v1/transaction/fd-placement/product';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_LIST'
		}
	};

	return WL.Server.invokeHttp(input);
}


//To laod the fixed deposit charts
function FdChartService(products) {
	///v1/transaction/fd-placement/chart?productId={productId}&productId={productId}
	var path = '/api/v1/transaction/fd-placement/chart?' + products;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_CHART'
		}
	};

	return WL.Server.invokeHttp(input);
}


// Get product details and tenure
function FdPlacementFormService(productId) {
	var path = '/api/v1/transaction/fd-placement/form?productId=' + productId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_PLACEMENT'
		}
	};

	return WL.Server.invokeHttp(input);
}


// To post the data and validate the fixed deposit
function FdPlacementValidationService (requestHeader, requestBody) {
	var path = '/api/v1/transaction/fd-placement/form';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_PLACEMENT_VALIDATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// Insert the data into Fixed deposit
function FdPlacementInsertService (requestHeader, requestBody) {
	var path = '/api/v1/transaction/fd-placement/form';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_PLACEMENT_CONFIRMATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


//Get the Crediting List from Quick action menu for update
function FdUpdateFormService(accRelId) {
	var path = '/api/v1/transaction/fd-update/form/' + accRelId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_UPDATE'
		}
	};

	return WL.Server.invokeHttp(input);
}


// Validate and update FixedDeposit from quick action menu
function FdUpdateValidationService (requestHeader, requestBody) {
	var path = '/api/v1/transaction/fd-update/form';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_UPDATE_VALIDATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}



// Isernt to update FixedDeposit from quick action menu
function FdUpdateInsertService (requestHeader, requestBody) {
	var path = '/api/v1/transaction/fd-update/form';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_UPDATE_CONFIRMATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}



//get form data for uplift
function FdUpliftmentFormService(accRelId) {
	var path = '/api/v1/transaction/fd-upliftment/form/' + accRelId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_UPLIFT'
		}
	};

	return WL.Server.invokeHttp(input);
}


//post validate for uplift
function FdUpliftmentValidationService (requestHeader, requestBody) {
	var path = '/api/v1/transaction/fd-upliftment/form';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_UPLIFT_VALIDATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


//Put Insert Uplift
function FdUpliftmentInsertService (requestHeader, requestBody) {
	var path = '/api/v1/transaction/fd-upliftment/form';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'FIXED_DEPOSIT_UPLIFT_CONFIRMATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}
