//To get Crediting/exchange accounts (TO list)
function FundTransferService(moduleId) {
	var path = '/api/v1/transaction/fund-transfer/form/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'TRANSFER_MONEY'
		}
	};

	return WL.Server.invokeHttp(input);
}


// To Validate the fund transfer
function  FundTransferValidationService(requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/fund-transfer/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'TRANSFER_MONEY_VALIDATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// To perform the data insertion for Fund trasfer 
function FundTransferInsertService (requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/fund-transfer/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'TRANSFER_MONEY_CONFIRMATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// To validate Flexi Fund Transfer 
function  FlexiLoanTransferValidationServ(requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/flexi-loan/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'MENU_TRANSFER_MONEY_VALIDATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// To Insert Flexi Fund Transfer 
function  FlexiLoanTransferInsertService(requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/flexi-loan/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'MENU_TRANSFER_MONEY_CONFIRMATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}