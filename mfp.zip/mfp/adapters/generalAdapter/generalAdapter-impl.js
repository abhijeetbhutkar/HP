//ATM Locator service (Not Secure)
function LocationService(authKey, country) {
	var path = '/api/v1/enquiry/location-service?country=' + country;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': authKey,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ATM_LOCATOR'
		}
	};

	return WL.Server.invokeHttp(input);
}


//Banner and About us service (Not Secure)
function BannerAndContentService(authKey) {
	var path = '/api/v1/public/banner/about-us';

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': authKey,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ABOUT_US'
		}
	};

	return WL.Server.invokeHttp(input);
}


//Logout summary + actual Logout (Secure)
function ClicksLogoutSummaryService() {
	var path = '/api/v1/common/logout-summary';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'delete',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'LOGOUT_SUMMARY'
		}
	};

	return WL.Server.invokeHttp(input);
}


//Money Online Survery (ecure)
function ClicksMonkeySurveyService(moduleId) {
	var path = '/api/v1/enquiry/survey/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'LOGOUT_SUMMARY_SURVEY'
		}
	};

	return WL.Server.invokeHttp(input);
}


// Get DisplayName and LastTimeLogin
function UserInquiryService(deviceId, freshInstall) {
	///v1/enquiry/user/inquiry?device-id={deviceId}&fresh-install=true
	var path = '/api/v1/common/user/inquiry?device-id=' + deviceId + '&fresh-install=' + freshInstall;
	//var path = '/api/v1/enquiry/user/inquiry?device-id=' + deviceId + '&fresh-install=' + freshInstall;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ACCOUNT_OVERVIEW'
		}
	};

	return WL.Server.invokeHttp(input);
}


// Agree the Terms and Conditions
function TnCAcceptanceService(moduleId) {
	var path = '/api/v1/tnc/general?module=' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'TNC_PAGE'
		}
	};

	return WL.Server.invokeHttp(input);
}

//Check for the downtime messges
function ModuleAccessService(moduleId) {
	var path = '/api/v1/enquiry/access/' + moduleId

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'DOWNTIME_CASES'
		}
	};

	return WL.Server.invokeHttp(input);
}