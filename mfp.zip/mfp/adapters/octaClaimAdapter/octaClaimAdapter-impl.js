//Get the crediting List
function CreditngAccountService(moduleId) {
	var path = '/api/v1/transaction/crediting-account/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'OCTA_CLAIM_CONFIRM'
		}
	};

	return WL.Server.invokeHttp(input);
}

//Get the list of S/R
function OctoSendInquiryList(inqType) {
	var path = '/api/v1/transaction/octoSend/form?inqType=' + inqType;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'OCTA_CLAIM'
		}
	};

	return WL.Server.invokeHttp(input);
}

// perform Claim Money
function OctoSendClaimMoney (requestHeader, requestBody) {
	var path = '/api/v1/transaction/octoSend/claim';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'OCTA_CLAIM_PERFORM'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}