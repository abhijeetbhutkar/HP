//to search an account with biller Name
function PayBillBillerSearchService(moduleId, billerName) {
	var path = '/api/v1/transaction/pay-bill/biller/' + moduleId + '?key=' + billerName;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'PAY_BILL'
		}
	};

	return WL.Server.invokeHttp(input);
}


//it is for retrieving recent and favorite list.
function PayBillFormDataService(moduleId) {
	var path = '/api/v1/transaction/pay-bill/form/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'PAY_BILL'
		}
	};

	return WL.Server.invokeHttp(input);
}


//this will be called when u select an account in fav or enter an open account.
function PayBillBillerInfoService (requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/pay-bill/biller/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'PAY_BILL'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// pre-validation on bill account number if there is RTN flow
function PayBillPreValidationService (requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/pay-bill/bill/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'PAY_BILL'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// Validate the whole obj
function PayBillValidationService (requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/pay-bill/form/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'PAY_BILL_VALIDATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


// Confrim and insert pay bill
function PayBillPaymentService (requestHeader, requestBody, moduleId) {
	var path = '/api/v1/transaction/pay-bill/form/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'PAY_BILL_CONFIRMATION'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}