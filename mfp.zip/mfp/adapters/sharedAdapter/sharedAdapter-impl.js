//To get Debiting accounts (FROM list)
function DebitingAccountService (moduleId) {
	var path = '/api/v1/transaction/debiting-account/' + moduleId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'DEBITING_LIST'
		}
	};

	return WL.Server.invokeHttp(input);
}


//Load the list of settings
function AppDeviceService (deviceId) {
	var path = '/api/v1/enquiry/user/self/app-devices/' + deviceId + '/settings';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'SETTINGS_SCREEN'
		}
	};

	return WL.Server.invokeHttp(input);
}


// To validate each module - activate/deactivate
function ValidateAppServiceActivation (deviceId, parameters) {
	// v1/enquiry/user/self/app-devices?deviceId={deviceId}&name=toa&actionType=activate
	var path = '/api/v1/enquiry/user/self/app-devices?deviceId=' + deviceId + '&' + parameters;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'HOME_SCREEN'
		}
	};

	return WL.Server.invokeHttp(input);
}


// Request for OTP and activation
function RequestAppServiceActivation (requestHeader, requestBody) {
	var path = '/api/v1/transaction/user/self/app-devices';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'post',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ACTIVATION_CONFIRM'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}

// Activate the module
function ActivateAppService (requestHeader, requestBody) {
	var path = '/api/v1/transaction/user/self/app-devices';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'put',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'ACTIVATION_INSERT'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


//Request for TAC (SMS)
function TACRequest (requestHeader, requestBody) {
	var path = '/api/v1/transaction/request-tac';

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'POST',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Channel-Auth-Code': requestHeader.ChannelAuthCode,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'OTP_PAGE'
		},
		body : {
			contentType : 'application/json',
			content: requestBody
		}
	};

	return WL.Server.invokeHttp(input);
}


//Load the list of active token list
function ActiveTokenList(serviceId) {
	var path = '/api/v1/transaction/active-token/' + serviceId;

	var userId = WL.Server.getActiveUser();
	var oauthToken = userId.attributes.oauthToken;
	var tokenType = userId.attributes.tokenType;

	var input = {
		method : 'get',
		returnedContentType : 'json',
		path : path,
		headers : {
			'Authorization': tokenType + ' ' + oauthToken,
			'Accept': 'application/json',
			'Content-Type': 'application/json; charset=UTF-8',
			'Accept-Language': 'en',
			'PageId': 'OTP_TOkEN_LIST'
		}
	};

	return WL.Server.invokeHttp(input);
}
