package com.CIMBClicksMY;

public final class AppConstants {

    /** The message for authentication by using FingerPrint */
    public static final int MSG_AUTHENTICATION = 1000;

    /** The message for opening the authentication with FingerPrint wiht password */
    public static final int MSG_AUTHENTICATION_USER_INTERFACE_WITH_PASSWORD = 1001;

    /** The message for opening the authentication's user-interface with FingerPrint without password */
    public static final int MSG_AUTHENTICATION_USER_INTERFACE_WITHOUT_PASSWORD = 1002;

    /** The message to cancel the scanning of FingerPrint feature */
    public static final int MSG_CANCEL = 1003;

    /** The message to register the FingerPrint feature */
    public static final int MSG_REGISTER = 1004;

    /** The message for getting the name of the FingerPrint*/
    public static final int MSG_GET_NAME = 1005;

    /** The message for getting the unique-id of the FingerPrint */
    public static final int MSG_GET_UNIQUE_ID = 1006;

    /** The message for getting the authentication's index */
    public static final int MSG_AUTHENTICATION_INDEX = 1007;

    /** The message for getting the authentication-ui's index */
    public static final int MSG_AUTHENTICATION_USER_INTERFACE_INDEX = 1008;

    /** The message for enabling the UserInterface of authentication by scanning FingerPrint with custom-logo */
    public static final int MSG_AUTHENTICATION_USER_INTERFACE_CUSTOM_LOGO = 1009;

    /** The message for enabling hte UserInterface of authentication by scanning FingerPrint with transparency-ui */
    public static final int MSG_AUTHENTICATION_USER_INTERFACE_TRANSPARENCY = 1010;

    /** The message for dismissing the authentication's user-interface */
    public static final int MSG_AUTHENTICATION_USER_CUSTOM_DISMISS = 1011;

    /** The message for starting hte authentication's user-interface */
    public static final int MSG_AUTHENTICATION_USER_INTERFACE_BUTTON_STANDBY = 1012;

}
