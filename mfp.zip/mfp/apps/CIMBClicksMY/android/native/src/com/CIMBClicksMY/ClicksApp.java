package com.CIMBClicksMY;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.support.multidex.MultiDexApplication;
import android.util.Log;
import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.SsdkVendorCheck;
import com.samsung.android.sdk.pass.Spass;
import com.samsung.android.sdk.pass.SpassFingerprint;

/**
 * The class <code>ClicksApp</code> which provides the global access for current application. As the global instance of the current app that has been
 * declared into the manifest.xml file, Its features determine all of aspects which has been reused into other components.
 */
public class ClicksApp extends MultiDexApplication {

    private static final String TAG = ClicksApp.class.getSimpleName();

//	public static boolean isShowMessengerView = false;
	public static boolean isUpdateMsgCount = false;
	public static boolean isActivateMessenger = false;

    protected ForegroundService mService;

    public ForegroundService getService() {
        return mService;
    }

    public void setService(ForegroundService service) {
        mService = service;
    }

    public Spass mSpass;

    public SpassFingerprint mSpassFingerprint;

    public Context mContext;

    public boolean mIsFingerPrintEnabled = false;

    public void setFingerPrintEnabled(boolean isFingerPrintEnabled) {
        this.mIsFingerPrintEnabled = isFingerPrintEnabled;
    }

    public boolean isFingerPrintEnabled() {
        return mIsFingerPrintEnabled;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;

//        mSpass = new Spass();
//        try {
//            mSpass.initialize(mContext);
//        } catch (SsdkUnsupportedException e) {
//            e.printStackTrace();
//        }
//
//        mIsFingerPrintEnabled = mSpass.isFeatureEnabled(Spass.DEVICE_FINGERPRINT);
//        if (mIsFingerPrintEnabled) {
//            mSpassFingerprint = new SpassFingerprint(mContext);
//        } else {
//            Log.d(TAG, "FingerPrint Service is not supported in the device");
//        }
    }

    /**
     * Method registerBroadcastReceiver() which has been used for Activity
     * @param context The ApplicationContext's intance maybe the Activity's Context.
     * @param receiver The BroadcastReceiver instance
     */
    public void registerBroadcastReceiver(final Context context, BroadcastReceiver receiver) {
        final IntentFilter filter = new IntentFilter();
        filter.addAction(SpassFingerprint.ACTION_FINGERPRINT_RESET);
        filter.addAction(SpassFingerprint.ACTION_FINGERPRINT_ADDED);
        filter.addAction(SpassFingerprint.ACTION_FINGERPRINT_REMOVED);
        context.registerReceiver(receiver, filter);

    }

    /**
     * Method unregisterBroadcastReceiver() which has been used for unregisterring the existing broadcast receiver into the specified activity
     * @param context The ApplicationContext's instance, maybe the Activity's context.
     * @param receiver The BroadcastReceiver instance.
     */
    public void unregisterBroadcastReceiver(final Context context, BroadcastReceiver receiver) {
        try {
            if (context != null) {
                context.unregisterReceiver(receiver);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
