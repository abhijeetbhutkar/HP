package com.CIMBClicksMY;

import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;

public class ForegroundService extends com.worklight.androidgap.WLForegroundService{

    private static final String TAG = ForegroundService.class.getSimpleName();

    public static final int PUSHING_BACK_FINGER_PRINT_DATA = 3;
    public static final int GETTING_FINGER_PRINT_MSG = 1;
    public static final int CHECKING_ROOTED_DEVICE_MSG = 2;

    public final IncomingHandler mServiceHandler = new IncomingHandler();

    public final Messenger mMessenger = new Messenger(mServiceHandler);
    /**
     * The action string which should be sent from other intent for getting the finger's print
     * if the current device has been supported by the FingerPrint's recognition sensors.
     **/
    public static final String GETTING_FINGER_PRINT_ACTION = "com.cimbclicks.action.getting_finger_print";
    /**
     * The action string which should be sent from other intent for checking the current device
     * has been rooted or not.
     */
    public static final String CHECKING_ROOTED_DEVICE_ACTION = "com.cimbclicks.action.checking_rooted_device";

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return mMessenger.getBinder();
    }

    /**
     * The class <code>IncomingHandler</code> which has been used to handle the message which has sent from the Activity components.
     * With each of cases into the bunch of messages, navigate to doing the specific purposes.
     */
    public class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                // Todo: Checking the current device has been rooted or not?
                case CHECKING_ROOTED_DEVICE_MSG: {
                    break;
                }
                // Todo: Start to get the finger's print from android device
                case GETTING_FINGER_PRINT_MSG: {
                    break;
                }
                // Todo: sending the encoding data back to the other components
                case PUSHING_BACK_FINGER_PRINT_DATA: {
                    break;
                }
            }
            super.handleMessage(msg);
        }
    }
}

