package com.CIMBClicksMY.GCM;

import android.os.Bundle;
import android.util.Log;

import com.CIMBClicksMY.utils.CommonUtils;
import com.google.android.gms.gcm.GcmListenerService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;

public class GPPListenerService extends GcmListenerService {

    private final String TAG = "GPPListenerService";

    /**
     * Called when message is received.
     *
     * @param from SenderID of the sender.
     * @param data Data bundle containing message data as key/value pairs.
     *             For Set of keys use data.keySet().
     */
    // [START receive_message]
    @Override
    public void onMessageReceived(String from, Bundle data) {
		Log.d(TAG, "onMessageReceived from : " + from + ", data " + data);

        JSONObject jsonObject = new JSONObject();
        final Set<String> keys = data.keySet();
        for (String key : keys) {
            try {
                jsonObject.put(key, data.get(key));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Log.d(TAG, "Sending JSON:" + jsonObject.toString());

		String body = null;
		long time = 0;
		try {

			body = jsonObject != null ? jsonObject.getString("body") : null;
			time = jsonObject != null ? jsonObject.getLong("google.sent_time") : 0;
		} catch (JSONException e) {
			body = null;
			time = 0;
		}


		CommonUtils.createMsgNotification(GPPListenerService.this, body);
		CommonUtils.notifyJsMessengerCount(GPPListenerService.this, body, time);
    }
    // [END receive_message]

}
