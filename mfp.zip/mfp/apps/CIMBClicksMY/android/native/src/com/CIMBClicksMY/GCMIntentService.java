package com.CIMBClicksMY;

import android.content.Context;
import android.content.Intent;

public class GCMIntentService extends com.worklight.androidgap.push.GCMIntentService{
	//Nothing to do here...

	@Override
	protected void onMessage(Context context, Intent intent) {
//		super.onMessage(context, intent);
	}
}
