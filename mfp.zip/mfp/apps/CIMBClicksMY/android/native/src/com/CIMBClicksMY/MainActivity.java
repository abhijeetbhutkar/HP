package com.CIMBClicksMY;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.CIMBClicksMY.fragments.ContactsFragment;
import com.CIMBClicksMY.plugins.RootDetection;
import com.CIMBClicksMY.utils.CommonUtils;
import com.CIMBClicksMY.views.tsnackbar.TSnackbar;
import com.CIMBClicksMY.widgets.MessengerWebView;
import com.samsung.android.sdk.pass.Spass;
import com.samsung.android.sdk.pass.SpassFingerprint;
import com.worklight.androidgap.api.WL;
import com.worklight.androidgap.api.WLInitWebFrameworkListener;
import com.worklight.androidgap.api.WLInitWebFrameworkResult;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaChromeClient;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CordovaWebViewClient;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends FragmentActivity implements CordovaInterface, WLInitWebFrameworkListener,
        Animation.AnimationListener, DrawerLayout.DrawerListener{

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 1;

    private CordovaWebView mHomeWebView;
    private MessengerWebView mMessengerWebView;

    public static final String SHOW_MESSENGER_PANEL = "show_messenger_panel";
    public static final String CLOSE_MESSENGER_PANEL = "close_messenger_panel";
	public static final String UPDATE_MESSAGE_COUNT = "update_message_count";
	public static final String ACTIVATE_MESSENGER = "activate_messenger";
    public static final String MATCHED_PATTERN = "^(.*://|javascript:)[\\s\\S]*$";

	public static final String PARAM_MSG_SUBJECT = "msg_subject";
	public static final String PARAM_MSG_TIME = "msg_time";

    public RelativeLayout mMainContent;

    public DrawerLayout mFrameContent;

    public RelativeLayout mProgressBarContainer;
    public ProgressBar mProgressBar;

    private final ExecutorService mThreadPool = Executors.newCachedThreadPool();
    public static MainActivity mApp;

    public boolean mIsLoadedWebView = false;
    public MessengerWebClient mMessengerWebViewClient;
    public MessengerChromeClient mMessengerChromeClient;

    public String mMessengerURLString;

    public SpassFingerprint mSpassFingerprint;
    public Spass mSpass;
	private float lastTranslate = 0.0f;

    private ProgressDialog dialog;
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        mApp = this;

		// disabled by soe yan naing
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_main);

        if(getIntent().getBooleanExtra("isShowMessengerView", false))
            handleShowMessengerView(true, false);

        onInitializedUI();

		// Provides initialization services for hybrid applications.
        WL.createInstance(this);
        WL.getInstance().showSplashScreen(this);
        WL.getInstance().initializeWebFramework(getApplicationContext(), this);

        showMessengerIntentFilter.addAction(SHOW_MESSENGER_PANEL);
        showMessengerIntentFilter.addAction(CLOSE_MESSENGER_PANEL);
		showMessengerIntentFilter.addAction(UPDATE_MESSAGE_COUNT);
    }

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);

        Log.d(TAG, "onNewIntent");
        if(intent.getBooleanExtra("isShowMessengerView", false))
            handleShowMessengerView(true, true);

	}

    @Override
    public void requestPermission(CordovaPlugin var1, int var2, String var3){}

    @Override
    public void requestPermissions(CordovaPlugin var1, int var2, String[] var3){}

    @Override
    public boolean hasPermission(String var1){return false;}

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void onInitializedUI() {
        mFrameContent = (DrawerLayout) findViewById(R.id.frame_content);
        mMainContent = (RelativeLayout) findViewById(R.id.main_content);

        mProgressBarContainer = (RelativeLayout) findViewById(R.id.loading_bar_container);
        mProgressBar = (ProgressBar) findViewById(R.id.loading_progressbar);

        mHomeWebView =  (CordovaWebView) findViewById(R.id.main_webview);
        mMessengerWebView = (MessengerWebView) findViewById(R.id.messenger_webview);
        mMessengerWebView.setVisibility(View.VISIBLE);

        mFrameContent.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        mFrameContent.closeDrawers();
		mFrameContent.addDrawerListener(MainActivity.this);

        mFadeInAnim = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        mFadeOutAnim = AnimationUtils.loadAnimation(this, R.anim.fade_out);
        mProgressBarContainer.setLayoutAnimationListener(this);

    }

    @Override
    public void startActivityForResult(CordovaPlugin cordovaPlugin, Intent intent, int requestCode) {
        Log.d(TAG, "startActivityForResult is unImplemented");
    }

    @Override
    public void setActivityResultCallback(CordovaPlugin cordovaPlugin) {
        Log.d(TAG, "setActivityResultCallback in unImplemented");

    }

    @Override
    public Activity getActivity() {
        return this;
    }

    @Override
    public Object onMessage(String msg, Object obj) {
        Log.d(TAG, msg);
        if (msg.equalsIgnoreCase("exit")) {
            super.finish();
        }
        return null;
    }

    @Override
    public ExecutorService getThreadPool() {
        return mThreadPool;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onInitWebFrameworkComplete(WLInitWebFrameworkResult result) {
        if (result.getStatusCode() == WLInitWebFrameworkResult.SUCCESS) {

            CordovaWebViewClient homeWebViewClient = new CordovaWebViewClient(this, mHomeWebView) {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    Log.d(TAG, "WebView Is Openning: " + url);
                    view.loadUrl(url);
                    return true;
                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                }
            };

            mHomeWebView.setWebViewClient(homeWebViewClient);
            mHomeWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
            mHomeWebView.getSettings().setJavaScriptEnabled(true);
            mHomeWebView.getSettings().setTextZoom(100);
            mHomeWebView.loadUrl(WL.getInstance().getMainHtmlFilePath());

            mMessengerWebView.setLayerType(View.LAYER_TYPE_SOFTWARE , null);
			mMessengerWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
            mMessengerWebView.getSettings().setLoadWithOverviewMode(true);
            mMessengerWebView.getSettings().setJavaScriptEnabled(true);
			mMessengerWebView.addJavascriptInterface(new MessengerWebViewInfterface(this), "AndroidFunction");
        } else {
            handleWebFrameworkInitFailure(result);
        }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void setLayerTypeForWebView(CordovaWebView webView) {
        try {
            Method setLayerTypeMethod = webView.getClass().getMethod("setLayerType", int.class, Paint.class);
            setLayerTypeMethod.invoke(webView, View.LAYER_TYPE_SOFTWARE, null);
        } catch (NoSuchMethodException ex){
            ex.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    private void handleWebFrameworkInitFailure(WLInitWebFrameworkResult result) {
        AlertDialog.Builder alertDiaLogBuilder = new AlertDialog.Builder(this);
        alertDiaLogBuilder.setNegativeButton(R.string.close, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface diaLog, int which) {
                finish();
            }
        });

        alertDiaLogBuilder.setTitle(R.string.error);
        alertDiaLogBuilder.setMessage(result.getMessage());
        alertDiaLogBuilder.setCancelable(false).create().show();
    }

    @Override
    public void onBackPressed() {
        if (mFrameContent.isDrawerOpen(GravityCompat.END)) {
            LocalBroadcastManager.getInstance(mApp).sendBroadcast(new Intent(CLOSE_MESSENGER_PANEL));
            mFrameContent.closeDrawers();
			return;
        }

        ContactsFragment fragment = (ContactsFragment) getSupportFragmentManager()
                .findFragmentByTag(ContactsFragment.class.getSimpleName());
        if (fragment != null){
            removeFragment(fragment);
            return;
        }

        super.onBackPressed();
    }

    public void clearMessengerHistory() {
        mMessengerWebView.clearHistory();
    }

    public void requestMessengerFocus() {
        mMessengerWebView.requestFocus();
    }

    public void invalidateMessenger() {
        mMessengerWebView.invalidate();
    }

    public void setMessengerVisibility(int visibility) {
        mMessengerWebView.setVisibility(visibility);
    }

    public void loadMessengerWebViewContent(String url) {
        mMessengerWebView.setWebViewClient(mMessengerWebViewClient);
        mMessengerWebView.setWebChromeClient(mMessengerChromeClient);
        mMessengerWebView.loadUrl(((url.matches(MATCHED_PATTERN) ? "" : "file:///android_asset/www/") + url));
    }

	public void reloadMessengerWebView() {
		if (mMessengerWebView != null) {
			mMessengerWebView.reload();
		}
	}

	@Override
	public void onDrawerSlide(View drawerView, float slideOffset) {
		float moveFactor = (drawerView.getWidth() * slideOffset);

//		if (!(drawerView instanceof RelativeLayout)) { // if right layout
			moveFactor = -moveFactor;
//		}

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			mMainContent.setTranslationX(moveFactor);
		} else {
			TranslateAnimation anim = new TranslateAnimation(lastTranslate, moveFactor, 0.0f, 0.0f);
			anim.setDuration(0);
			anim.setFillAfter(true);
			mMainContent.startAnimation(anim);

			lastTranslate = moveFactor;
		}
	}

	@Override
	public void onDrawerOpened(View drawerView) {

	}

	@Override
	public void onDrawerClosed(View drawerView) {
		// update msg count on bell icon.
		refreshMesageCount();
	}

	@Override
	public void onDrawerStateChanged(int newState) {

	}

	public class MessengerWebViewInfterface {
		Context mContext;

		MessengerWebViewInfterface(Context c) {
			mContext = c;
		}

		@JavascriptInterface
		public void activateMessenger(){
			Log.d(TAG, "calling from JavascriptInterface");
			ClicksApp.isActivateMessenger = true;
			handleActivateMessenger();
		}

	}

    public IntentFilter showMessengerIntentFilter = new IntentFilter(SHOW_MESSENGER_PANEL);

    public BroadcastReceiver mShowMessengerDiaLogReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            final String url = intent.getStringExtra("url");

            if (action.equalsIgnoreCase(SHOW_MESSENGER_PANEL)) {
                if (!MainActivity.this.isLoadedWebView()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadMessengerWebViewContent(url);
                        }
                    });
                } else {
					reloadMessengerWebView();
				}
                mFrameContent.openDrawer(GravityCompat.END);
				CommonUtils.closeMsgNotification(MainActivity.this);
            } else if (action.equalsIgnoreCase(CLOSE_MESSENGER_PANEL)) {
                mFrameContent.closeDrawer(GravityCompat.END);

				// update msg count on bell icon.
				refreshMesageCount();

				CommonUtils.closeMsgNotification(MainActivity.this);
            } else if (action.equalsIgnoreCase(UPDATE_MESSAGE_COUNT)) {
				if (mHomeWebView != null) {
					refreshMesageCount();
					ClicksApp.isUpdateMsgCount = false;

					String subject = intent.getStringExtra(PARAM_MSG_SUBJECT);
					long time = intent.getLongExtra(PARAM_MSG_TIME, 0);
					showTopMessageLayout(subject, time);
				}
				Log.d(TAG, "on message arrived, Broadcast Receiver");
			} else if (action.equalsIgnoreCase(ACTIVATE_MESSENGER)) {
				if (mHomeWebView != null) {
					mHomeWebView.loadUrl("javascript:activateMessenger('MESSENGER_ACTIVATION','null')");
					ClicksApp.isActivateMessenger = false;
				}
				Log.d(TAG, "on activate messenger, Broadcast Receiver");
			}
        }
    };

    public void sendBroadCastShowOrHidePanel(Intent intent, String action, String url) {
        intent.setAction(action);
        intent.putExtra("url", url);
        LocalBroadcastManager.getInstance(MainActivity.this).sendBroadcast(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.d(TAG, String.format("DeviceName: %s", CommonUtils.getDeviceName()));

		// should not call plugin class here as different state between Activity & PlugIns. "rootDetection.isDeviceRooted()".
//        final RootDetection rootDetection = new RootDetection();
//        final String rootStatus = rootDetection.isDeviceRooted() ? getResources().getString(R.string.current_device_has_rooted_content)
//                : getResources().getString(R.string.current_device_has_not_rooted_content);
//        Log.d(TAG, "Device: " + rootStatus);

        mMessengerWebViewClient = new MessengerWebClient(this, mMessengerWebView);
        mMessengerChromeClient = new MessengerChromeClient(this, mMessengerWebView);

        if (mHomeWebView != null) {
            mHomeWebView.handleResume(true);
        }

        if (mMessengerWebView != null) {
            mMessengerWebView.handleResume(true);
        }

        LocalBroadcastManager.getInstance(MainActivity.this).registerReceiver(mShowMessengerDiaLogReceiver, showMessengerIntentFilter);

		handleOnMessageArrived();
		handleActivateMessenger();
    }


    @Override
    protected void onPause() {
        super.onPause();

        if (mHomeWebView != null) {
            mHomeWebView.handlePause(true);
        }

        if (mMessengerWebView != null) {
            mMessengerWebView.handlePause(true);
        }
        LocalBroadcastManager.getInstance(MainActivity.this).unregisterReceiver(mShowMessengerDiaLogReceiver);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mHomeWebView != null) {
            mHomeWebView.handleDestroy();
        }

        if (mMessengerWebView != null) {
            mMessengerWebView.handleDestroy();
        }

        LocalBroadcastManager.getInstance(MainActivity.this).unregisterReceiver(mShowMessengerDiaLogReceiver);
    }

    private Animation mFadeInAnim;
    private Animation mFadeOutAnim;

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {
        if (animation == mFadeOutAnim) {
            mProgressBarContainer.startAnimation(mFadeOutAnim);
            mMessengerWebView.startAnimation(mFadeInAnim);
        }
    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

    public class MessengerWebClient extends CordovaWebViewClient {

        public MessengerWebClient(CordovaInterface cordova, CordovaWebView view) {
            super(cordova, view);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(((url.matches(MATCHED_PATTERN) ? "" : "file:///android_asset/www/") + url));
            return true;
        }

        @SuppressLint("SetJavaScriptEnabled")
        @TargetApi(Build.VERSION_CODES.HONEYCOMB)
        @Override
        public void onPageFinished(WebView view, String url) {
            mProgressBar.setVisibility(View.GONE);
            mProgressBarContainer.setVisibility(View.GONE);
            MainActivity.this.setProgressValue(100);

            mProgressBarContainer.startAnimation(mFadeOutAnim);
            mProgressStatus = 100;

			refreshMesageCount();

            Log.d(TAG, String.format("LoadingPageFinished: %s", url));
            Log.d(TAG, String.format("ProgressLoading: %d", mProgressStatus));
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            mProgressBarContainer.setVisibility(View.VISIBLE);
            mProgressBar.setVisibility(View.VISIBLE);
            mProgressBarContainer.requestLayout();
            mMessengerWebView.setDrawingCacheEnabled(true);

            MainActivity.this.setProgressValue(0);
            mProgressStatus = 0;
            Log.d(TAG, String.format("LoadingPageStarted: %s", url));
            Log.d(TAG, String.format("ProgressLoading: %d", mProgressBar.getProgress()));
        }

    }

    public class MessengerChromeClient extends CordovaChromeClient {

        public MessengerChromeClient(CordovaInterface ctx, CordovaWebView app) {
            super(ctx, app);
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);

            MainActivity.this.setProgressValue(newProgress);
            mProgressStatus = newProgress;
        }
    }

    public int mProgressStatus = 0;

    public boolean isLoadedWebView() {
        if (mProgressStatus == 100) {
            mIsLoadedWebView = true;
        } else {
            mIsLoadedWebView = false;
        }
        return mIsLoadedWebView;
    }

    public void setProgressValue(int progressValue) {
        this.mProgressBar.setProgress(progressValue);
    }

	public void handleShowMessengerView(boolean isShowMessengerView, final boolean foreground) {
        Log.d(TAG, "handleShowMessengerView::" + isShowMessengerView + "::" + foreground);

        if (isShowMessengerView) {
            CommonUtils.pushNotification = true;
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					new Handler().postDelayed(new Runnable() {
						@Override
						public void run() {
							if (mHomeWebView != null && foreground) {
                                Log.d(TAG, "mHomeWebView.loadUrl");
                                mHomeWebView.loadUrl("javascript:onMessengerNewMessage(1);");
							}
							if (isLoadedWebView()) {
								reloadMessengerWebView();
							}

							mFrameContent.closeDrawers();
							mFrameContent.openDrawer(GravityCompat.END);

							CommonUtils.closeMsgNotification(MainActivity.this);
						}
					}, 1000);
				}
			});
		}
	}

	public void handleOnMessageArrived() {
		if (ClicksApp.isUpdateMsgCount) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Log.d(TAG, "on message arrived, Activity");
					if (mHomeWebView != null) {
						mHomeWebView.loadUrl("javascript:onMessengerNewMessage();");
						ClicksApp.isUpdateMsgCount = false;
					}
				}
			});
		}
	}

	public void handleActivateMessenger() {
		if (ClicksApp.isActivateMessenger) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Log.d(TAG, "on activate messenger, Activity");
					if (mHomeWebView != null) {
						mFrameContent.closeDrawer(GravityCompat.END);
						mHomeWebView.loadUrl("javascript:window.activateMessenger('MESSENGER_ACTIVATION','null')");
						ClicksApp.isActivateMessenger = false;
					}
				}
			});
		}
	}

	public void refreshMesageCount() {
		if (mHomeWebView != null)
			mHomeWebView.loadUrl("javascript:onMessengerNewMessage();");
	}

	public void showTopMessageLayout(String subject, long time) {
		// replaced with heats up notification

//		final View targetView = findViewById(R.id.frame_content);
//		final TSnackbar snackbar = TSnackbar.make(targetView, "", TSnackbar.LENGTH_LONG)
//				.setCallback(new TSnackbar.Callback() {
//					@Override
//					public void onDismissed(TSnackbar snackbar, @DismissEvent int event) {
//						super.onDismissed(snackbar, event);
//					}
//				});
//
//		TSnackbar.SnackbarLayout layout = (TSnackbar.SnackbarLayout) snackbar.getView();
//		layout.setPadding(0,0,0,0);
//
//		View v = snackbar.getView();
//		FrameLayout.LayoutParams params =(FrameLayout.LayoutParams)v.getLayoutParams();
//		params.gravity = Gravity.TOP;
//		params.setMargins(0,0,0,0);
//		v.setLayoutParams(params);
//		v.setPadding(0,0,0,0);
//
//		// Inflate our custom view
//		View snackView = LayoutInflater.from(MainActivity.this).inflate(R.layout.snackbar_tooltip, null);
//		snackView.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View view) {
//				openMsgViewfromTopLayout();
//				snackbar.dismiss();
//			}
//		});
//
//		TextView subjectTxt = (TextView) snackView.findViewById(R.id.msg_subject);
//		TextView timeTxt = (TextView) snackView.findViewById(R.id.time);
//
//		subjectTxt.setText(subject);
//		timeTxt.setText(CommonUtils.formatTime(time));
//
//		// Add the view to the Snackbar's layout
//		layout.addView(snackView, 0);
//
//		snackbar.show();
	}

	public void openMsgViewfromTopLayout() {
		if (isLoadedWebView()) {
			reloadMessengerWebView();
		}
		mFrameContent.openDrawer(GravityCompat.END);
		CommonUtils.closeMsgNotification(MainActivity.this);
	}

    private CallbackContext callback;
    public void showFragment(Fragment fragment, CallbackContext callbackContext){
        callback = callbackContext;

        if (!isFinishing()) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.slide_right_in, R.anim.slide_right_out)
                    .replace(R.id.content_container, fragment, fragment.getClass().getSimpleName())
                    .commitAllowingStateLoss();
        }
    }

    public void removeFragment(Fragment fragment){
        CommonUtils.dismissKeyboard(this);
        getSupportFragmentManager().beginTransaction()
				.setCustomAnimations(R.anim.slide_right_in, R.anim.slide_right_out)
                .remove(fragment)
                .commit();
    }

    public void showLoading(){
        new Handler().post(new Runnable(){
            @Override
            public void run() {
//                Log.d("ContactsFragment","showLoading");
                dialog =  new ProgressDialog(MainActivity.this);
                dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                dialog.setTitle("Loading");
                dialog.setMessage("Please wait...");
                dialog.setCancelable(false);
                dialog.setIndeterminate(true);
                dialog.show();
            }
        });
    }

    public void hideLoading(){
        if (dialog != null){
            if (dialog.isShowing()) {
                dialog.dismiss();
//                Log.d("ContactsFragment","hideLoading");
            }
        }
    }

    public void showAlertMessage(final String title, final String msg, final boolean showCancel, final boolean showOK,
                                 final String cancelLabel, final String okLabel,
                                 final DialogInterface.OnClickListener cancelListener,
                                 final DialogInterface.OnClickListener okListener) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (alertDialog != null && alertDialog.isShowing()){
                    alertDialog.dismiss();
                    alertDialog = null;
                }

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alertDialogBuilder.setTitle(title);
                alertDialogBuilder.setMessage(msg);

                if (showCancel && cancelLabel != null)
                    alertDialogBuilder.setNegativeButton(cancelLabel, cancelListener);
                if (showOK && okLabel != null)
                    alertDialogBuilder.setPositiveButton(okLabel, okListener);

                alertDialog = alertDialogBuilder.create();

                alertDialog.show();
            }
        });

    }

    public void requestContactPermission(CallbackContext callbackContext){
        callback = callbackContext;
        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.READ_CONTACTS)) {

                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                showAlertMessage(getString(R.string.permission_allow_contacts_title)
                        ,getString(R.string.permission_allow_contacts)
                        ,false,true,null,"Ok",null,permissionOkListener);
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.READ_CONTACTS},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }
    }

    private DialogInterface.OnClickListener permissionOkListener = new DialogInterface.OnClickListener() {

        @Override
        public void onClick(DialogInterface dialogInterface, int count) {
            Intent i = new Intent();
            i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.addCategory(Intent.CATEGORY_DEFAULT);
            i.setData(Uri.parse("package:" + getApplicationContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(i);
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    showFragment(ContactsFragment.newInstance(callback), callback);

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    showAlertMessage(getString(R.string.permission_allow_contacts_title)
                            ,getString(R.string.permission_allow_contacts)
                            ,false,true,null,"Ok",null,permissionOkListener);
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

}
