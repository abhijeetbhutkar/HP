package com.CIMBClicksMY.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

/**
 * @author Larry Pham (larrypham.vn@gmail.com)
 * @since March.10.2016
 *
 * @description
 *      The class <code>ProgressActivity</code> which has represented to display the ProgressBar dialog screen, when processing some user-cases such as:
 *      authenticating an account or scanning touch-id, fingerprint, etc...
 */
public class ProgressActivity extends Activity {
    private static final String TAG = ProgressActivity.class.getSimpleName();

    public static final String ACTION_HIDE_PROGRESS = "ProgressActivity.ACTION_HIDE_PROGRESS";
    public static final String EXTRA_SHOW_OVERLAY = "ProgressActivity.EXTRA_SHOW_OVERLAY";
    public static final String EXTRA_IS_FULLSCREEN = "ProgressActivity.EXTRA_IS_FULLSCREEN";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        final Intent intent = getIntent();
        Log.i(TAG, "Intent: " + intent.getAction() + " / " + intent.hasExtra(ACTION_HIDE_PROGRESS));

        // If its received intent has contained the hiding action, finishing the current activity
        if (intent.hasExtra(ACTION_HIDE_PROGRESS)) {
            finish();
            this.overridePendingTransition(0,0);
            return;
        }

        final Bundle extras = intent.getExtras();
        boolean showOverlay = extras == null || extras.getBoolean(EXTRA_SHOW_OVERLAY, true);
        boolean isFullScreen = extras != null && extras.getBoolean(EXTRA_IS_FULLSCREEN, false);

        if (isFullScreen) {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        // Adding a new ProgressBar and its container
        final ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams
                .WRAP_CONTENT);
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        bar.setLayoutParams(params);
        bar.setBackgroundColor(Color.TRANSPARENT);

        RelativeLayout container = new RelativeLayout(this);
        if (showOverlay) {
            container.setBackgroundColor(Color.parseColor("#aa000000"));
            container.addView(bar);
        }
        setTheme(android.R.style.Theme_Translucent_NoTitleBar);
        setContentView(container);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        Log.d(TAG, "Intent: " + intent.getAction() + " / " + intent.hasExtra(ACTION_HIDE_PROGRESS));
        if (intent.hasExtra(ACTION_HIDE_PROGRESS)) {
            finish();
            this.overridePendingTransition(0,0);
            return;
        }
        super.onNewIntent(intent);
    }
}
