package com.CIMBClicksMY.adapters;

import android.content.Context;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;

import com.CIMBClicksMY.R;
import com.CIMBClicksMY.models.ContactModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Harry on 7/11/16.
 */

public class ContactListAdapter extends ArrayAdapter<ContactModel> {

    int resource;
    List<ContactModel> items;
    List<ContactModel> originalItems;

    public ContactListAdapter(Context context, int resource) {
        super(context, resource);
        this.resource = resource;
    }

    public ContactListAdapter(Context context, int resource, List<ContactModel> items) {
        super(context, resource, items);
        this.resource = resource;
        this.items = items;
        this.originalItems = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if (v == null) {
            v = LayoutInflater.from(getContext()).inflate(resource, null);
        }

        ContactModel p = getItem(position);

        if (p != null) {
            TextView tv_name = (TextView) v.findViewById(R.id.tv_name);
            TextView tv_phone_number = (TextView) v.findViewById(R.id.tv_phone_number);

            tv_name.setText(p.getName());
            tv_phone_number.setText(p.getPhoneNumber());
        }

        return v;
    }

    @Override
    public int getCount() {
//        Log.d("ContactsFragment","items:" + items.size());
        return items.size();
    }

    @Nullable
    @Override
    public ContactModel getItem(int position) {
        return items.get(position);
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint,FilterResults results) {

                items = (ArrayList<ContactModel>) results.values; // has the filtered values
                notifyDataSetChanged();  // notifies the data with new filtered values
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();        // Holds the results of a filtering operation in values
                ArrayList<ContactModel> FilteredArrList = new ArrayList<>();

                if (originalItems == null) {
                    originalItems = new ArrayList<ContactModel>(items); // saves the original data in originalItems
                }

                /********
                 *
                 *  If constraint(CharSequence that is received) is null returns the originalItems(Original) values
                 *  else does the Filtering and returns FilteredArrList(Filtered)
                 *
                 ********/
                if (constraint == null || constraint.length() == 0) {

                    // set the Original result to return
                    results.count = originalItems.size();
                    results.values = originalItems;
                } else {
                    constraint = constraint.toString().toLowerCase();
                    for (int i = 0; i < originalItems.size(); i++) {
                        String data = originalItems.get(i).getName();
//                        Log.d("ContactsFragment","data: " + data);
                        if (data.toLowerCase().startsWith(constraint.toString())) {
                            FilteredArrList.add(new ContactModel(originalItems.get(i).getName(),originalItems.get(i).getPhoneNumber()));
                        }
                    }
                    // set the Filtered result to return
                    results.count = FilteredArrList.size();
                    results.values = FilteredArrList;
                }
                return results;
            }
        };
        return filter;
    }

}
