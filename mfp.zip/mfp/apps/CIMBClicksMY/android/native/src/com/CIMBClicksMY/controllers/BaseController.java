package com.CIMBClicksMY.controllers;

public abstract class BaseController {
    protected static final String TAG = BaseController.class.getSimpleName();

    /**
     * Invalidating the changes from background side or models to the UI components.
     */
    public abstract void invalidate();

    /**
     * Invalidating the changes from background side or models to the UI components with parameters.
     * @param params The specified parameters
     */
    public abstract void invalidate(Object... params);
}
