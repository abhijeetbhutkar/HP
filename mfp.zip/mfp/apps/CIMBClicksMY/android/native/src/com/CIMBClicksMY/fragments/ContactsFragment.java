package com.CIMBClicksMY.fragments;

import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.telephony.PhoneNumberUtils;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.CIMBClicksMY.MainActivity;
import com.CIMBClicksMY.R;
import com.CIMBClicksMY.adapters.ContactListAdapter;
import com.CIMBClicksMY.models.ContactModel;
import com.CIMBClicksMY.utils.IndexComparator;
import com.CIMBClicksMY.utils.MyPhoneUtils;
import com.CIMBClicksMY.views.IndexView;

import org.apache.cordova.CallbackContext;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Harry on 7/11/16.
 */

public class ContactsFragment extends Fragment implements AdapterView.OnItemClickListener, View.OnClickListener{

    private List<ContactModel> contactsList;
    private ListView mContactsList;
    private ContactListAdapter adapter;
    private EditText et_searchBox;
    private IndexView indexView;
    private TextView selectIndexView;
    private CallbackContext callback;
	private TextView cancelView;

    public static ContactsFragment newInstance(CallbackContext callbackContext){

        ContactsFragment fragment = new ContactsFragment();
        fragment.callback = callbackContext;
        return fragment;
    }

    // Empty public constructor, required by the system
    public ContactsFragment() {}

	// A UI Fragment must inflate its View
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("ContactsFragment","onCreateView");
        return inflater.inflate(R.layout.fragment_contacts,
                container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // Gets the ListView from the View list of the parent activity
        mContactsList =
                (ListView) getView().findViewById(R.id.list);
        et_searchBox =
                (EditText) getView().findViewById(R.id.et_searchBox);
        indexView = (IndexView) getView().findViewById(R.id.index);
        selectIndexView = (TextView) getView().findViewById(R.id.select_index);
		cancelView = (TextView) getView().findViewById(R.id.cancel_action);
		cancelView.setOnClickListener(this);

        contactsList = new ArrayList<>();

        new MyAsyncTask().execute();

        // Set the item click listener to be the current fragment.
        mContactsList.setOnItemClickListener(this);

        et_searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                adapter.getFilter().filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void getAllContacts(){
        Cursor cursor = getActivity().getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        while (cursor.moveToNext()){
            String id = cursor.getString(
                    cursor.getColumnIndex(ContactsContract.Contacts._ID));
            String name = cursor.getString(
                    cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            if (Integer.parseInt(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                //Query phone here.
                Cursor pCur = getActivity().getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = ?",
                        new String[]{id}, null);
                while (pCur.moveToNext()) {
                    // Do something with phones
                    String contactNumber = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
//                    Log.d("ContactsFragment","name:" + name + " number:" + contactNumber);
                    if(MyPhoneUtils.checkIfMalaysiaMobileNumber(contactNumber))
                        contactsList.add(new ContactModel(name,contactNumber));
                }
                pCur.close();
            }
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View item, int position, long rowID) {
        ContactModel contactModel = (ContactModel) parent.getItemAtPosition(position);
//        Toast.makeText(getActivity(),contactModel.getName(), Toast.LENGTH_LONG).show();
        JSONObject r = new JSONObject();
        try {
            r.put("name", contactModel.getName());
            r.put("number", PhoneNumberUtils.stripSeparators(contactModel.getPhoneNumber()));
        }catch(JSONException e){
            callback.error("Message failed");
        }
        callback.success(r);
        ((MainActivity) getActivity()).removeFragment(ContactsFragment.this);
    }

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.cancel_action:
				((MainActivity) getActivity()).removeFragment(ContactsFragment.this);
			default:
				break;
		}

	}

	private class MyAsyncTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            ((MainActivity) getActivity()).showLoading();
        }

        @Override
        protected Void doInBackground(Void... params) {
            // Execute query here
            getAllContacts();
            Collections.sort(contactsList, new IndexComparator());

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            adapter = new ContactListAdapter(getActivity(),R.layout.list_item_contact,contactsList);

            // Sets the adapter for the ListView
            mContactsList.setAdapter(adapter);
            indexView.init(mContactsList, selectIndexView);

            ((MainActivity) getActivity()).hideLoading();

            if (contactsList.size() == 0) {
//                Toast.makeText(getActivity(), "No contact to show", Toast.LENGTH_LONG).show();
                callback.error("No contact");
                ((MainActivity) getActivity()).removeFragment(ContactsFragment.this);
            }
        }

    }
}
