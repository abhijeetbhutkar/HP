package com.CIMBClicksMY.fragments;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.RelativeLayout;

import com.CIMBClicksMY.MainActivity;
import com.CIMBClicksMY.R;

/**
 * Created by Soe Yan Naing on 5/9/2016.
 */
public class FingerPrintDialog extends Dialog {

    private DialogController cimbSingleDialogController;
    private Context context;
    private RelativeLayout singleButton;
	private View defaultLayout, retryLayout, successLayout;

    public FingerPrintDialog(Context context, DialogController cimbSingleDialogController) {
        super(context, android.R.style.Theme_Holo_Dialog);
        this.context=context;
        this.cimbSingleDialogController = cimbSingleDialogController;
        initDialog();
    }

    private void initDialog() {
        getWindow();
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        setCanceledOnTouchOutside(false);
        setCancelable(false);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_single_view);

		defaultLayout = findViewById(R.id.finger_print_default_layout);
		retryLayout = findViewById(R.id.finger_print_error_layout);
		successLayout = findViewById(R.id.finger_print_success_layout);

        singleButton = (RelativeLayout)findViewById(R.id.single_dialog_button_rl);
        singleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                FingerPrintDialog.this.cancel();
                if(cimbSingleDialogController!=null)
                    cimbSingleDialogController.onOkClick();
            }
        });

		defaultLayout.setVisibility(View.VISIBLE);
		retryLayout.setVisibility(View.GONE);
		successLayout.setVisibility(View.GONE);

    }

	public void enableNormalLayout() {
		if (defaultLayout != null) {
			defaultLayout.post(new Runnable() {
				@Override
				public void run() {
					defaultLayout.setVisibility(View.VISIBLE);
				}
			});
			retryLayout.post(new Runnable() {
				@Override
				public void run() {
					retryLayout.setVisibility(View.GONE);
				}
			});
			successLayout.post(new Runnable() {
				@Override
				public void run() {
					successLayout.setVisibility(View.GONE);
				}
			});
		}
	}

	public void enableRetryLayout() {
		if (defaultLayout != null) {
			defaultLayout.post(new Runnable() {
				@Override
				public void run() {
					defaultLayout.setVisibility(View.GONE);
				}
			});
			retryLayout.post(new Runnable() {
				@Override
				public void run() {
					retryLayout.setVisibility(View.VISIBLE);
				}
			});
			successLayout.post(new Runnable() {
				@Override
				public void run() {
					successLayout.setVisibility(View.GONE);
				}
			});
		}
	}

	public void enableSuccessLayout() {
		if (defaultLayout != null) {
			defaultLayout.post(new Runnable() {
				@Override
				public void run() {
					defaultLayout.setVisibility(View.GONE);
				}
			});
			retryLayout.post(new Runnable() {
				@Override
				public void run() {
					retryLayout.setVisibility(View.GONE);
				}
			});
			successLayout.post(new Runnable() {
				@Override
				public void run() {
					successLayout.setVisibility(View.VISIBLE);
				}
			});
		}
	}

	public interface DialogController {
		void onOkClick();
	}
}
