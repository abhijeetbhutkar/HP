package com.CIMBClicksMY.interfaces;

public interface IndexString {
	public char getFirstChar();

	public String getString();
}
