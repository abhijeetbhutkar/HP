package com.CIMBClicksMY.models;

public class BaseModel {
}
