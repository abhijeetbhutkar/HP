package com.CIMBClicksMY.models;

import com.CIMBClicksMY.interfaces.IndexString;

/**
 * Created by Harry on 7/11/16.
 */

public class ContactModel implements IndexString {
    private String name;
    private String phoneNumber;

    public ContactModel(String name, String phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public char getFirstChar() {
        char c = name.charAt(0);
        if (c >= 'a' && c <= 'z') {
            c = (char) (c - 'a' + 'A');
        }
        return c;
    }

    @Override
    public String getString() {
        return name;
    }
}
