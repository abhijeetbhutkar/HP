package com.CIMBClicksMY.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class DeviceInfo implements Parcelable, Serializable {

    private String mDeviceName;

    private String mSerialDigits;

    private String mManufactureName;

    private boolean mIsRooted;

    public String getDeviceName() {
        return mDeviceName;
    }

    public void setDeviceName(String deviceName) {
        mDeviceName = deviceName;
    }

    public String getSerialDigits() {
        return mSerialDigits;
    }

    public void setSerialDigits(String serialDigits) {
        mSerialDigits = serialDigits;
    }

    public String getManufactureName() {
        return mManufactureName;
    }

    public void setManufactureName(String manufactureName) {
        mManufactureName = manufactureName;
    }

    public boolean isRooted() {
        return mIsRooted;
    }

    public void setRooted(boolean rooted) {
        mIsRooted = rooted;
    }

    public DeviceInfo(Parcel in) {
        readFromParcel(in);
    }

    public DeviceInfo(DeviceInfo other) {
        mSerialDigits = other.getSerialDigits();
        mDeviceName = other.mDeviceName;
        mManufactureName = other.getManufactureName();
        mIsRooted = other.isRooted();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public void readFromParcel(Parcel source) {
        if (source != null) {
            this.mSerialDigits = source.readString();
            this.mDeviceName = source.readString();
            this.mManufactureName = source.readString();
            this.mIsRooted = source.readInt() != 0;
        }
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (dest != null) {
            dest.writeString(this.mSerialDigits);
            dest.writeString(this.mDeviceName);
            dest.writeString(this.mManufactureName);
            dest.writeInt(this.mIsRooted ? 1 : 0);
        }
    }

    public static final Creator<DeviceInfo> CREATOR = new Creator<DeviceInfo>() {
        @Override
        public DeviceInfo createFromParcel(Parcel in) {
            return new DeviceInfo(in);
        }

        @Override
        public DeviceInfo[] newArray(int size) {
            return new DeviceInfo[size];
        }
    };

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (obj.getClass() != this.getClass()) {
            return false;
        }

        final DeviceInfo other = (DeviceInfo) obj;

        return mSerialDigits.equalsIgnoreCase(other.getSerialDigits()) && mDeviceName.equalsIgnoreCase(other.getDeviceName())
                && (mManufactureName.equalsIgnoreCase(other.getManufactureName()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = result * prime + mSerialDigits.hashCode();
        result = result * prime + mDeviceName.hashCode();
        result = result * prime + mManufactureName.hashCode();
        if (isRooted()) {
            result = result * prime + 1;
        }
        return result;
    }

    @Override
    public String toString() {
        return String.format("SerialNumber: %s \n Device Name: %s \n ManufactureName: %s", mSerialDigits, mDeviceName, mManufactureName);
    }
}
