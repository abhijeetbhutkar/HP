package com.CIMBClicksMY.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class TACModel implements Parcelable, Serializable {

    protected TACModel(Parcel in) {
    }

    public static final Creator<TACModel> CREATOR = new Creator<TACModel>() {
        @Override
        public TACModel createFromParcel(Parcel in) {
            return new TACModel(in);
        }

        @Override
        public TACModel[] newArray(int size) {
            return new TACModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
    }
}
