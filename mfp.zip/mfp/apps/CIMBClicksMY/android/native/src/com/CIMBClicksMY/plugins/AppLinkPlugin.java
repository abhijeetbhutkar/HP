package com.CIMBClicksMY.plugins;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;

import com.CIMBClicksMY.R;
import com.CIMBClicksMY.utils.CommonUtils;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

/**
 * @author Soe
 * added at 25/Nov/2016
 *
 * call openExternalApp("","") from Hybrid side to use this plugin.
 */
public class AppLinkPlugin extends CordovaPlugin {

	@Override
	public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
		if (action.equalsIgnoreCase("openExternalApp")) {

			try {
				String packageName = "", uriStr = "";
				if (args != null && args.length() == 2) {
					packageName = args.getString(0);
					uriStr = args.getString(1);
				}

				if (CommonUtils.isAppInstalled(packageName, cordova.getActivity())) {
					PackageManager manager = cordova.getActivity().getPackageManager();
					Intent intent = manager.getLaunchIntentForPackage(packageName);
					intent.addCategory(Intent.CATEGORY_LAUNCHER);
					cordova.getActivity().startActivity(intent);
				} else {
					Uri uri = Uri.parse(uriStr);
					Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
					try {
						cordova.getActivity().startActivity(myAppLinkToMarket);
					} catch (ActivityNotFoundException e) {
						//the device hasn't installed Google Play
						Toast.makeText(cordova.getActivity(), cordova.getActivity().getString(R.string.google_play_store_not_installed), Toast.LENGTH_LONG).show();
					}
				}

				callbackContext.success();
				return true;
			} catch (Exception ex) {
				callbackContext.error("N/A");
				return false;
			}
		}
		return false;
	}

}
