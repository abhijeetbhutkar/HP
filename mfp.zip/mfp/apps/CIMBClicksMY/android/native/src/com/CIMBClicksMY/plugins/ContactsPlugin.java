package com.CIMBClicksMY.plugins;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import com.CIMBClicksMY.MainActivity;
import com.CIMBClicksMY.R;
import com.CIMBClicksMY.fragments.ContactsFragment;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

/**
 * Created by Harry on 7/11/16.
 */

public class ContactsPlugin extends CordovaPlugin {

    public static final String TAG = ContactsPlugin.class.getSimpleName();
    public static final String GET_CONTACTS = "get_contacts";


    @Override
    public boolean execute(String action, JSONArray data, CallbackContext callbackContext) throws JSONException {

        if (action.equalsIgnoreCase(GET_CONTACTS)) {

            MainActivity activity = (MainActivity) cordova.getActivity();

            if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.READ_CONTACTS)
                    == PackageManager.PERMISSION_GRANTED) {
                activity.showFragment(ContactsFragment.newInstance(callbackContext), callbackContext);
            }else
                activity.requestContactPermission(callbackContext);

            return true;
        } else {
            return false;
        }
    }


}
