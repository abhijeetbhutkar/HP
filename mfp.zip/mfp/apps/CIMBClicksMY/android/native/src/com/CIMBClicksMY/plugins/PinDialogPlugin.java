package com.CIMBClicksMY.plugins;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.widget.EditText;
import android.widget.ProgressBar;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PinDialogPlugin extends CordovaPlugin {

    private static final String TAG = PinDialogPlugin.class.getSimpleName();

    public ProgressBar mSpinnerDialog = null;

    public PinDialogPlugin() {

    }

    public boolean execute(String action, JSONArray args, final CallbackContext callbackContext) throws JSONException {
        if (action.equalsIgnoreCase("prompt")) {
            final String message = args.getString(0);
            final String title = args.getString(1);
            final JSONArray buttonLabels = args.getJSONArray(2);

            final CordovaInterface cordova = this.cordova;
            final EditText promptInput = new EditText(cordova.getActivity());

            promptInput.setInputType(InputType.TYPE_CLASS_NUMBER);
            promptInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
            final Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(cordova.getActivity());
                    builder.setMessage(message);
                    builder.setTitle(title);

                    builder.setCancelable(true);
                    builder.setView(promptInput);

                    final JSONObject result = new JSONObject();
                    if (buttonLabels.length() > 0) {
                        try {
                            builder.setNegativeButton(buttonLabels.getString(0),
                                    new AlertDialog.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            try {
                                                result.put("buttonIndex", -1);
                                                result.put("input1", promptInput.getText().toString().trim().length() == 0 ? "" : promptInput.getText());
                                            } catch (JSONException ex) {
                                                ex.printStackTrace();
                                            }
                                            callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, result));
                                        }
                                    });
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    if (buttonLabels.length() > 1) {
                        try {
                            builder.setNegativeButton(buttonLabels.getString(1),
                                    new AlertDialog.OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                            try {
                                                result.put("buttonIndex", 2);
                                                result.put("input1", promptInput.getText().toString().trim().length() == 0 ? "" : promptInput.getText());
                                            } catch (JSONException ex) {
                                                ex.printStackTrace();
                                            }
                                        }
                                    });
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }
                    }

                    if (buttonLabels.length() > 2) {
                        try {
                            builder.setPositiveButton(buttonLabels.getString(2), new AlertDialog.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    try {
                                        result.put("buttonIndex", 3);
                                        result.put("input1", promptInput.getText().toString().length() == 0 ? "" : promptInput.getText());
                                    } catch (JSONException ex) {
                                        ex.printStackTrace();
                                    }
                                    callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, result));
                                }
                            });
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }
                    }

                    builder.setOnCancelListener(new AlertDialog.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            dialog.dismiss();
                            try {
                                result.put("buttonIndex", 0);
                                result.put("input1", promptInput.getText().toString().trim().length() == 0 ? "" : promptInput.getText());
                            } catch (JSONException ex) {
                                ex.printStackTrace();
                            }
                            callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, result));
                        }
                    });
                    builder.create();
                    builder.show();
                }
            } ;
            this.cordova.getActivity().runOnUiThread(runnable);
        }
        return true;
    }
}
