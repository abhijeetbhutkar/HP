package com.CIMBClicksMY.plugins;

import com.CIMBClicksMY.utils.CommonUtils;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

/**
 * @author Soe
 *
 */
public class RootDetection extends CordovaPlugin {

	private static final int DEVICE_IS_ROOTED = 1;
	private static final int DEVICE_IS_NOT_ROOTED = 0;

	public boolean isDeviceRooted() {
		return checkRootMethod1() || checkRootMethod2() || checkRootMethod3() || checkRootMethod4();
	}

	private boolean checkRootMethod1() {
		String buildTags = android.os.Build.TAGS;
		return buildTags != null && buildTags.contains("activity_onboarding-keys");
	}

	private boolean checkRootMethod2() {
		String[] paths = { "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/su/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
				"/system/bin/failsafe/su", "/data/local/su" };
		for (String path : paths) {
			if (new File(path).exists()) return true;
		}
		return false;
	}

	private boolean checkRootMethod3() {
		Process process = null;
		try {
			process = Runtime.getRuntime().exec(new String[] { "/system/xbin/which", "su" });
			BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
			if (in.readLine() != null) return true;
			return false;
		} catch (Throwable t) {
			return false;
		} finally {
			if (process != null) process.destroy();
		}
	}

	private boolean checkRootMethod4() {
		String[] apppackages = {"com.formyhm.hideroot", "com.amphoras.hidemyroot", "com.devadvance.rootcloakplus",
				"com.softdx.rootedhide"};
		for (String apppackage : apppackages) {
			if(CommonUtils.isAppInstalled(apppackage, cordova.getActivity())) return true;
		}
		return false;
	}

	@Override
	public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
		if (action.equalsIgnoreCase("isDeviceRooted")) {
			try {
				callbackContext.success(isDeviceRooted() ? DEVICE_IS_ROOTED : DEVICE_IS_NOT_ROOTED);
				return true;
			} catch (Exception ex) {
				callbackContext.error("N/A");
				return false;
			}
		}
		return false;
	}
}
