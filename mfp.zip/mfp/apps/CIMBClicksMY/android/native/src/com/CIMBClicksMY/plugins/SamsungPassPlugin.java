package com.CIMBClicksMY.plugins;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Handler;
import android.util.Log;
import android.util.SparseArray;
import android.widget.Toast;

//import com.CIMBClicksSG.widgets.ScannerFingerPrintDialog;
import com.CIMBClicksMY.fragments.FingerPrintDialog;
import com.CIMBClicksMY.utils.CommonUtils;
import com.samsung.android.sdk.SsdkUnsupportedException;
import com.samsung.android.sdk.SsdkVendorCheck;
import com.samsung.android.sdk.pass.Spass;
import com.samsung.android.sdk.pass.SpassFingerprint;
import com.samsung.android.sdk.pass.SpassInvalidStateException;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SamsungPassPlugin extends CordovaPlugin implements FingerPrintDialog.DialogController {
    private static final String TAG = SamsungPassPlugin.class.getSimpleName();

    public static final String CHECK_SAMSUNG_PASS = "isAvailable";
    public static final String CHECK_REGISTERED_FINGERS = "checkRegisterFinger";
    public static final String START_VERIFY = "verifyFingerprintWithCustomPasswordFallback";
    public static final String MOVE_USER_TO_SETTING = "moveUserToSetting";


    public static final String FINGER_PRINT_UNIQUE_ID = "FingerPrintUniqueId";
    public static final String FINGER_PRINT_SCANNING_SUCCESS = "Success";
    public static final String ERROR = "Error";

    public static final String KEY_FINGER_PRINT_DISMISS = "KEY_FINGER_PRINT_DISMISS";
    private SharedPreferences mPreferences;

    private Spass mSpass;
    private SpassFingerprint mSpassFingerprint;
    private boolean mIsFeaturedEnabled = false;

    private boolean mOnReadyIdentify = false;
    private boolean onReadyEnroll = false;

//    private ScannerFingerPrintDialog mFingerPrintDialog;
    private boolean mIsFingerPrintDialogOpen = false;
    private int mWrongFingerPrint = 0;

	private CallbackContext mCallbackContext;
	private FingerPrintDialog verifyDialog;
	private SpassFingerprint.IdentifyListener fingerPrintListener;


    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {

        mSpass = new Spass();
        try {
            mSpass.initialize(this.cordova.getActivity().getApplicationContext());
            Log.d(TAG, "Spass was initialized");
        } catch (SsdkUnsupportedException e) {
            Log.d(TAG,"This is not Samsung device");
            return;
        }catch (UnsupportedOperationException e){
            Log.d(TAG,"Fingerprint Service is not supported in the device");
            return;
        }

        mIsFeaturedEnabled = mSpass.isFeatureEnabled(Spass.DEVICE_FINGERPRINT);
        if (mIsFeaturedEnabled) {
            mSpassFingerprint = new SpassFingerprint(this.cordova.getActivity().getApplicationContext());
            Log.d(TAG, "Fingerprint Service is supported in the device.");
        } else {
            Log.d(TAG, "FingerPrint Service is not supported");
        }

		verifyDialog = new FingerPrintDialog(cordova.getActivity(), this);
    }

    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        Log.d(TAG, "Plugin Method Called " + action);

        if (!SsdkVendorCheck.isSamsungDevice()) {
            JSONObject r = new JSONObject();
            r.put("code", "0004");
            r.put("message", "This feature is only available in Samsung device");
            callbackContext.error(r);
            return true;
        }

        mCallbackContext = callbackContext;

        if (action.equalsIgnoreCase(CHECK_SAMSUNG_PASS)) {
            this.checkSamsungPassSupport(args, callbackContext);
        } else if (action.equalsIgnoreCase(CHECK_REGISTERED_FINGERS)) {
            this.checkForRegisterFingers(args, callbackContext);
        } else if (action.equalsIgnoreCase(START_VERIFY)) {
            this.startIdentifyWithDialog(args, callbackContext);
        } else if (action.equalsIgnoreCase(MOVE_USER_TO_SETTING)){
        	this.moveUserToSetting(callbackContext);
        }
        else {
            return false;
        }
        return true;
    }



    private void moveUserToSetting(CallbackContext callbackContext){
//    	this.cordova.getActivity().startActivityForResult(new Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS), 0);
        this.registerFingerprint();
//    	callbackContext.success();
    }

    private void registerFingerprint() {
//        if (onReadyIdentify == false) {
            if (onReadyEnroll == false) {
                onReadyEnroll = true;
                if (mSpassFingerprint != null) {
                    mSpassFingerprint.registerFinger(this.cordova.getActivity(), mRegisterListener);
                }
                Log.d(TAG,"Jump to the Enroll screen");
            } else {
            	Log.d(TAG,"Please wait and try to register again");
            }
//        } else {
//            log("Please cancel Identify first");
//        }
    }

    private SpassFingerprint.RegisterListener mRegisterListener = new SpassFingerprint.RegisterListener() {
        @Override
        public void onFinished() {
            onReadyEnroll = false;
            Log.d(TAG,"RegisterListener.onFinished()");
            mCallbackContext.success();
        }
    };

    private void checkSamsungPassSupport(JSONArray args, CallbackContext callbackContext)  throws JSONException {
        Log.d(TAG, CHECK_SAMSUNG_PASS);

        if (mIsFeaturedEnabled) {
            callbackContext.success();
        } else {
            JSONObject r = new JSONObject();
            r.put("code", "0003");
            r.put("message", "This feature is not available in this device.");
            callbackContext.error(r);

        }
    }

    private void checkForRegisterFingers(JSONArray args, CallbackContext callbackContext) throws JSONException {
        Log.d(TAG, CHECK_REGISTERED_FINGERS);
        boolean mHasRegisteredFinger = false;
//        mSpassFingerprint.hasRegisteredFinger();
        if (mSpassFingerprint == null) {
            return;
        }
        try {
        	mHasRegisteredFinger = mSpassFingerprint.hasRegisteredFinger();
        } catch (UnsupportedOperationException e) {
        	Log.d(TAG,"Fingerprint Service is not supported in the device");
        }

        if (mHasRegisteredFinger) {
            callbackContext.success();
        } else {
            JSONObject r = new JSONObject();
            r.put("code", "0002");
            r.put("message", "Please register fingerprint to use this feature.");
            callbackContext.error(r);

            Toast.makeText(this.cordova.getActivity(), "Please register fingerprint first", Toast.LENGTH_SHORT).show();
        }
    }


    public String getFingerPrintUniqueId() {
        String result = null;
        Log.d(TAG, "getFingerPrintUniqueId");
        try {
            Log.d(TAG, "====  FINGER PRINT UNIQUE ID ===");
            if (mSpassFingerprint != null) {
                int fingerPrintIndex = mSpassFingerprint.getIdentifiedFingerprintIndex();
                result = getFingerPrintUniqueIds(fingerPrintIndex);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public String getFingerPrintUniqueIds(int fingerPrintIndex) {
        String result = null;
        SparseArray mList = null;
        try {
            Log.d(TAG, "=FingerPrint UniqueID =");
            if (mSpassFingerprint != null) {
                mList = mSpassFingerprint.getRegisteredFingerprintUniqueID();
            }

            if (mList == null) {
                Log.d(TAG, "Registered FingerPrint is not existed ");
            } else {
                String ID = (String) mList.get(fingerPrintIndex);
                Log.d(TAG, "Index: " + fingerPrintIndex + ", Unique ID is " + ID);
                result = ID;
            }
        } catch (IllegalStateException ex) {
            Log.e(TAG, ex.getMessage());
        }
        return result;
    }

    public String getFingerPrint() {
        String result = null;
        Log.d(TAG, "getFingerPrintUniqueId");
        try {
            Log.d(TAG, "===== FINGER PRINT NAME ====");
            if (mSpassFingerprint != null) {
                int fingerPrintIndex = mSpassFingerprint.getIdentifiedFingerprintIndex();
                result = getFingerPrintNames(fingerPrintIndex);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public String getFingerPrintNames(int fingerPrintIndex) {
        String result = null;
        SparseArray<String> mList = null;
        try {
            Log.d(TAG, "== FingerPrint UniqueName ==");
            if (mSpassFingerprint != null) {
                mList = mSpassFingerprint.getRegisteredFingerprintName();
            }

            if (mList == null) {
                Log.d(TAG, "Registered FingerPrint is not exited");
            } else {
//                for (int i = 0; i < mList.size(); i++) {
//                    int index = mList.keyAt(i);
//                    String name = mList.get(index);
//                    Log.d(TAG,"index " + index + ", Name is " + name);
//                }

                String name = (String) mList.get(fingerPrintIndex);
                Log.d(TAG, "Index: " + fingerPrintIndex + ", FingerPrint's Name: " + name);
                result = name;
            }
        } catch (IllegalStateException ex) {
            ex.printStackTrace();
        }
        return result;
    }

    private void startIdentifyWithDialog(JSONArray args, CallbackContext callbackContext) throws JSONException {
        final CallbackContext callbackContextFinal = callbackContext;
		boolean isShowDialog = true;
		/*
		TODO: Set isShowDialog = false and HTML should pass the true/false to decide to show fingerprint or not.
		if (args != null && args.length() > 0) {
			isShowDialog = args.getBoolean(0);
		}
        */

		fingerPrintListener = new SpassFingerprint.IdentifyListener() {
            @Override
            public void onFinished(int eventStatus) {
                Log.d(TAG, "onFinished(): Identify authentication onFinished : " + eventStatus);

                if (eventStatus == SpassFingerprint.STATUS_AUTHENTIFICATION_SUCCESS) {
                    Log.d(TAG, "onFinished(): Identify authentication success");

					if (verifyDialog != null)
						cordova.getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								CommonUtils.vibrate(cordova.getActivity(), 100);
								verifyDialog.enableSuccessLayout();
							}
						});

					new Handler().postDelayed(new Runnable() {
						@Override
						public void run() {
							callbackContextFinal.success();

							if (verifyDialog != null)
								verifyDialog.dismiss();
						}
					}, 1000);



                } else if (eventStatus == SpassFingerprint.STATUS_AUTHENTIFICATION_PASSWORD_SUCCESS) {
                    callbackContextFinal.success();
                } else if (eventStatus == SpassFingerprint.STATUS_USER_CANCELLED
                        || eventStatus == SpassFingerprint.STATUS_USER_CANCELLED_BY_TOUCH_OUTSIDE) {
                    Log.d(TAG,"onFinished() : User cancel this identify.");

                    JSONObject r = new JSONObject();
                    try {
                        r.put("code", "0006");
                        r.put("message", "User has cancel this operation");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    callbackContextFinal.error(r);

					if (verifyDialog != null)
						verifyDialog.dismiss();

                } else if (eventStatus == SpassFingerprint.STATUS_TIMEOUT_FAILED) {
                    Log.d(TAG,"onFinished() : The time for identify is finished.");

					if (verifyDialog != null)
						cordova.getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								CommonUtils.vibrate(cordova.getActivity(), 100);

								verifyDialog.enableRetryLayout();

								new Handler().postDelayed(new Runnable() {
									@Override
									public void run() {

										if (verifyDialog != null)
											verifyDialog.dismiss();
									}
								}, 1500);
							}
						});


                    JSONObject r = new JSONObject();
                    try {
                        r.put("code", "0007");
                        r.put("message", "Time to use finger print is elapsed.");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    callbackContextFinal.error(r);
                } else if (!mSpass.isFeatureEnabled(Spass.DEVICE_FINGERPRINT_AVAILABLE_PASSWORD) &&
                     (eventStatus == SpassFingerprint.STATUS_BUTTON_PRESSED)) {
                        Log.d(TAG,"onFinished() : User pressed the own button");
//                        Toast.makeText(mContext, "Please connect own Backup Menu", Toast.LENGTH_SHORT).show();
                        JSONObject r = new JSONObject();
                        try {
                            r.put("code", "0008");
                            r.put("message", "User has cancel this operation");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        callbackContextFinal.error(r);

						if (verifyDialog != null)
							verifyDialog.dismiss();
                } else {
					if (verifyDialog != null)
						cordova.getActivity().runOnUiThread(new Runnable() {
							@Override
							public void run() {
								CommonUtils.vibrate(cordova.getActivity(), 100);

								verifyDialog.enableRetryLayout();

								new Handler().postDelayed(new Runnable() {
									@Override
									public void run() {

										if (verifyDialog != null)
											verifyDialog.dismiss();
									}
								}, 1500);
							}
						});


                    Log.d(TAG, "onFinished(): Authentication Fail for identify");
                    JSONObject r = new JSONObject();
                    try {
                        r.put("code", "0009");
                        r.put("message", "User authorisation is failed");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    callbackContextFinal.error(r);
                }

//				if (verifyDialog != null)
//					verifyDialog.dismiss();
            }

            @Override
            public void onReady() {

            }

            @Override
            public void onStarted() {

            }

            @Override
            public void onCompleted() {

            }
        };

        if (mSpassFingerprint != null) {
			// hided the finger print dialog title
//            mSpassFingerprint.setDialogTitle(dialogTitle, 0xf0000);
//            mSpassFingerprint.startIdentifyWithDialog(this.cordova.getActivity().getApplicationContext(), listener, false);

			// show custom finger print dialog
			if (isShowDialog && verifyDialog != null) {
				verifyDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
					@Override
					public void onDismiss(DialogInterface dialog) {
						if (fingerPrintListener != null)
							fingerPrintListener.onFinished(SpassFingerprint.STATUS_USER_CANCELLED);
					}
				});
				verifyDialog.enableNormalLayout();
				verifyDialog.show();
			}
            try {
                mSpassFingerprint.startIdentify(fingerPrintListener);
            }catch(SpassInvalidStateException e){
                if (verifyDialog != null)
                    verifyDialog.dismiss();
                JSONObject r = new JSONObject();
                r.put("code", "0001");
                r.put("message", "Fingerprint verification is disabled, please try after sometime");
                callbackContextFinal.error(r);
            }
        }
    }

	@Override
	public void onOkClick() {
		if (verifyDialog != null) {
			verifyDialog.dismiss();
		}
	}
}
