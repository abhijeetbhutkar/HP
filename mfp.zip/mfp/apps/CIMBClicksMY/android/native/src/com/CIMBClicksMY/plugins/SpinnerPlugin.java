package com.CIMBClicksMY.plugins;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import com.CIMBClicksMY.activities.ProgressActivity;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * @author Larry Pham (larrypham.vn@gmail.com)
 * @since March.10.2016
 *
 * @Description:
 *      The class <code>SpinnerPlugin</code> which provides the functions for showing the ProgressBar dialog or hiding the ProgressBar.
 *      From the hybrid side, just calling the method 'show' into the javascript source code, and then calling back to the hybrid bridge
 *      component, the activity of native side will understand how to show the ProgressBar dialog into current screen.
 */
public class SpinnerPlugin extends CordovaPlugin {

    private static final String TAG = SpinnerPlugin.class.getSimpleName();

    public static final String PARAM_SHOW_OVERLAY = "show_overlay";
    public static final String PARAM_SHOW_TIMEOUT = "show_timeout";
    public static final String PARAM_IS_FULLSCREEN = "fullscreen";

    private boolean mIsShown = false;

    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        final Activity context = this.cordova.getActivity();
        if (action.equalsIgnoreCase("show")) {
            if (!mIsShown) {
                mIsShown = true;

                JSONObject argsObj = args.getJSONObject(0);
                Boolean showOverlay = argsObj.has(PARAM_SHOW_OVERLAY) ? argsObj.getBoolean(PARAM_SHOW_OVERLAY) : null;
                Integer hideTimeOut = argsObj.has(PARAM_SHOW_TIMEOUT) ? argsObj.getInt(PARAM_SHOW_TIMEOUT) : null;
                Boolean isFullScreen = argsObj.has(PARAM_IS_FULLSCREEN) ? argsObj.getBoolean(PARAM_IS_FULLSCREEN) : null;

                show(context, showOverlay, hideTimeOut, isFullScreen);
            }
            callbackContext.success();
            return true;
        } else if (action.equalsIgnoreCase("hide")) {
            if (mIsShown) {
                mIsShown = false;
                hide(context);
            }
            callbackContext.success();
            return true;
        }
        callbackContext.error("Spinner received invalid action '" + action + "'");
        return false;
    }

    private boolean show(final Activity context, Boolean showOverlay, Integer hideTimeout, Boolean isFullScreen) {
        final Intent intent = new Intent(context, ProgressActivity.class);
        if (showOverlay != null) {
            intent.putExtra(ProgressActivity.EXTRA_SHOW_OVERLAY, showOverlay);
        }

        if (isFullScreen != null) {
            intent.putExtra(ProgressActivity.EXTRA_IS_FULLSCREEN, isFullScreen);
        }
        context.startActivity(intent);

        if (hideTimeout != null) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    hide(context);
                }
            }, hideTimeout * 1000);
        }
        return true;
    }

    private boolean hide(final Activity context) {
        final Intent intent = new Intent(context, ProgressActivity.class);
        intent.putExtra(ProgressActivity.ACTION_HIDE_PROGRESS, true);
        context.startActivity(intent);

        return true;
    }
}
