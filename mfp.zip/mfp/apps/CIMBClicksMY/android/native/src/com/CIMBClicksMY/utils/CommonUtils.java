package com.CIMBClicksMY.utils;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.CIMBClicksMY.ClicksApp;
import com.CIMBClicksMY.MainActivity;
import com.CIMBClicksMY.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.common.base.Strings;

import org.apache.cordova.CordovaInterface;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CommonUtils {

	public static final String TAG = CommonUtils.class.getSimpleName();
	public static boolean pushNotification = false;
//	public static int MSG_NOTIFICATION_ID = 1;

    private CommonUtils() {

    }

    public static String getDeviceName() {
        String manufacture = Build.MANUFACTURER;
        String model = Build.MODEL;

        if (model.startsWith(manufacture)) {
            return capitalize(model);
        }
        return capitalize(manufacture) + " " + model;
    }

    public static String capitalize(String str) {
       if (TextUtils.isEmpty(str)) {
           return str;
       }

        char[] charArray = str.toCharArray();
        boolean capitalizeNext= true;
        String phrase = "";

        for (char elem: charArray) {
           if (capitalizeNext && Character.isLetter(elem)) {
               phrase += Character.toUpperCase(elem);
               capitalizeNext = false;
               continue;
           } else if (Character.isWhitespace(elem)) {
               capitalizeNext = true;
           }
           phrase += elem;
        }
        return phrase;
    }

	public static String formatTime(long when) {
		String convertedTime = null;
		SimpleDateFormat inputFormat = new SimpleDateFormat("hh:mm a");
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis(when);
			convertedTime = inputFormat.format(calendar.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return convertedTime;
	}

	/**
	 * Check the device to make sure it has the Google Play Services APK. If
	 * it doesn't, display a dialog that allows users to download the APK from
	 * the Google Play Store or enable it in the device's system settings.
	 */
	public static boolean checkPlayServices(final CordovaInterface cordova) {
		final int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(cordova.getActivity());
		if (resultCode != ConnectionResult.SUCCESS) {
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
				cordova.getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {
						GooglePlayServicesUtil.getErrorDialog(resultCode, cordova.getActivity(), 9000).show();
					}
				});
			} else {
				Log.i(TAG, "This device is not supported.");
				cordova.getActivity().finish();
			}
			return false;
		}
		return true;
	}

	public static void createMsgNotification(Context context, String body) {
		body = Strings.isNullOrEmpty(body) ?  context.getResources().getString(R.string.push_notification_body) : body;

		Intent intent = new Intent(context, MainActivity.class);
		intent.putExtra("isShowMessengerView", true);
//		ClicksApp.isShowMessengerView = true;
		PendingIntent pendingIntent = PendingIntent.getActivity(context, 0 /* Request code */, intent,
			PendingIntent.FLAG_UPDATE_CURRENT);

		Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context)
			.setSmallIcon(R.drawable.ic_notification_icon)
			.setContentTitle(context.getResources().getString(R.string.push_notification_title))
			.setContentText(body)
			.setAutoCancel(true)
			.setSound(defaultSoundUri)
			.setContentIntent(pendingIntent);

		// enable heats up Notification (since Android Lollipop version API 5.0)
		if (Build.VERSION.SDK_INT >= 21)
			notificationBuilder.setPriority(Notification.PRIORITY_HIGH);

		NotificationManager notificationManager =
			(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

		// increasing id to show multiple notification message.
		int notificationId = (int) Calendar.getInstance().getTimeInMillis();

		notificationManager.notify(notificationId /* ID of notification */, notificationBuilder.build());
	}

	public static void closeMsgNotification(Context context) {
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.cancelAll();
	}

	public static void notifyJsMessengerCount(Context context, String subject, long time) {
		ClicksApp.isUpdateMsgCount = true;
		Intent intent = new Intent(MainActivity.UPDATE_MESSAGE_COUNT);
		intent.putExtra(MainActivity.PARAM_MSG_SUBJECT, subject);
		intent.putExtra(MainActivity.PARAM_MSG_TIME, time);
		LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
	}

	// removed
//	public static void notifyActivateMessenger(Context context) {
//		ClicksApp.isActivateMessenger = true;
//		Intent intent = new Intent(MainActivity.ACTIVATE_MESSENGER);
//		LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
//	}

    public static void dismissKeyboard(Activity context){
        // Check if no view has focus:
        View view = context.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }


	public static void vibrate(Context context, long milliseconds) {
		try {
			Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
			vibrator.vibrate(milliseconds);
		} catch (SecurityException e) {
			Log.e(TAG,
					"Could not activate vibration feedback. Please add <uses-permission android:name=\"android.permission.VIBRATE\" /> to your application's manifest.");
		} catch (Exception e) {
			Log.w(TAG, "Exception while attempting to vibrate: ", e);
		}
	}

	public static boolean isAppInstalled(String packageName, Context activity) {
		Intent mIntent = activity.getPackageManager().getLaunchIntentForPackage(packageName);
		if (mIntent != null)
			return true;
		else
			return false;
	}
}

