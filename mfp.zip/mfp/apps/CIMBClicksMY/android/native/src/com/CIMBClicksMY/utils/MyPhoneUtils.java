package com.CIMBClicksMY.utils;

import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;

/**
 * Created by Harry on 10/11/16.
 */

public class MyPhoneUtils {

    public static String MY_COUNTRY_CODE = "+601";
    public static String MY_COUNTRY_CODE2 = "01";
    /*
    start with + 601, 01
    length is 10 - 11 digits
     */
    public static boolean checkIfMalaysiaMobileNumber(String number){
        if (!TextUtils.isEmpty(number)){
            String normalizedNumber = PhoneNumberUtils.normalizeNumber(number);
            if (normalizedNumber.startsWith(MY_COUNTRY_CODE) || normalizedNumber.startsWith(MY_COUNTRY_CODE2)){
                if (normalizedNumber.length() >= 10){
                    return true;
                }else {
                    return false;
                }
            }
        }

        return false;
    }
}
