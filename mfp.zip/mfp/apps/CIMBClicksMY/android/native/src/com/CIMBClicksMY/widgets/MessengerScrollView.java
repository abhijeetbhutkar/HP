package com.CIMBClicksMY.widgets;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ScrollView;

public class MessengerScrollView extends ScrollView {

    public boolean mShouldBeHide = false;

    public MessengerScrollView(Context context) {
        super(context);
    }

    public MessengerScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public MessengerScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setShouldBeHide(boolean enabled) {
        mShouldBeHide = enabled;
    }

    public boolean isShouldBeHide() {
        return mShouldBeHide;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
            setShouldBeHide(true);
            return true;
        }
        return super.onTouchEvent(event);
    }
}
