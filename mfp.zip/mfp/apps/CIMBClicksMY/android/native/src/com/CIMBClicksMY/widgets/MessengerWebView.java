package com.CIMBClicksMY.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import org.apache.cordova.CordovaWebView;

public class MessengerWebView extends CordovaWebView {

    public MessengerWebView(Context context) {
        super(context);
    }

    public MessengerWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        invalidate();
    }
}
