//
//  AppLinkPlugin.h
//  mfpCIMBClicksMYIphone
//
//  Created by Kishore on 30/11/2016.
//
//

#import <Cordova/CDVPlugin.h>
#import <Cordova/CDVViewController.h>

@interface AppLinkPlugin : CDVPlugin
{
    
}
- (void)openExternalApp:(CDVInvokedUrlCommand *)command;

- (void)openAppSettings:(CDVInvokedUrlCommand *)command;

@end
