//
//  AppLinkPlugin.m
//  mfpCIMBClicksMYIphone
//
//  Created by Kishore on 30/11/2016.
//
//

#import "AppLinkPlugin.h"

@implementation AppLinkPlugin

- (void)openExternalApp:(CDVInvokedUrlCommand *)command
{
    NSString* appID;
    
    NSString* itunesURL;
    
    if ([command.arguments count]>0)
    {
        appID = [command.arguments objectAtIndex:0];
    }
    if ([command.arguments count]>1)
    {
         itunesURL = [command.arguments objectAtIndex:1];
    }
    
    NSURL *existingAppUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@",appID]];
    
    if ( [[UIApplication sharedApplication] openURL: existingAppUrl])
    {
       
    }
    else
    {
        [[UIApplication sharedApplication] openURL: [NSURL URLWithString:itunesURL]];
    }
}

- (void)openAppSettings:(CDVInvokedUrlCommand *)command
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
}

@end
