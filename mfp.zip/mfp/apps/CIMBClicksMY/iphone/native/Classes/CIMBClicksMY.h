//
//  MyAppDelegate.h
//
//

#import <IBMMobileFirstPlatformFoundationHybrid/IBMMobileFirstPlatformFoundationHybrid.h>
#import "Cordova/CDVViewController.h"
#import "CustomNotification.h"

@interface MyAppDelegate : WLAppDelegate <WLInitWebFrameworkDelegate> {
 
     CustomNotification *cn;
}

+ (MyAppDelegate *)sharedApppDelegate;

@property (nonatomic, strong) CDVViewController* cordovaViewController;

@property (nonatomic, strong) NSString* deviceId;
@property (nonatomic ,strong) UIImageView * maskView;

- (NSString *)deviceIdentifier;

- (NSString *)documentDirectoryPath;

-(void)openMessengerWhenAppisInForeground;


@end
