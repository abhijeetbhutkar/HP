//
//  MyAppDelegate.m
//  CIMBClicksMY
//
//

#import "CIMBClicksMY.h"
#import <IBMMobileFirstPlatformFoundationHybrid/IBMMobileFirstPlatformFoundationHybrid.h>
#import "DeviceUID.h"
#import <AudioToolbox/AudioServices.h>

#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

@implementation MyAppDelegate

+ (MyAppDelegate *)sharedApppDelegate
{
    return (MyAppDelegate *)[UIApplication sharedApplication].delegate;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    application.applicationSupportsShakeToEdit = NO;
    
	BOOL result = [super application:application didFinishLaunchingWithOptions:launchOptions];

    // A root view controller must be created in application:didFinishLaunchingWithOptions:
	self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    UIViewController* rootViewController = [[UIViewController alloc] init];

    [self.window setRootViewController:rootViewController];
    [self.window makeKeyAndVisible];

    [self registerDeviceForPushNotofication];
    [[WL sharedInstance] showSplashScreen];
    // By default splash screen will be automatically hidden once Worklight JavaScript framework is complete.
	// To override this behaviour set autoHideSplash property in initOptions.js to false and use WL.App.hideSplashScreen() API.

    [[WL sharedInstance] initializeWebFrameworkWithDelegate:self];


    if (launchOptions != nil)
    {
        //opened from a push notification when the app is closed
        NSDictionary* userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        NSLog(@"User Information: %@",userInfo);
        
        [[NSUserDefaults standardUserDefaults] setObject:userInfo forKey:@"notification"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }else{
        [[NSUserDefaults standardUserDefaults] setObject:Nil forKey:@"notification"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }


    return result;
}

// This method is called after the WL web framework initialization is complete and web resources are ready to be used.
-(void)wlInitWebFrameworkDidCompleteWithResult:(WLWebFrameworkInitResult *)result
{
    if ([result statusCode] == WLWebFrameworkInitResultSuccess) {
        [self wlInitDidCompleteSuccessfully];
    } else {
        [self wlInitDidFailWithResult:result];
    }
}

-(void)wlInitDidCompleteSuccessfully
{
    UIViewController* rootViewController = self.window.rootViewController;

    // Create a Cordova View Controller
    self.cordovaViewController = [[CDVViewController alloc] init] ;

    self.cordovaViewController.startPage = [[WL sharedInstance] mainHtmlFilePath];

    // Adjust the Cordova view controller view frame to match its parent view bounds
    self.cordovaViewController.view.frame = rootViewController.view.bounds;

	// Display the Cordova view
    [rootViewController addChildViewController:self.cordovaViewController];
    [rootViewController.view addSubview:self.cordovaViewController.view];
    [self.cordovaViewController didMoveToParentViewController:rootViewController];
}

-(void)wlInitDidFailWithResult:(WLWebFrameworkInitResult *)result
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"ERROR"
                                                  message:[result message]
                                                  delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
    [alertView show];
}


- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    if (!self.maskView) {
        self.maskView =[[UIImageView alloc] initWithFrame:self.window.bounds];
    }

    [self.maskView setImage:[UIImage imageNamed:@"Default-736h"]];

    [self.window addSubview:self.maskView];

    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    [self.maskView removeFromSuperview];


    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (NSString *)deviceIdentifier
{

    //    return @"D7777711";

    if(self.deviceId)
        return self.deviceId;



    NSString *udid = [DeviceUID uid];// [self uniqueIdentifier];

    self.deviceId =udid;

    return udid;

}

- (NSString *)documentDirectoryPath
{

    /*
     NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);

     NSString *documentsDirectory = [paths objectAtIndex:0];

     return documentsDirectory;*/

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);

    NSString *cachePath = [paths objectAtIndex:0];

    BOOL isDir = NO;

    NSError *error;

    if (![[NSFileManager defaultManager] fileExistsAtPath:cachePath isDirectory:&isDir] && isDir == NO)
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:cachePath withIntermediateDirectories:NO attributes:nil error:&error];
    }

    return cachePath;
}


- (void)registerDeviceForPushNotofication
{

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 80000
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8.0")) {

        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge)  categories:nil]];

        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
    else
    {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge)];
    }
#else
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge)];
#endif

}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSString * strDeviceToken = [[deviceToken description] stringByReplacingOccurrencesOfString:@" " withString:@""];

    strDeviceToken = [strDeviceToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<> "]];

    NSLog(@"Device Token:%@", strDeviceToken);
    
    [[NSUserDefaults standardUserDefaults] setObject:strDeviceToken forKey:@"pushId"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    //[[BTVConfigurationManager sharedConfigurationManager] setAPNSIdentifier:strDeviceToken];
}

- (void) application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    UIApplicationState state = [application applicationState];
    NSString * jsCallBack = [NSString stringWithFormat:@"onMessengerNewMessage(true)"];
    if(state == UIApplicationStateActive)
        jsCallBack = [NSString stringWithFormat:@"onMessengerNewMessage()"];
    [self.cordovaViewController.webView stringByEvaluatingJavaScriptFromString:jsCallBack];
    
    
    if ( application.applicationState == UIApplicationStateActive )
    {
        // handle custom events when app in active mode
        
        if (cn)
        {
            [cn.view removeFromSuperview];
            
            [NSObject cancelPreviousPerformRequestsWithTarget:self];
        }
        
        cn = [[CustomNotification alloc] initWithNibName:@"CustomNotification" bundle:nil];
        
        cn.titleString = [[userInfo valueForKey:@"aps"] valueForKey:@"alert"];
        
        [cn.view setFrame:CGRectMake(0, -64, [[UIScreen mainScreen]bounds].size.width, 64)];
        
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        
        self.window.windowLevel = UIWindowLevelStatusBar;
        
        [self.window addSubview:cn.view];
        
        [UIView animateWithDuration:0.5 animations:^
         {
             [cn.view setFrame:CGRectMake(0, 0, [[UIScreen mainScreen]bounds].size.width, 64)];
             
         } completion:^(BOOL finished)
         {
             [self performSelector:@selector(MoveUpCustomPush) withObject:nil afterDelay:5];
         }];
    }
    
    
}

-(void)MoveUpCustomPush
{
    
    
    @autoreleasepool {
        [UIView animateWithDuration:0.5 animations:^{
            [cn.view setFrame:CGRectMake(0, -64, [[UIScreen mainScreen]bounds].size.width, 64)];
        } completion:^(BOOL finished) {
            [cn.view removeFromSuperview];
            self.window.windowLevel = UIWindowLevelNormal;
        }];
    }
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"Push notification registration error:%@", error);
}

-(BOOL)application:(UIApplication *)application shouldAllowExtensionPointIdentifier:(NSString *)extensionPointIdentifier
{
    
    if (extensionPointIdentifier == UIApplicationKeyboardExtensionPointIdentifier)
    {
        return NO;
    }
    
    return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        [[UIMenuController sharedMenuController] setMenuVisible:NO animated:NO];
    }];
    return [super canPerformAction:action withSender:sender];
}

-(void)openMessengerWhenAppisInForeground
{
    NSString * jsCallBack = [NSString stringWithFormat:@"onMessengerNewMessage(1)"];

    
    [self.cordovaViewController.webView stringByEvaluatingJavaScriptFromString:jsCallBack];
}


@end
