//
//  ChooseContact.h
//  mfpCIMBClicksMYIphone
//
//  Created by Pankaj on 08/11/2016.
//
//

#import <Cordova/CDVPlugin.h>
#import <Cordova/CDVViewController.h>


@interface ChooseContact : CDVPlugin

@property (nonatomic,strong) CDVInvokedUrlCommand *command;
- (void)get_contacts:(CDVInvokedUrlCommand *)command;

@end
