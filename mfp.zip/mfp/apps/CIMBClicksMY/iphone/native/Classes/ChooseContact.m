//
//  ChooseContact.m
//  mfpCIMBClicksMYIphone
//
//  Created by Pankaj on 08/11/2016.
//
//

#import "ChooseContact.h"
#import "ContactListViewController.h"
#import "CIMBClicksMY.h"


@interface ChooseContact ()<ContactListDelegate>

@end

@implementation ChooseContact

- (void)get_contacts:(CDVInvokedUrlCommand *)command {
    
    self.command = command;
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Contact" bundle:[NSBundle mainBundle]];
    
    UINavigationController *navController =[storyBoard instantiateInitialViewController];

    
    ContactListViewController *contactListViewController = (ContactListViewController *)navController.topViewController;
    contactListViewController.contactDelegate = self;
    MyAppDelegate *appDelegate = [MyAppDelegate sharedApppDelegate];
    
    [appDelegate.window.rootViewController presentViewController:navController animated:true completion:^{
        [contactListViewController getAllContactList];
    }];
    
}

-(void)setContactList:(NSDictionary *)contact {
    
    CDVPluginResult* pluginResult;
    if (contact) {
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:contact];
    }
    else {
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_NO_RESULT messageAsString:@""];
    }
   
    
    [self.commandDelegate sendPluginResult:pluginResult callbackId:self.command.callbackId];

}


@end
