//
//  ContactListViewController.h
//  mfpCIMBClicksMYIphone
//
//  Created by Pankaj on 08/11/2016.
//
//

#import <UIKit/UIKit.h>
#import <AddressBook/ABAddressBook.h>
#import <AddressBookUI/AddressBookUI.h>


@protocol ContactListDelegate <NSObject>

-(void)setContactList:(NSDictionary *)contact;

@end

@interface ContactListViewController : UIViewController
@property (nonatomic, strong) IBOutlet UITableView *tableView;

//this delegate is strong because it was getting nil after viewdid load 
@property (nonatomic) id <ContactListDelegate> contactDelegate;
-(void)getAllContactList ;
@end

typedef void (^ CDVAddressBookWorkerBlock)(
   ABAddressBookRef         addrBook
);

@interface CDVAddressBookPhoneNumberHelper : NSObject
{
}
- (void)createAddressBook:(CDVAddressBookWorkerBlock)workerBlock;

@end
