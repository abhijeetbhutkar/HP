//
//  ContactListViewController.m
//  mfpCIMBClicksMYIphone
//
//  Created by Pankaj on 08/11/2016.
//
//

#import "ContactListViewController.h"

@interface ContactListViewController () <UITableViewDataSource>{
    //for search records
    NSMutableArray *contacts;
    
    //for indexing A-Z
    NSMutableDictionary *contactsDictionary;
    NSArray *searchResults;
    NSArray *contactSectionTitles;
    NSArray *contactIndexTitles;
    
}

@end

@implementation ContactListViewController

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    return   [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    contactIndexTitles  = @[@"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K", @"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z", @"#"];
    self.title  = @"Contacts";
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated {
    
    NSLog(@"%@",self.contactDelegate);
    //[self getAllContactList];
    
}
-(void)getAllContactList {
    
    CDVAddressBookPhoneNumberHelper* abHelper = [[CDVAddressBookPhoneNumberHelper alloc] init];
    ContactListViewController* __weak weakSelf = self;
    
    [abHelper createAddressBook: ^(ABAddressBookRef addrBook) {
        if (addrBook == NULL) { // permission was denied or other error - return error
            
            dispatch_async(dispatch_get_main_queue(), ^{
               [weakSelf backPreviousScreen];[weakSelf backPreviousScreen];
            });
            
            return ;
            
        }
        
        contacts = [[NSMutableArray alloc] init];
        
        CFArrayRef records = ABAddressBookCopyArrayOfAllPeople(addrBook);
        NSArray *phoneContacts = (__bridge NSArray*)records;
        CFRelease(records);
        
        contactsDictionary =[[NSMutableDictionary alloc] init];
        
        for(int i = 0; i < phoneContacts.count; i++) {
            ABRecordRef ref = (__bridge ABRecordRef)[phoneContacts objectAtIndex:i];
            
            ABMultiValueRef phones = ABRecordCopyValue(ref, kABPersonPhoneProperty);
            int countPhones = ABMultiValueGetCount(phones);
            //we skip users with no phone numbers
            if (countPhones > 0) {
                NSMutableArray* phoneNumbersArray = [[NSMutableArray alloc] init];
                
                for(CFIndex j = 0; j < countPhones; j++) {
                    CFStringRef phoneNumberRef = ABMultiValueCopyValueAtIndex(phones, j);
                    CFStringRef phoneTypeLabelRef = ABMultiValueCopyLabelAtIndex(phones, j);
                    NSString *number = (__bridge NSString *) phoneNumberRef;
                    NSLog(@"%@",number);
                    
                    //Filter
                    NSPredicate *resultPredicate = [NSPredicate
                                                    predicateWithFormat:@"number == %@",
                                                    number];
                    NSArray *allphones = [phoneNumbersArray filteredArrayUsingPredicate:resultPredicate];
                    
                    if (allphones.count>0) {
                        
                    }
                    else {
                        
                        NSString *phoneLabel = @"OTHER";
                        if (phoneTypeLabelRef) {
                            if (CFEqual(phoneTypeLabelRef, kABWorkLabel)) {
                                phoneLabel = @"WORK";
                            } else if (CFEqual(phoneTypeLabelRef, kABHomeLabel)) {
                                phoneLabel = @"HOME";
                            } else if (CFEqual(phoneTypeLabelRef, kABPersonPhoneMobileLabel)) {
                                phoneLabel = @"MOBILE";
                            } else if (CFEqual(phoneTypeLabelRef, kABPersonPhoneIPhoneLabel)) {
                                phoneLabel = @"IPHONE";
                            } else if (CFEqual(phoneTypeLabelRef, kABPersonPhoneMainLabel)) {
                                phoneLabel = @"MAIN";
                            } else if (CFEqual(phoneTypeLabelRef, kABPersonPhoneHomeFAXLabel)) {
                                phoneLabel = @"HOMEFAX";
                            } else if (CFEqual(phoneTypeLabelRef, kABPersonPhoneWorkFAXLabel)) {
                                phoneLabel = @"WORKFAX";
                            } else if (CFEqual(phoneTypeLabelRef, kABPersonPhoneOtherFAXLabel)) {
                                phoneLabel = @"OTHERFAX";
                            } else if (CFEqual(phoneTypeLabelRef, kABPersonPhonePagerLabel)) {
                                phoneLabel = @"PAGER";
                            }
                        }
                        
                        // creating the nested element with the phone number details
                        NSMutableDictionary* phoneNumberDictionary = [NSMutableDictionary dictionaryWithCapacity:1];
                        [phoneNumberDictionary setObject: number forKey:@"number"];
                        [phoneNumberDictionary setObject: number forKey:@"normalizedNumber"];
                        [phoneNumberDictionary setObject: phoneLabel forKey:@"type"];
                        //removing formating for number
                        NSCharacterSet *notAllowedChars = [[NSCharacterSet characterSetWithCharactersInString:@"+1234567890"] invertedSet];
                        NSString *newnumber = [[number componentsSeparatedByCharactersInSet:notAllowedChars] componentsJoinedByString:@""];
                        [phoneNumberDictionary setObject: newnumber forKey:@"stripnumber"];

                        if([newnumber hasPrefix:@"+601"] || [newnumber hasPrefix:@"01"]){
                        // adding this phone number to the list of phone numbers for this user
                            [phoneNumbersArray addObject:phoneNumberDictionary];
                        }
                        
                        if (phoneNumberRef) CFRelease(phoneNumberRef);
                        if (phoneTypeLabelRef) CFRelease(phoneTypeLabelRef);
                    }
                }
                
                // creating the contact object
                NSString *displayName;
                
                NSString *firstName = (__bridge_transfer NSString*)ABRecordCopyValue(ref, kABPersonFirstNameProperty);
                if (!firstName)
                    firstName = @"";
                displayName = firstName;
                
                NSString *middleName = (__bridge_transfer NSString*)ABRecordCopyValue(ref, kABPersonMiddleNameProperty);
                if (!middleName) {
                    middleName = @"";
                }
                else {
                    if (displayName.length)
                        displayName = [displayName stringByAppendingString:@" "];
                    displayName = [displayName stringByAppendingString:middleName];
                }
                
                NSString *lastName = (__bridge_transfer NSString*)ABRecordCopyValue(ref, kABPersonLastNameProperty);
                if (!lastName) {
                    lastName = @"";
                }
                else {
                    if (displayName.length)
                        displayName = [displayName stringByAppendingString:@" "];
                    displayName = [displayName stringByAppendingString:lastName];
                }
                
                NSString *contactId = [NSString stringWithFormat:@"%d", ABRecordGetRecordID(ref)];
                
                //NSLog(@"Name %@ - %@", displayName, contactId);
                
                NSSet *set = [NSSet setWithArray:phoneNumbersArray];
                
                NSArray *numbers = [set allObjects];
                
                if (numbers.count>0) {
                    for (int index =0 ; index<numbers.count; index++) {
                        NSMutableDictionary* contactDictionary = [NSMutableDictionary dictionaryWithCapacity:1];
                        [contactDictionary setObject: contactId forKey:@"id"];
                        [contactDictionary setObject: displayName forKey:@"displayName"];
                        [contactDictionary setObject: firstName forKey:@"firstName"];
                        [contactDictionary setObject: lastName forKey:@"lastName"];
                        [contactDictionary setObject: middleName forKey:@"middleName"];
                        [contactDictionary setObject: [numbers objectAtIndex:index] forKey:@"phoneNumber"];
                        [contacts addObject:contactDictionary];
                    }
                }
                
                //add the contact to the list to return
            }
            CFRelease(phones);
        }
        
        if (addrBook) {
            CFRelease(addrBook);
        }
        
        //Filtering array based on first name
        for (NSString *alphabate in contactIndexTitles) {
            
            //Filter on alphabate
            NSPredicate *resultPredicate = [NSPredicate
                                            predicateWithFormat:@"displayName beginswith[i] %@",
                                            alphabate];
            NSArray *contactArray = [contacts filteredArrayUsingPredicate:resultPredicate];
            
            //remove duplicate record
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:contactArray];
            contactArray = [orderedSet array];
            
            //sort record
            NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"displayName" ascending:YES];
            contactArray  = [contactArray sortedArrayUsingDescriptors:@[sort]];
            
            //adding to dictionary with key as alphabate
            if (contactArray.count > 0) {
                [contactsDictionary setObject:contactArray forKey:[alphabate uppercaseString]];
            }
        }
        
        //getting all keys
        contactSectionTitles = [[contactsDictionary allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        
        NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"displayName" ascending:YES];
        contacts = (NSMutableArray *) [contacts sortedArrayUsingDescriptors:@[sort]];
        
        dispatch_async(dispatch_get_main_queue(), ^{
           [weakSelf.tableView reloadData];
        });
        
        
    }];
    
}

- (void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    if (alertView.tag == 1001) {
        [self backPreviousScreen];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (IBAction)cancelButtonTapped:(id)sender {
    [self backPreviousScreen];
}


-(void)backPreviousScreen {
    if ([self.contactDelegate respondsToSelector:@selector(setContactList:)]) {
        [self.contactDelegate setContactList:nil];
        
    }
    [self dismissViewControllerAnimated:true completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [searchResults count];
        
    } else {
        NSString *sectionTitle = [contactSectionTitles objectAtIndex:section];
        NSArray *sectionAnimals = [contactsDictionary objectForKey:sectionTitle];
        return [sectionAnimals count];
        
    }
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"ContactCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:simpleTableIdentifier];
    }
    
    NSDictionary *contact = nil;
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.detailTextLabel.font = [UIFont systemFontOfSize:10];
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        contact = [searchResults objectAtIndex:indexPath.row];
        cell.textLabel.text = [contact objectForKey:@"displayName"];
        cell.detailTextLabel.text = [[contact objectForKey:@"phoneNumber"] objectForKey:@"number"];
    } else {
        NSString *sectionTitle = [contactSectionTitles objectAtIndex:indexPath.section];
        NSArray *contactArray = [contactsDictionary objectForKey:sectionTitle];
        NSDictionary *contactData = [contactArray objectAtIndex:indexPath.row];
        
        cell.textLabel.text = [contactData objectForKey:@"displayName"];
        
        cell.detailTextLabel.text = [[contactData objectForKey:@"phoneNumber"] objectForKey:@"number"];
    }
    
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *contact = nil;
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        contact = [searchResults objectAtIndex:indexPath.row];
    }
    else {
        NSString *sectionTitle = [contactSectionTitles objectAtIndex:indexPath.section];
        NSArray *contactArray = [contactsDictionary objectForKey:sectionTitle];
        contact = [contactArray objectAtIndex:indexPath.row];
    }
    
    
    
    if ([self.contactDelegate respondsToSelector:@selector(setContactList:)]) {
        
        NSString *number = [[contact objectForKey:@"phoneNumber"] objectForKey:@"stripnumber"];
        
        NSDictionary *dataDictionary = [NSDictionary dictionaryWithObjectsAndKeys:[contact objectForKey:@"displayName"],@"name",number,@"number", nil];
        [self.contactDelegate setContactList:dataDictionary];
    }
    [self dismissViewControllerAnimated:true completion:nil];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return 1;
    }
    else {
        // Return the number of sections.
        return contactSectionTitles.count;
    }
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return nil;
    }
    else {
        UILabel *myLabel = [[UILabel alloc] init];
        myLabel.frame = CGRectMake(15, 2, 320, 20);
        myLabel.font = [UIFont boldSystemFontOfSize:18];
        myLabel.text = [contactSectionTitles objectAtIndex:section];
        UIView *headerView = [[UIView alloc] init];
        [headerView addSubview:myLabel];
        return headerView;
    }
}


- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return @[];
    }
    else {
        return contactIndexTitles;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return 24;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 50;
    
}

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"displayName contains[cd] %@",
                                    searchText];
    
    searchResults = [contacts filteredArrayUsingPredicate:resultPredicate];
}

#pragma mark - UISearchDisplayController delegate methods
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller
shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];
    
    return YES;
}
/*
 - (BOOL)searchDisplayController:(UISearchDisplayController *)controller
 shouldReloadTableForSearchScope:(NSInteger)searchOption
 {
 [self filterContentForSearchText:[self.searchDisplayController.searchBar text]
 scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
 objectAtIndex:searchOption]];
 
 return YES;
 }
 
 */

@end

@implementation CDVAddressBookPhoneNumberHelper

/**
 * NOTE: workerBlock is responsible for releasing the addressBook that is passed to it
 */
- (void)createAddressBook:(CDVAddressBookWorkerBlock)workerBlock
{
    ABAddressBookRef addrBook = ABAddressBookCreateWithOptions(NULL, nil);
    ABAddressBookRequestAccessWithCompletion(addrBook, ^(bool granted, CFErrorRef error) {
        // callback can occur in background, address book must be accessed on thread it was created on
        dispatch_sync(dispatch_get_main_queue(), ^{
            workerBlock(error || !granted ? NULL : addrBook);
        });
    });
}

@end
