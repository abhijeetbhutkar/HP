//
//  CustomNotification.h
//  North
//
//  Created by Kartheek on 30/01/16.
//  Copyright © 2016 Way2Online. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNotification : UIViewController
{
    
    __weak IBOutlet NSLayoutConstraint *messageHeightConstraint;
    IBOutlet UILabel *pushTitle;
}

@property (strong, nonatomic) NSString *titleString;
- (IBAction)openNotification:(id)sender;

@end
