//
//  CustomNotification.m
//  North
//
//  Created by Kartheek on 30/01/16.
//  Copyright © 2016 Way2Online. All rights reserved.
//

#import "CustomNotification.h"
#import "CIMBClicksMY.h"

@interface CustomNotification ()
{
    MyAppDelegate *app;
}
@end

@implementation CustomNotification

- (void)viewDidLoad
{
    app = (MyAppDelegate *)[[UIApplication sharedApplication] delegate];
    pushTitle.text = _titleString;
    [super viewDidLoad];
    
    
    UISwipeGestureRecognizer *gestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeHandler:)];
    [gestureRecognizer setDirection:(UISwipeGestureRecognizerDirectionDown)];
    [self.view addGestureRecognizer:gestureRecognizer];
    
    // Do any additional setup after loading the view from its nib.
}

-(void)swipeHandler:(UISwipeGestureRecognizer *)recognizer
{
    
     pushTitle.numberOfLines = 0;
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    [UIView animateWithDuration:1.0 animations:^
    {
        [self.view setFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, pushTitle.frame.size.height+40)];
    }completion:^(BOOL finished)
    {
        
        [self performSelector:@selector(MoveUpCustomPush) withObject:nil afterDelay:7];

    }];
    
    
    
    
   
}


-(void)MoveUpCustomPush
{
    
    
    @autoreleasepool {
        [UIView animateWithDuration:0.5 animations:^{
            [self.view setFrame:CGRectMake(0, -64, [[UIScreen mainScreen]bounds].size.width, 64)];
        } completion:^(BOOL finished) {
            [self.view removeFromSuperview];
            [[UIApplication sharedApplication] keyWindow].windowLevel = UIWindowLevelNormal;
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)openNotification:(id)sender
{
    [self.view removeFromSuperview];
    
    [[UIApplication sharedApplication]keyWindow].windowLevel = UIWindowLevelNormal;
    
    app = (MyAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [app openMessengerWhenAppisInForeground];
}
@end
