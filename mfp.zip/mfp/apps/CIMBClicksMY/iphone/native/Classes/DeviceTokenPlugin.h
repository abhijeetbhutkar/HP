//
//  deviceTokenPlugin.h
//  mfpCIMBClicksMYIphone
//
//  Created by Arun Sekhar on 10/8/16.
//
//

#import <Foundation/Foundation.h>

#import <Cordova/CDVPlugin.h>
#import <Cordova/CDVViewController.h>

@interface DeviceTokenPlugin : CDVPlugin
{
    
}

- (void)getDeviceToken:(CDVInvokedUrlCommand*)command;
- (void)successNotification:(CDVInvokedUrlCommand*)command;
@end
