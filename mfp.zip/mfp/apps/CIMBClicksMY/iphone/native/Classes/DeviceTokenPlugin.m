//
//  deviceTokenPlugin.m
//  mfpCIMBClicksMYIphone
//
//  Created by Arun Sekhar on 10/8/16.
//
//

#import "DeviceTokenPlugin.h"

@implementation DeviceTokenPlugin

- (void)getDeviceToken:(CDVInvokedUrlCommand*)command
{
    CDVPluginResult* pluginResult;
    
    UIUserNotificationSettings *types = [[UIApplication sharedApplication] currentUserNotificationSettings];
    
    if (types.types)
    {
        NSString * pushId =[[NSUserDefaults standardUserDefaults] objectForKey:@"pushId"];
        if (pushId)
        {
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:pushId];
            
        }
        else
        {
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_NO_RESULT messageAsString:@""];
            
        }
    }
    else
    {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_NO_RESULT messageAsString:@""];
        
    }
    
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    
}

- (void)getPushNotifcation:(CDVInvokedUrlCommand*)command
{
    CDVPluginResult* pluginResult;
    UIUserNotificationSettings *types = [[UIApplication sharedApplication] currentUserNotificationSettings];
    if (types.types)
    {
        NSString * notification =[[NSUserDefaults standardUserDefaults] objectForKey:@"notification"];
        if (notification)
        {
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@""];
        }
        else
        {
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_NO_RESULT messageAsString:@""];
        }
    }
    else
    {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_NO_RESULT messageAsString:@""];
    }
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

@end
