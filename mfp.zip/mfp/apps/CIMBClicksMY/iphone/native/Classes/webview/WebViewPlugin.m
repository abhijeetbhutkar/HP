
#include <sys/types.h>
#include <sys/sysctl.h>
#include <sys/stat.h>

#import <Cordova/CDV.h>
#import "WebViewPlugin.h"
#import "CIMBClicksMY.h"

#define kScreenWidth                            [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight                           [[UIScreen mainScreen] bounds].size.height
#define kOffsetWidth                            40

@implementation WebViewPlugin

//@synthesize webViewController;

+ (void)initialize
{
    if (self == [WebViewPlugin class])
    {
        NSLog(@"***** INIT");
    }
}


- (void)subscribeCallback:(CDVInvokedUrlCommand*)command
{
    [self.commandDelegate runInBackground:^{
        @try {
            webViewFinishedCallBack = command.callbackId;
        }
        @catch (NSException *exception) {
            NSString* reason=[exception reason];
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString: reason];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
        }
    }];
}

- (void)show:(CDVInvokedUrlCommand*)command{
  NSString* url=(NSString*)[command.arguments objectAtIndex:0];
  NSLog(@"showwebViewView %@", url);
  [self.commandDelegate runInBackground:^{
    @try {
      dispatch_async(dispatch_get_main_queue(), ^
        {
            CDVViewController *viewController =  [MyAppDelegate sharedApppDelegate].cordovaViewController;
                        
            CGRect frame = [viewController.webView frame];
            
            frame.origin.x = -kScreenWidth + kOffsetWidth;
            
            if(!messageWebViewController)
            {
                messageWebViewController = [[WebViewController alloc] init];

                messageWebViewController.delegate = self;
            
                messageWebViewController.startPage = url;
            
                [messageWebViewController.view setFrame:CGRectMake( kScreenWidth, -20, kScreenWidth - kOffsetWidth, kScreenHeight + 20)];
          
                [self.viewController.view addSubview:messageWebViewController.view];
            }else{
                [messageWebViewController.webView reload];

            }
            
            statusBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 20)];
            
            statusBar.backgroundColor = [UIColor colorWithRed:(51/255.0) green:(51/255.0) blue:(51/255.0) alpha:1] ;
            
            closeButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, kOffsetWidth, kScreenHeight)];
            
            [closeButton setBackgroundColor:[UIColor clearColor]];
            
            [closeButton setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.45]];
            
            [closeButton setTag:1212];
            
            [closeButton setAlpha:0.0];
            
            [closeButton addTarget:self action:@selector(closeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            
            [viewController.view addSubview:closeButton];
           
            [[[UIApplication sharedApplication] keyWindow] addSubview:statusBar];
            
            [messageWebViewController.view setFrame:CGRectMake( kScreenWidth, -20, kScreenWidth - kOffsetWidth, kScreenHeight + 20)];
            
            [UIView animateWithDuration:0.35 animations:^{
                [viewController.webView setFrame:frame];
                
                [messageWebViewController.view setFrame:CGRectMake( kOffsetWidth, -20, kScreenWidth - kOffsetWidth, kScreenHeight + 20)];
            } completion:^(BOOL finished) {
                
                [UIView animateWithDuration:0.35 animations:^{
                    [closeButton setAlpha:1.0];
                }];
            }];
      });

      CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
      [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    }
    @catch (NSException *exception) {
      NSString* reason=[exception reason];
      CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString: reason];
      [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    }
  }];
}

- (void)hide:(CDVInvokedUrlCommand*)command{
  NSLog(@"hidewebViewView");
  [self.commandDelegate runInBackground:^{
    @try {

      dispatch_async(dispatch_get_main_queue(), ^{

          CDVViewController *viewController =  [MyAppDelegate sharedApppDelegate].cordovaViewController;
          
          CGRect frame = [viewController.webView frame];
          
          frame.origin.x = 0;
          
         [UIView animateWithDuration:0.35 animations:^{
              [viewController.webView setFrame:frame];
              
              [self.viewController.view setFrame:CGRectMake( kScreenWidth, -20, kScreenWidth - kOffsetWidth, kScreenHeight + 20)];
          }];
          
          UIButton *_closeButton = [viewController.view viewWithTag:1212];
          
          [_closeButton removeFromSuperview];
          
          //[self.viewController dismissViewControllerAnimated:YES completion:nil];
          
          //[self dispose];
          
      });

      CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
      [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    }
    @catch (NSException *exception) {
      NSString* reason=[exception reason];
      CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString: reason];
      [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    }
  }];
}

- (void)closeButtonAction:(UIButton *)sender
{
    CDVViewController *viewController =  [MyAppDelegate sharedApppDelegate].cordovaViewController;
    
    CGRect frame = [viewController.webView frame];
    
    frame.origin.x = 0;
    
    [UIView animateWithDuration:0.35 animations:^{
        [viewController.webView setFrame:frame];
        
        [messageWebViewController.view setFrame:CGRectMake( kScreenWidth, -20, kScreenWidth - kOffsetWidth, kScreenHeight + 20)];
    }];
    
    [statusBar removeFromSuperview];
    
    [sender removeFromSuperview];
    
    NSString * jsCallBack = [NSString stringWithFormat:@"onMessengerNewMessage()"];
    [viewController.webView stringByEvaluatingJavaScriptFromString:jsCallBack];

}

-(void)webViewFinished
{
  NSLog(@"webViewFinished");
  //webViewController = nil;

  CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
  [self.commandDelegate sendPluginResult:pluginResult callbackId:webViewFinishedCallBack];
}

@end

@implementation WebViewController

@synthesize delegate;

- (id)init {
  self = [super init];
  return self;
}

- (void)viewDidDisappear:(BOOL)animated {
  NSLog(@"viewDidDisappear");
  [super viewDidDisappear:animated];
  [delegate webViewFinished];
  delegate = nil;
}
@end
